/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

interface RemotePlayer {
  id: string;
  name: string;
  vehicle: string;
  color: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  roll: number;
  speedKmh: number;
  lights: boolean;
  brake: boolean;
  horn: boolean;
  fuelLiters: number;
  lastSeen: number;
}

const players = new Map<string, { ws: WebSocket; data: RemotePlayer }>();
const sharedSeed = 194723; // Fixed synchronized scenic seed for multiplayer road

wss.on('connection', (ws) => {
  const playerId = `driver_${Math.random().toString(36).substring(2, 7)}`;
  const defaultPlayer: RemotePlayer = {
    id: playerId,
    name: `Driver ${playerId.slice(-4).toUpperCase()}`,
    vehicle: 'hatch800',
    color: 0xb3262b,
    x: 170,
    y: 0,
    z: 380,
    yaw: 0,
    pitch: 0,
    roll: 0,
    speedKmh: 0,
    lights: false,
    brake: false,
    horn: false,
    fuelLiters: 35,
    lastSeen: Date.now(),
  };

  players.set(playerId, { ws, data: defaultPlayer });

  // Send welcome message
  const activeList = Array.from(players.values())
    .filter((p) => p.data.id !== playerId)
    .map((p) => p.data);

  ws.send(
    JSON.stringify({
      type: 'welcome',
      id: playerId,
      seed: sharedSeed,
      players: activeList,
    })
  );

  // Notify other players
  const joinMsg = JSON.stringify({ type: 'player_joined', player: defaultPlayer });
  for (const [id, client] of players.entries()) {
    if (id !== playerId && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(joinMsg);
    }
  }

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'update') {
        const entry = players.get(playerId);
        if (entry) {
          entry.data = {
            ...entry.data,
            ...msg.state,
            id: playerId,
            lastSeen: Date.now(),
          };
        }
      } else if (msg.type === 'event') {
        // Broadcast events (horn, quick message) to other drivers
        const broadcast = JSON.stringify({
          type: 'player_event',
          senderId: playerId,
          event: msg.event,
          payload: msg.payload,
        });
        for (const [id, client] of players.entries()) {
          if (id !== playerId && client.ws.readyState === WebSocket.OPEN) {
            client.ws.send(broadcast);
          }
        }
      } else if (msg.type === 'ping') {
        ws.send(JSON.stringify({ type: 'pong' }));
      }
    } catch {
      // Ignore malformed packets
    }
  });

  const cleanup = () => {
    players.delete(playerId);
    const leaveMsg = JSON.stringify({ type: 'player_left', id: playerId });
    for (const client of players.values()) {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(leaveMsg);
      }
    }
  };

  ws.on('close', cleanup);
  ws.on('error', cleanup);
});

// Broadcast 20Hz continuous world sync snapshot to connected drivers
setInterval(() => {
  if (players.size === 0) return;
  const now = Date.now();
  // Prune dead sessions > 15s
  for (const [id, client] of players.entries()) {
    if (now - client.data.lastSeen > 15000) {
      client.ws.terminate();
      players.delete(id);
    }
  }

  const snapshot = Array.from(players.values()).map((p) => p.data);
  const syncMsg = JSON.stringify({ type: 'sync', players: snapshot });
  for (const client of players.values()) {
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(syncMsg);
    }
  }
}, 50);

const isProd = process.env.NODE_ENV === 'production';
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(port, '0.0.0.0', () => {
    console.log(`Mountain Roads server running on port ${port} (Multiplayer WS active)`);
  });
}

startServer();
