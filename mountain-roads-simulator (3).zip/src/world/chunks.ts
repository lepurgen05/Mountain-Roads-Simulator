/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { mulberry32, sstep, fbm2 } from '../core/noise.ts';
import { BASE_ALT, Road } from './road.ts';
import {
  C,
  inst,
  put,
  done,
  groundMat,
  roadMat,
  pineGeo,
  cedarGeo,
  leafGeo,
  bushGeo,
  grassGeo,
  treeMat,
  bushMat,
  grassMat,
  rockGeo,
  rockMat,
  postGeo,
  postMat,
} from '../core/assets.ts';
import { Heightfield } from './heightfield.ts';

export const CHUNK_ROWS = 40;
export const TILE = 160;

const GRAV = new THREE.Color(0x8a7a62);
const YEL = new THREE.Color(0xd9b43a);
const PADDY = new THREE.Color(0x86a040);
const cc = new THREE.Color();

export interface RibbonChunk {
  group: THREE.Group;
  dispose: () => void;
}

export interface GroundTile {
  group: THREE.Group;
  cx: number;
  cz: number;
  lod: number;
  dispose: () => void;
}

export class ChunkManager {
  public scene: THREE.Scene;
  public road: Road;
  public hf: Heightfield;
  public seed: number;
  public rmap: Map<number, RibbonChunk> = new Map();
  public tmap: Map<string, GroundTile> = new Map();
  public ahead: number = 7;
  public veg: number = 0.8;
  public lodScale: number = 1.0;
  public tick: number = 0;
  public need: [number, number, number][] = [];

  constructor(scene: THREE.Scene, road: Road, hf: Heightfield, seed: number) {
    this.scene = scene;
    this.road = road;
    this.hf = hf;
    this.seed = seed | 0;
  }

  public configure(dist: number, veg: number, lodScale: number = 1.0): void {
    this.ahead = dist;
    this.lodScale = lodScale;
    const nv = veg / 100;
    if (Math.abs(nv - this.veg) > 1e-3) {
      this.veg = nv;
      this.clearTiles();
    }
  }

  public clearTiles(): void {
    for (const t of this.tmap.values()) {
      this.scene.remove(t.group);
      t.dispose();
    }
    this.tmap.clear();
  }

  public clear(): void {
    for (const c of this.rmap.values()) {
      this.scene.remove(c.group);
      c.dispose();
    }
    this.rmap.clear();
    this.clearTiles();
  }

  public prewarm(row: number, px: number, pz: number): void {
    this.hf.ensureIndex(row + 450);
    const c0 = Math.floor(row / CHUNK_ROWS);
    for (let c = Math.max(0, c0 - 1); c <= c0 + this.ahead; c++) {
      this.addRibbon(c);
    }
    this.refreshNeed(px, pz);
    for (const n of this.need) {
      this.addTile(n[1], n[2], px, pz);
    }
  }

  public refreshNeed(px: number, pz: number): void {
    const R = this.ahead * 160 + 80;
    const g0x = Math.max(0, Math.floor((px - 2000 - R) / TILE));
    const g1x = Math.floor((px - 2000 + R) / TILE);
    const g0z = Math.floor((pz - R) / TILE);
    const g1z = Math.floor((pz + R) / TILE);
    const need: [number, number, number][] = [];

    for (let gi = g0x; gi <= g1x; gi++) {
      for (let gj = g0z; gj <= g1z; gj++) {
        const cx = 2000 + (gi + 0.5) * TILE;
        const cz = (gj + 0.5) * TILE;
        const d = Math.hypot(cx - px, cz - pz);
        if (d > R + TILE * 0.7 || !this.hf.near(cx, cz, 320)) continue;
        need.push([d, gi, gj]);
      }
    }
    need.sort((a, b) => a[0] - b[0]);
    this.need = need;

    for (const [k, t] of this.tmap) {
      if (Math.hypot(t.cx - px, t.cz - pz) > R + TILE * 1.6) {
        this.scene.remove(t.group);
        t.dispose();
        this.tmap.delete(k);
      }
    }
  }

  public update(row: number, px: number, pz: number): void {
    this.hf.ensureIndex(row + 450);
    const c0 = Math.floor(row / CHUNK_ROWS);

    for (const [c, ch] of this.rmap) {
      if (c < c0 - 2 || c > c0 + this.ahead + 1) {
        this.scene.remove(ch.group);
        ch.dispose();
        this.rmap.delete(c);
      }
    }

    for (let c = Math.max(0, c0 - 1); c <= c0 + this.ahead; c++) {
      if (!this.rmap.has(c)) {
        this.addRibbon(c);
        break;
      }
    }

    if (this.tick++ % 10 === 0) this.refreshNeed(px, pz);

    for (const n of this.need) {
      const k = n[1] + ',' + n[2];
      if (!this.tmap.has(k)) {
        this.addTile(n[1], n[2], px, pz);
        break;
      }
    }
  }

  private addRibbon(c: number): void {
    if (this.rmap.has(c)) return;
    const ch = this.buildRibbon(c);
    this.scene.add(ch.group);
    this.rmap.set(c, ch);
  }

  private addTile(gi: number, gj: number, px: number, pz: number): void {
    const k = gi + ',' + gj;
    if (this.tmap.has(k)) return;
    const cx = 2000 + (gi + 0.5) * TILE;
    const cz = (gj + 0.5) * TILE;
    const dist = Math.hypot(cx - px, cz - pz);

    // Dynamic LOD selection
    const lod0Threshold = 320 * this.lodScale;
    const lod1Threshold = 600 * this.lodScale;
    const lod = dist < lod0Threshold ? 0 : dist < lod1Threshold ? 1 : 2;

    const t = this.buildTile(gi, gj, lod);
    if (t) {
      this.scene.add(t.group);
      this.tmap.set(k, t);
    }
  }

  private buildRibbon(c: number): RibbonChunk {
    const N = CHUNK_ROWS;
    const road = this.road;
    const group = new THREE.Group();
    const geos: THREE.BufferGeometry[] = [];
    const inst_: THREE.InstancedMesh[] = [];

    road.ensure((c + 1) * N + 1);

    const RV = 10;
    const rpos = new Float32Array((N + 1) * RV * 3);
    const rcol = new Float32Array((N + 1) * RV * 3);
    const ruv = new Float32Array((N + 1) * RV * 2);
    const ri: number[] = [];

    for (let r = 0; r <= N; r++) {
      const i = c * N + r;
      const hd = road.h[i];
      const cx = Math.cos(hd);
      const cz = -Math.sin(hd);
      const hw = road.w[i];
      const sty = road.sty[i];
      const y = road.y[i] - 0.03;
      const m = sty === 2 ? 0.3 : 0.1;

      let A = C.ASPH;
      let Ln = C.LINE;
      let mid = hw >= 2.9 && i % 8 < 4 ? C.LINE : A;
      if (sty === 1) {
        A = Ln = mid = GRAV;
      } else if (sty === 2) {
        mid = YEL;
      }

      const offs = [-hw, -hw + 0.2, -hw + 0.2, -m, -m, m, m, hw - 0.2, hw - 0.2, hw];
      const cs = [Ln, Ln, A, A, mid, mid, A, A, Ln, Ln];

      for (let k = 0; k < RV; k++) {
        const v = r * RV + k;
        rpos[v * 3] = road.x[i] + cx * offs[k];
        rpos[v * 3 + 1] = y;
        rpos[v * 3 + 2] = road.z[i] + cz * offs[k];
        rcol[v * 3] = cs[k].r;
        rcol[v * 3 + 1] = cs[k].g;
        rcol[v * 3 + 2] = cs[k].b;
        ruv[v * 2] = offs[k] / 3;
        ruv[v * 2 + 1] = (i * 4) / 3;
      }
    }

    for (let r = 0; r < N; r++) {
      for (const k of [0, 2, 4, 6, 8]) {
        const a = r * RV + k;
        const b = a + 1;
        const c2 = a + RV;
        const d = c2 + 1;
        ri.push(a, c2, b, b, c2, d);
      }
    }

    const rg = new THREE.BufferGeometry();
    rg.setAttribute('position', new THREE.BufferAttribute(rpos, 3));
    rg.setAttribute('color', new THREE.BufferAttribute(rcol, 3));
    rg.setAttribute('uv', new THREE.BufferAttribute(ruv, 2));
    rg.setIndex(ri);
    rg.computeVertexNormals();

    geos.push(rg);
    const rm = new THREE.Mesh(rg, roadMat);
    rm.receiveShadow = true;
    group.add(rm);

    // Roadside safety posts with reflectors
    const ps = inst(group, postGeo, postMat, 40);
    inst_.push(ps);
    for (let r = 0; r < N; r++) {
      const i = c * N + r;
      if (i % 6 !== 0 || road.sty[i] === 1) continue;
      const hd = road.h[i];
      const hw = road.w[i] + 1.1;
      for (const sd of [-1, 1]) {
        put(
          ps,
          road.x[i] + Math.cos(hd) * hw * sd,
          road.y[i] + 0.35,
          road.z[i] - Math.sin(hd) * hw * sd,
          1,
          1,
          1,
          0,
          1,
          1,
          1
        );
      }
    }
    done(ps);

    return {
      group,
      dispose: () => {
        geos.forEach((g) => g.dispose());
        inst_.forEach((m) => m.dispose());
      },
    };
  }

  private buildTile(gi: number, gj: number, lod: number): GroundTile | null {
    const hf = this.hf;
    const road = this.road;
    const seed = this.seed;
    const x0 = 2000 + gi * TILE;
    const z0 = gj * TILE;

    // Segment count scaled by LOD:
    // LOD 0: 24x24 (smooth & sharp high fidelity, 3x faster than 40x40)
    // LOD 1: 14x14 (clean mid distance)
    // LOD 2: 8x8 (far background mountain silhouette)
    const TC = lod === 0 ? 24 : lod === 1 ? 14 : 8;
    const s = TILE / TC;
    const n = TC + 1;
    const M = n + 2;
    const group = new THREE.Group();
    const geos: THREE.BufferGeometry[] = [];
    const inst_: THREE.InstancedMesh[] = [];

    const Hm = new Float32Array(M * M);
    const Dm = new Float32Array(M * M);
    const Im = new Int32Array(M * M);
    let any = false;
    let last = 0;

    for (let jj = -1; jj <= n; jj++) {
      for (let ii = -1; ii <= n; ii++) {
        const k = (jj + 1) * M + ii + 1;
        const y = hf.heightAt(x0 + ii * s, z0 + jj * s);
        if (isFinite(y)) {
          any = true;
          Hm[k] = y;
          Dm[k] = hf.q.d;
          Im[k] = hf.q.i;
          last = y;
        } else {
          Hm[k] = NaN;
          Dm[k] = 999;
          Im[k] = -1;
        }
      }
    }

    if (!any) return null;
    for (let k = 0; k < M * M; k++) {
      if (!isFinite(Hm[k])) Hm[k] = last - 120;
    }

    const V = n * n;
    const pos = new Float32Array(V * 3);
    const nor = new Float32Array(V * 3);
    const uv = new Float32Array(V * 2);
    const cl = new Float32Array(V * 3);
    const idx = new Uint32Array(TC * TC * 6);

    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        const v = j * n + i;
        const k = (j + 1) * M + i + 1;
        const x = x0 + i * s;
        const z = z0 + j * s;
        const y = Hm[k];
        const nx = (Hm[k - 1] - Hm[k + 1]) / (2 * s);
        const nz = (Hm[k - M] - Hm[k + M]) / (2 * s);
        const nl = Math.hypot(nx, 1, nz);
        const ny = 1 / nl;
        const alt = y + BASE_ALT;
        const d = Dm[k];
        const ri = Im[k];

        pos[v * 3] = x;
        pos[v * 3 + 1] = y;
        pos[v * 3 + 2] = z;
        nor[v * 3] = nx / nl;
        nor[v * 3 + 1] = ny;
        nor[v * 3 + 2] = nz / nl;
        uv[v * 2] = x / 9;
        uv[v * 2 + 1] = z / 9;

        // Lush green Himalayan hills and tea gardens
        cc.copy(C.GA).lerp(C.GB, fbm2(seed + 61, x / 60, z / 60, 2));
        cc.lerp(C.GC, sstep(0.45, 0.75, fbm2(seed + 62, x / 25, z / 25, 2)) * 0.55);
        cc.lerp(C.PADDY, sstep(0.4, 0.65, fbm2(seed + 63, x / 80, z / 80, 2)) * 0.35);

        // Only steep cliffs (slopes > 57 deg) or high snow lines get rock
        const cliffRock = sstep(0.55, 0.35, ny);
        const alpineRock = sstep(2900, 3400, alt) * 0.7;
        cc.lerp(C.ROCK, Math.max(cliffRock, alpineRock));

        if (ri >= 0) {
          const hw = road.w[ri];
          if (d < hw + 2.5) cc.lerp(road.sty[ri] === 1 ? GRAV : C.GRAVEL, 0.65);
          else if (d < hw + 5) cc.lerp(C.GRAVEL, 0.2);
        }

        cl[v * 3] = cc.r;
        cl[v * 3 + 1] = cc.g;
        cl[v * 3 + 2] = cc.b;
      }
    }

    let q = 0;
    for (let j = 0; j < TC; j++) {
      for (let i = 0; i < TC; i++) {
        const a = j * n + i;
        const b = a + 1;
        const c2 = a + n;
        const d = c2 + 1;
        idx[q++] = a;
        idx[q++] = c2;
        idx[q++] = b;
        idx[q++] = b;
        idx[q++] = c2;
        idx[q++] = d;
      }
    }

    const tg = new THREE.BufferGeometry();
    tg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    tg.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    tg.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    tg.setAttribute('color', new THREE.BufferAttribute(cl, 3));
    tg.setIndex(new THREE.BufferAttribute(idx, 1));

    geos.push(tg);
    const tm = new THREE.Mesh(tg, groundMat);
    tm.receiveShadow = true;
    group.add(tm);

    // Vegetation scaling by LOD
    if (lod < 2) {
      const rng = mulberry32(seed * 31 + gi * 7919 + gj * 104729);
      const vegFactor = this.veg * (lod === 0 ? 1.0 : 0.4);
      const T0 = Math.floor(75 * vegFactor);
      const B0 = Math.floor(45 * vegFactor);
      const G0 = lod === 0 ? Math.floor(80 * vegFactor) : 0; // Skip grass on LOD 1 & 2 for huge FPS boost

      const mk = (geo: THREE.BufferGeometry, mat: THREE.Material, max: number, sh = false) => {
        const m = inst(group, geo, mat, max, sh && lod === 0);
        inst_.push(m);
        return m;
      };

      const flat = (x: number, z: number, y: number) =>
        Math.abs(hf.heightAt(x + 4, z) - y) < 4.4 && Math.abs(hf.heightAt(x, z + 4) - y) < 4.4;

      const pm = mk(pineGeo, treeMat, T0, true);
      const cm = mk(cedarGeo, treeMat, T0, true);
      const lm = mk(leafGeo, treeMat, T0, true);
      const bm = mk(bushGeo, bushMat, B0, false);
      const gm = G0 > 0 ? mk(grassGeo, grassMat, G0, false) : null;
      const rk = mk(rockGeo, rockMat, 10, false);

      for (let t = 0; t < T0; t++) {
        const x = x0 + rng() * TILE;
        const z = z0 + rng() * TILE;
        const sc = 0.7 + rng() * 0.9;
        const h = rng();
        const ry = rng() * 6.28;
        const pick = rng();
        const y = hf.heightAt(x, z);
        if (!isFinite(y)) continue;
        const d = hf.q.d;
        const ri = hf.q.i;
        const alt = y + BASE_ALT;

        if (
          d < road.w[ri] + 2.5 ||
          d > 200 ||
          rng() > 0.35 + 0.65 * sstep(250, 700, alt) ||
          fbm2(seed + 51, x / 200, z / 200, 2) < 0.4 ||
          (road.yz[ri] > 0.3 && d < 16) ||
          !flat(x, z, y)
        )
          continue;

        const pp = sstep(1000, 1800, alt);
        const k = 0.8 + 0.4 * h;
        put(
          pick < 0.45 * pp ? pm : pick < 0.8 * pp ? cm : lm,
          x,
          y - 0.1,
          z,
          sc,
          sc * (0.85 + h * 0.5),
          sc,
          ry,
          k,
          k * 0.95,
          k * 0.85
        );
      }

      for (let t = 0; t < B0; t++) {
        const x = x0 + rng() * TILE;
        const z = z0 + rng() * TILE;
        const sc = 0.6 + rng() * 1.1;
        const g = 0.7 + rng() * 0.6;
        const y = hf.heightAt(x, z);
        if (!isFinite(y)) continue;
        const d = hf.q.d;
        const ri = hf.q.i;
        if (
          d < road.w[ri] + 1.2 ||
          d > 200 ||
          fbm2(seed + 52, x / 120, z / 120, 2) < 0.33 ||
          (road.yz[ri] > 0.3 && d < 12) ||
          !flat(x, z, y)
        )
          continue;
        put(bm, x, y - 0.05, z, sc, sc, sc, rng() * 6, g * 0.8, g, g * 0.7);
      }

      if (gm && G0 > 0) {
        for (let t = 0; t < G0; t++) {
          const x = x0 + rng() * TILE;
          const z = z0 + rng() * TILE;
          const sc = 0.8 + rng() * 0.9;
          const g = 0.75 + rng() * 0.5;
          const y = hf.heightAt(x, z);
          if (!isFinite(y)) continue;
          const d = hf.q.d;
          const ri = hf.q.i;
          const hw = road.w[ri];
          if (d < hw + 0.7 || d > hw + 36 || (road.yz[ri] > 0.3 && d < 10)) continue;
          put(gm, x, y - 0.02, z, sc, sc, sc, rng() * 6, g, g, g * 0.85);
        }
      }

      for (let t = 0; t < 12; t++) {
        const x = x0 + rng() * TILE;
        const z = z0 + rng() * TILE;
        const sc = 0.5 + rng() * rng() * 2.8;
        const g = 0.75 + rng() * 0.4;
        const y = hf.heightAt(x, z);
        if (!isFinite(y)) continue;
        if (hf.q.d < road.w[hf.q.i] + 1.5 + sc * 1.3 || hf.q.d > 120) continue;
        put(rk, x, y + sc * 0.1, z, sc, sc, sc, rng() * 6.28, g, g, g);
      }

      for (const m of inst_) done(m);
    }

    return {
      group,
      cx: x0 + TILE / 2,
      cz: z0 + TILE / 2,
      lod,
      dispose: () => {
        geos.forEach((g) => g.dispose());
        inst_.forEach((m) => m.dispose());
      },
    };
  }
}
