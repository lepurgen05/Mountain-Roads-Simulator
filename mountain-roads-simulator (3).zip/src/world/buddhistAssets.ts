/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

export interface BuddhistAssetsWorldInterface {
  hAt(x: number, z: number): number;
  roadDist(x: number, z: number): number;
}

export class BuddhistAssets {
  public group: THREE.Group;
  public lanterns: THREE.PointLight[] = [];

  constructor(scene: THREE.Scene, world: BuddhistAssetsWorldInterface) {
    this.group = new THREE.Group();
    this.buildRoadsideAssets(world);
    scene.add(this.group);
  }

  private buildRoadsideAssets(world: BuddhistAssetsWorldInterface): void {
    // Shared materials
    const matWhiteStucco = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.88,
    });
    const matPlinthStone = new THREE.MeshStandardMaterial({
      color: 0x64748b,
      roughness: 0.92,
    });
    const matManiSlate = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.95,
    });
    const matGoldTrim = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.35,
      metalness: 0.8,
    });
    const matCrimsonTrim = new THREE.MeshStandardMaterial({
      color: 0x991b1b,
      roughness: 0.75,
    });
    const matTimber = new THREE.MeshStandardMaterial({
      color: 0x3e2723,
      roughness: 0.9,
    });

    const flagColors = [0x2563eb, 0xf8fafc, 0xdc2626, 0x16a34a, 0xeab308];

    // Helper: Build a traditional Tibetan Chorten (Stupa)
    const buildChorten = (cx: number, cz: number, scale = 1.0, yaw = 0) => {
      const cy = world.hAt(cx, cz);
      const cGroup = new THREE.Group();
      cGroup.position.set(cx, cy, cz);
      cGroup.rotation.y = yaw;
      cGroup.scale.setScalar(scale);

      // 1. Stepped Plinths (4 tiers)
      const plinthHeights = [0.5, 0.4, 0.35, 0.3];
      const plinthWidths = [4.4, 3.8, 3.2, 2.7];
      let currY = 0;
      for (let p = 0; p < 4; p++) {
        const pGeo = new THREE.BoxGeometry(plinthWidths[p], plinthHeights[p], plinthWidths[p]);
        const pMesh = new THREE.Mesh(pGeo, matPlinthStone);
        pMesh.position.set(0, currY + plinthHeights[p] / 2, 0);
        pMesh.castShadow = true;
        cGroup.add(pMesh);
        currY += plinthHeights[p];
      }

      // Red band cornice
      const band = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.2, 2.8), matCrimsonTrim);
      band.position.set(0, currY + 0.1, 0);
      cGroup.add(band);
      currY += 0.2;

      // 2. Bumpa (Bell-shaped Dome)
      const bumpaGeo = new THREE.CylinderGeometry(1.0, 1.35, 2.0, 16);
      const bumpaMesh = new THREE.Mesh(bumpaGeo, matWhiteStucco);
      bumpaMesh.position.set(0, currY + 1.0, 0);
      bumpaMesh.castShadow = true;
      cGroup.add(bumpaMesh);

      // Sacred reliquary niche (Gau) on front face
      const niche = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.7, 0.2), matCrimsonTrim);
      niche.position.set(0, currY + 1.1, 1.25);
      cGroup.add(niche);
      currY += 2.0;

      // 3. Harmika Cube
      const harmikaGeo = new THREE.BoxGeometry(1.1, 0.8, 1.1);
      const harmikaMesh = new THREE.Mesh(harmikaGeo, matWhiteStucco);
      harmikaMesh.position.set(0, currY + 0.4, 0);
      cGroup.add(harmikaMesh);

      // Decorative crimson & gold rim
      const harmikaRim = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.15, 1.25), matCrimsonTrim);
      harmikaRim.position.set(0, currY + 0.8, 0);
      cGroup.add(harmikaRim);
      currY += 0.88;

      // 4. 13 Stepped Spire Cones (Stages of Enlightenment)
      const spireSteps = 10;
      for (let st = 0; st < spireSteps; st++) {
        const r = 0.55 * (1 - (st / spireSteps) * 0.75);
        const ringH = 0.18;
        const ringGeo = new THREE.CylinderGeometry(r * 0.9, r, ringH, 12);
        const ringMesh = new THREE.Mesh(ringGeo, matGoldTrim);
        ringMesh.position.set(0, currY + ringH / 2, 0);
        cGroup.add(ringMesh);
        currY += ringH;
      }

      // 5. Crescent Moon & Sun Disc Finial (Nying-je & Thab)
      const sunGeo = new THREE.SphereGeometry(0.2, 10, 8);
      const sunMesh = new THREE.Mesh(sunGeo, matGoldTrim);
      sunMesh.position.set(0, currY + 0.4, 0);
      cGroup.add(sunMesh);

      const moonGeo = new THREE.TorusGeometry(0.28, 0.06, 8, 16, Math.PI);
      const moonMesh = new THREE.Mesh(moonGeo, matGoldTrim);
      moonMesh.position.set(0, currY + 0.22, 0);
      moonMesh.rotation.z = Math.PI;
      cGroup.add(moonMesh);

      // Night butter lamp lantern
      const lamp = new THREE.PointLight(0xf59e0b, 0, 16, 1.8);
      lamp.position.set(0, 1.8, 1.6);
      cGroup.add(lamp);
      this.lanterns.push(lamp);

      this.group.add(cGroup);
    };

    // Helper: Build a roadside carved Mani Stone Wall
    const buildManiWall = (x1: number, z1: number, x2: number, z2: number) => {
      const dist = Math.hypot(x2 - x1, z2 - z1);
      const angle = Math.atan2(z2 - z1, x2 - x1);
      const midX = (x1 + x2) / 2;
      const midZ = (z1 + z2) / 2;
      const midY = world.hAt(midX, midZ);

      const wallGroup = new THREE.Group();
      wallGroup.position.set(midX, midY, midZ);
      wallGroup.rotation.y = -angle;

      // Dry stone masonry wall body
      const wallH = 1.1;
      const wallW = 1.0;
      const wallMesh = new THREE.Mesh(new THREE.BoxGeometry(dist, wallH, wallW), matPlinthStone);
      wallMesh.position.set(0, wallH / 2, 0);
      wallMesh.castShadow = true;
      wallGroup.add(wallMesh);

      // Top cap slate slabs inscribed with Om Mani Padme Hum
      const numSlates = Math.floor(dist / 1.4);
      for (let i = 0; i < numSlates; i++) {
        const sx = -dist / 2 + (i + 0.5) * (dist / numSlates);
        const slateGeo = new THREE.BoxGeometry(1.2, 0.12, 1.15);
        const slate = new THREE.Mesh(slateGeo, matManiSlate);
        slate.position.set(sx, wallH + 0.06, (Math.random() - 0.5) * 0.05);
        slate.rotation.y = (Math.random() - 0.5) * 0.15;
        slate.rotation.z = (Math.random() - 0.5) * 0.06;
        wallGroup.add(slate);

        // Individual vertical Mani stone uprights leaning against the wall
        if (i % 2 === 0) {
          const upright = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.6, 0.08), matWhiteStucco);
          upright.position.set(sx, wallH + 0.35, 0);
          upright.rotation.x = 0.2;
          wallGroup.add(upright);
        }
      }

      this.group.add(wallGroup);
    };

    // Helper: Roadside 5-color Prayer Flag Poles (Lungta / Darchor)
    const buildPrayerPoleCluster = (px: number, pz: number, numPoles = 3) => {
      const py = world.hAt(px, pz);
      const cluster = new THREE.Group();
      cluster.position.set(px, py, pz);

      for (let i = 0; i < numPoles; i++) {
        const ox = (i - (numPoles - 1) / 2) * 1.6;
        const oz = (Math.random() - 0.5) * 1.2;
        const poleH = 7.5 + Math.random() * 2.5;

        // Timber pole
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, poleH, 8), matTimber);
        pole.position.set(ox, poleH / 2, oz);
        pole.rotation.z = (Math.random() - 0.5) * 0.08;
        cluster.add(pole);

        // Vertical white prayer flag banner
        const banner = new THREE.Mesh(
          new THREE.PlaneGeometry(0.8, poleH * 0.72),
          new THREE.MeshStandardMaterial({ color: 0xf8fafc, side: THREE.DoubleSide })
        );
        banner.position.set(ox + 0.42, poleH * 0.62, oz);
        cluster.add(banner);

        // Small 5-color streamers on top
        for (let fi = 0; fi < 5; fi++) {
          const streamer = new THREE.Mesh(
            new THREE.PlaneGeometry(0.35, 0.25),
            new THREE.MeshStandardMaterial({
              color: flagColors[fi],
              side: THREE.DoubleSide,
            })
          );
          streamer.position.set(ox + 0.2, poleH - 0.3 - fi * 0.3, oz);
          cluster.add(streamer);
        }
      }

      this.group.add(cluster);
    };

    // Helper: Catenary String of Prayer Flags across two anchor points
    const buildRoadsideSwag = (p1: THREE.Vector3, p2: THREE.Vector3) => {
      const count = 16;
      for (let i = 0; i < count; i++) {
        const t = (i + 0.5) / count;
        const pos = new THREE.Vector3().lerpVectors(p1, p2, t);
        pos.y -= Math.sin(t * Math.PI) * 1.4; // Hanging catenary curve

        const flag = new THREE.Mesh(
          new THREE.PlaneGeometry(0.48, 0.38),
          new THREE.MeshStandardMaterial({
            color: flagColors[i % flagColors.length],
            side: THREE.DoubleSide,
            roughness: 0.9,
          })
        );
        flag.position.copy(pos);
        flag.rotation.x = 0.2;
        flag.rotation.y = Math.atan2(p2.x - p1.x, p2.z - p1.z);
        this.group.add(flag);
      }
    };

    // -------------------------------------------------------------------------
    // Place Key Himalayan Roadside Buddhist Assets across the route
    // -------------------------------------------------------------------------
    // 1. Gairigaon Village Start Viewpoint Stupa (x: 105, z: 345)
    buildChorten(105, 345, 1.25, 0.4);
    buildManiWall(98, 350, 114, 340);
    buildPrayerPoleCluster(92, 355, 4);

    // 2. Gairigaon Hilltop Monastery Gateway Stupa (x: 195, z: 310)
    buildChorten(195, 310, 1.15, -0.6);
    buildPrayerPoleCluster(190, 315, 3);

    // 3. Middle Pass Hairpin Cliffside Chorten (x: 780, z: 175)
    buildChorten(780, 175, 1.1, 1.2);
    buildManiWall(770, 180, 792, 170);

    // 4. Scenic Valley Overlook Stupa (x: 1240, z: 245)
    buildChorten(1240, 245, 1.3, -1.0);
    buildPrayerPoleCluster(1250, 240, 5);

    // 5. Rimbick Town West Gateway Stupa (x: 1445, z: 440)
    buildChorten(1445, 440, 1.35, 0.2);
    buildManiWall(1435, 448, 1455, 432);
    buildPrayerPoleCluster(1460, 430, 4);

    // 6. Rimbick Central Crossroads Stupa (x: 1720, z: 375)
    buildChorten(1720, 375, 1.1, 0.8);

    // 7. Mountain Pass Exit Border Stupa (x: 1965, z: 385)
    buildChorten(1965, 385, 1.4, -0.4);
    buildPrayerPoleCluster(1975, 395, 5);

    // Roadside Prayer flag swags across mountain curves
    buildRoadsideSwag(
      new THREE.Vector3(105, world.hAt(105, 345) + 4.5, 345),
      new THREE.Vector3(92, world.hAt(92, 355) + 6.5, 355)
    );
    buildRoadsideSwag(
      new THREE.Vector3(1240, world.hAt(1240, 245) + 4.8, 245),
      new THREE.Vector3(1250, world.hAt(1250, 240) + 6.8, 240)
    );
    buildRoadsideSwag(
      new THREE.Vector3(1445, world.hAt(1445, 440) + 5.0, 440),
      new THREE.Vector3(1460, world.hAt(1460, 430) + 7.0, 430)
    );
  }

  public update(nightFactor: number): void {
    // Nocturnal warm amber glow at roadside shrines
    const lampIntensity = nightFactor > 0.1 ? nightFactor * 25 : 0;
    for (const lt of this.lanterns) {
      lt.intensity = lampIntensity;
    }
  }
}
