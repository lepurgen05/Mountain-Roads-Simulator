/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { tunnelMat, tunnelPortalMat, paint, postGeo, postMat, inst, put, done } from '../core/assets.ts';
import { canvasTex } from '../core/textures.ts';
import { TunnelDef } from '../types.ts';

export class TunnelPass {
  public group: THREE.Group;
  public defs: TunnelDef[] = [];
  public lights: THREE.PointLight[] = [];

  constructor(scene: THREE.Scene) {
    this.group = new THREE.Group();
    scene.add(this.group);
  }

  public clear(): void {
    while (this.group.children.length > 0) {
      const obj = this.group.children[0];
      this.group.remove(obj);
      if ((obj as THREE.Mesh).geometry) (obj as THREE.Mesh).geometry.dispose();
    }
    this.defs = [];
    this.lights = [];
  }

  /**
   * Builds an authentic arched Himalayan mountain tunnel.
   */
  public addTunnel(
    name: string,
    road: { x: number[]; z: number[]; h: number[]; y: number[]; w: number[] },
    startRow: number,
    endRow: number
  ): TunnelDef {
    const N = endRow - startRow;
    const len = N * 4; // DS = 4m

    // Portal coordinates
    const sH = road.h[startRow];
    const eH = road.h[endRow];
    const def: TunnelDef = {
      startRow,
      endRow,
      length: len,
      name,
      portalStart: { x: road.x[startRow], y: road.y[startRow], z: road.z[startRow], yaw: sH },
      portalEnd: { x: road.x[endRow], y: road.y[endRow], z: road.z[endRow], yaw: eH },
    };
    this.defs.push(def);

    // Build Vaulted Tunnel Geometry along road path
    // Semicircular arched cross-section: 12 segments
    const SEGS = 12;
    const vertices: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];

    for (let r = 0; r <= N; r++) {
      const i = startRow + r;
      const hd = road.h[i];
      const cx = Math.cos(hd);
      const cz = -Math.sin(hd);
      const hw = road.w[i] + 0.8;
      const archH = 4.8;
      const rx = road.x[i];
      const ry = road.y[i] - 0.05;
      const rz = road.z[i];

      for (let s = 0; s <= SEGS; s++) {
        const theta = (s / SEGS) * Math.PI; // 0 to PI
        const offX = Math.cos(theta) * hw;
        const offY = Math.sin(theta) * archH;

        const vx = rx + cx * offX;
        const vy = ry + offY;
        const vz = rz + cz * offX;

        vertices.push(vx, vy, vz);
        uvs.push(s / SEGS, (r * 4) / 8);
      }
    }

    for (let r = 0; r < N; r++) {
      for (let s = 0; s < SEGS; s++) {
        const a = r * (SEGS + 1) + s;
        const b = a + 1;
        const c = (r + 1) * (SEGS + 1) + s;
        const d = c + 1;
        // Inner wall facing inward (DoubleSide material also ensures visibility)
        indices.push(a, b, c);
        indices.push(b, d, c);
      }
    }

    const tunnelGeo = new THREE.BufferGeometry();
    tunnelGeo.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    tunnelGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    tunnelGeo.setIndex(indices);
    tunnelGeo.computeVertexNormals();

    const tunnelMesh = new THREE.Mesh(tunnelGeo, tunnelMat);
    tunnelMesh.receiveShadow = true;
    tunnelMesh.castShadow = false;
    this.group.add(tunnelMesh);

    // Build Entrance and Exit Portals (Massive Stone / Concrete Arches)
    this.buildPortal(road, startRow, true, name);
    this.buildPortal(road, endRow, false, name);

    // Add Sodium Tunnel Ceiling Lights every 20 meters
    for (let r = 3; r < N; r += 5) {
      const i = startRow + r;
      const rx = road.x[i];
      const ry = road.y[i] + 4.2;
      const rz = road.z[i];

      const lamp = new THREE.PointLight(0xffa834, 1.8, 22, 1.5);
      lamp.position.set(rx, ry, rz);
      this.group.add(lamp);
      this.lights.push(lamp);

      // Visual luminaire fixture
      const fixture = new THREE.Mesh(
        new THREE.BoxGeometry(0.35, 0.12, 0.9),
        new THREE.MeshBasicMaterial({ color: 0xffd277 })
      );
      fixture.position.set(rx, ry + 0.1, rz);
      this.group.add(fixture);
    }

    return def;
  }

  private buildPortal(
    road: { x: number[]; z: number[]; h: number[]; y: number[]; w: number[] },
    row: number,
    isEntry: boolean,
    name: string
  ): void {
    const hd = road.h[row];
    const yaw = isEntry ? hd : hd + Math.PI;
    const x = road.x[row];
    const y = road.y[row];
    const z = road.z[row];
    const hw = road.w[row] + 1.2;

    const portal = new THREE.Group();
    portal.position.set(x, y, z);
    portal.rotation.y = yaw;

    // Arch portal frame (extruded masonry arch)
    const archShape = new THREE.Shape();
    const pw = hw + 2.5;
    const ph = 6.2;
    // Outer arch rectangle
    archShape.moveTo(-pw, 0);
    archShape.lineTo(pw, 0);
    archShape.lineTo(pw, ph);
    archShape.lineTo(-pw, ph);
    archShape.closePath();

    // Inner arch hole (cutout)
    const holePath = new THREE.Path();
    const innerW = hw;
    const innerH = 4.8;
    holePath.moveTo(-innerW, 0);
    holePath.lineTo(innerW, 0);
    holePath.lineTo(innerW, innerH * 0.4);
    holePath.absarc(0, innerH * 0.4, innerW, 0, Math.PI, false);
    holePath.lineTo(-innerW, 0);
    holePath.closePath();
    archShape.holes.push(holePath);

    const portalGeo = new THREE.ExtrudeGeometry(archShape, {
      depth: 2.5,
      bevelEnabled: true,
      bevelThickness: 0.35,
      bevelSize: 0.35,
      bevelSegments: 2,
    });
    portalGeo.translate(0, 0, -1.25);

    const portalMesh = new THREE.Mesh(portalGeo, tunnelPortalMat);
    portalMesh.castShadow = true;
    portalMesh.receiveShadow = true;
    portal.add(portalMesh);

    // Signboard above portal
    const signTex = canvasTex(
      `\u25c0 ${name.toUpperCase()} \u25b6`,
      1024,
      160,
      '#1a2a3a',
      '#f0ad4e',
      'bold 54px Arial'
    );
    const sign = new THREE.Mesh(
      new THREE.PlaneGeometry(hw * 1.8, 0.8),
      new THREE.MeshBasicMaterial({ map: signTex })
    );
    sign.position.set(0, 5.4, 1.35);
    portal.add(sign);

    this.group.add(portal);
  }

  public isInside(row: number): boolean {
    for (const d of this.defs) {
      if (row >= d.startRow && row <= d.endRow) return true;
    }
    return false;
  }
}
