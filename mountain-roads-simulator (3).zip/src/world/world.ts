/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { Village, VILLAGE_ELEV } from './village.ts';
import { ZONES, CYCLE, DS, Road } from './road.ts';
import { Heightfield } from './heightfield.ts';
import { ChunkManager } from './chunks.ts';
import { Traffic, VillageTraffic } from './traffic.ts';
import { TunnelPass } from './tunnel.ts';
import { VILLAGE as V } from '../data/village.ts';
import { buildModel } from '../vehicle/model.ts';
import { VEHICLES } from '../vehicle/definitions.ts';
import { mulberry32 } from '../core/noise.ts';
import { Vehicle } from '../vehicle/vehicle.ts';
import { GameSettings, RoadSampleState } from '../types.ts';
import { FuelStationManager } from './fuelStations.ts';
import { Monastery } from './monastery.ts';
import { BuddhistAssets } from './buddhistAssets.ts';
import { KanchenjungaMassif } from './kanchenjunga.ts';

export class World {
  public scene: THREE.Scene;
  public s: GameSettings;
  public village: Village;
  public traffic: Traffic;
  public vtraffic: VillageTraffic;
  public tunnelPass: TunnelPass;
  public fuelManager: FuelStationManager;
  public monastery: Monastery;
  public buddhistAssets: BuddhistAssets;
  public kanchenjunga: KanchenjungaMassif;
  public chunks: ChunkManager | null = null;
  public seed: number | null = null;
  public dist: number = 7;
  public road!: Road;
  public hf!: Heightfield;
  public row: number = 0;

  constructor(scene: THREE.Scene, s: GameSettings) {
    this.scene = scene;
    this.s = s;
    this.village = new Village(scene, s);
    this.traffic = new Traffic(scene);
    this.vtraffic = new VillageTraffic(scene, this.village);
    this.tunnelPass = new TunnelPass(scene);
    this.fuelManager = new FuelStationManager(scene);
    this.monastery = new Monastery(scene, this.village);
    this.buddhistAssets = new BuddhistAssets(scene, this.village);
    this.kanchenjunga = new KanchenjungaMassif(scene);

    // Parked vehicles along scenic shoulders in village
    const rng = mulberry32(31);
    const keys = ['hatch800', 'thar', 'mazda', 'bus', 'hatch800', 'thar', 'mazda', 'hatch800', 'bus'];
    const cols = [0xe9e7e1, 0xb3262b, 0x2d4f8b, 0xd6a21a, 0x1f5fa8, 0x2f7a46];
    const placed: [number, number][] = [];

    for (const key of keys) {
      const sm = this.village.samples[Math.floor(rng() * this.village.samples.length)];
      if (!sm || sm[0] < 160 || sm[0] > 1980) continue;
      const off = sm[4] + 1.3 + VEHICLES[key].width / 2;
      let side = 0;
      for (const sd of rng() < 0.5 ? [1, -1] : [-1, 1]) {
        const px = sm[0] + sm[3] * off * sd;
        const pz = sm[1] - sm[2] * off * sd;
        if (
          Math.abs(this.village.hAt(px, pz) - sm[5]) < 1.2 &&
          !this.village.blocked(px, pz, 3) &&
          !placed.some((q) => Math.hypot(q[0] - px, q[1] - pz) < 8)
        ) {
          side = sd;
          placed.push([px, pz]);
          break;
        }
      }
      if (!side) continue;

      const m = buildModel(
        {
          ...VEHICLES[key],
          color: cols[Math.floor(rng() * cols.length)],
          accent: cols[Math.floor(rng() * cols.length)],
        },
        { lights: false, bake: true }
      );
      const x = sm[0] + sm[3] * off * side;
      const z = sm[1] - sm[2] * off * side;
      const yaw = Math.atan2(sm[2], sm[3]) + (side > 0 ? 0 : Math.PI);
      const fx = Math.sin(yaw);
      const fz = Math.cos(yaw);
      const lx = Math.cos(yaw);
      const lz = -Math.sin(yaw);
      const df = VEHICLES[key];
      const hb = df.wheelbase / 2;
      const ht = df.track / 2;
      const g = (a: number, b: number) => this.village.hAt(x + a, z + b);
      const hF = g(fx * hb, fz * hb);
      const hR = g(-fx * hb, -fz * hb);
      const hL = g(lx * ht, lz * ht);
      const hRt = g(-lx * ht, -lz * ht);

      m.root.position.set(x, (hF + hR + hL + hRt) / 4 + 0.05, z);
      m.root.rotation.set(
        -Math.atan2(hF - hR, df.wheelbase),
        yaw,
        Math.atan2(hL - hRt, df.track),
        'YXZ'
      );
      scene.add(m.root);
    }
  }

  public setSeed(seed: number): void {
    if (this.chunks) this.chunks.clear();
    this.tunnelPass.clear();
    this.seed = seed;

    this.road = new Road(seed, { x: 2000, z: V.exit.z, h: Math.PI / 2 });
    this.hf = new Heightfield(seed, this.road, (z) => this.village.hAt(1999.9, z));
    this.hf.setTunnelPass(this.tunnelPass);
    this.hf.ensureIndex(500);

    // Build mountain tunnels at high elevation transitions
    this.road.ensure(900);
    this.tunnelPass.addTunnel('Rimbick Pass Tunnel', this.road, 90, 140);
    this.tunnelPass.addTunnel('Kanchenjunga Ridge Tunnel', this.road, 380, 440);
    this.tunnelPass.addTunnel('Gorge Highway Tunnel', this.road, 760, 830);

    this.chunks = new ChunkManager(this.scene, this.road, this.hf, seed);
    this.chunks.ahead = this.dist;
    this.chunks.veg = this.s.vegetation / 100;
    this.chunks.lodScale = this.s.lodScale || 1.0;
    this.chunks.prewarm(0, 2000, V.exit.z);
    this.traffic.reset(this.road);
    this.fuelManager.init((x, z) => this.groundAt(x, z, { i: 0, off: 0, hw: 4, rx: 1, rz: 0 }));
  }

  public setQuality(s: GameSettings): void {
    this.s = s;
    this.dist = s.renderDistance;
    this.village.setVeg(s.vegetation / 100);
    if (this.chunks) {
      this.chunks.configure(s.renderDistance, s.vegetation, s.lodScale || 1.0);
    }
    this.traffic.setOptions(s.traffic, s.trafficDensity);
    this.vtraffic.setOptions(s.traffic, s.trafficDensity);
  }

  public blocked(x: number, z: number, m = 0): boolean {
    if (x >= 212 - m && x <= 248 + m && z >= 262 - m && z <= 288 + m) return true;
    return this.inVillage(x, z) && this.village.blocked(x, z, m);
  }

  public inVillage(x: number, z: number): boolean {
    return x < 2000 && x > -500 && z > -500 && z < 1500;
  }

  public groundAt(x: number, z: number, st: RoadSampleState): number {
    if (this.inVillage(x, z)) {
      st.dom = 0;
      st.i = 0;
      st.inTunnel = false;
      return this.village.groundAt(x, z, st);
    }
    if (st.dom !== 1) {
      st.dom = 1;
      st.i = 0;
    }
    if (!this.hf) return VILLAGE_ELEV;
    return this.hf.groundAt(x, z, st);
  }

  public constrain(v: Vehicle): void {
    if (v.st.dom === 0) {
      this.village.collide(v);
      v.x = Math.max(-480, v.x);
      v.z = Math.max(-480, Math.min(1480, v.z));
    } else if (Math.abs(v.st.off) > 230) {
      const e = v.st.off - Math.sign(v.st.off) * 230;
      v.x -= v.st.rx * e;
      v.z -= v.st.rz * e;
      v.vx *= 0.9;
      v.vz *= 0.9;
    }
  }

  public respawnPoint(v: Vehicle): { x: number; z: number; yaw: number } {
    if (v.st.dom === 1) {
      const r = this.road;
      const i = Math.max(0, v.st.i);
      const h = r.h[i];
      const fwd = Math.sin(h) * Math.sin(v.yaw) + Math.cos(h) * Math.cos(v.yaw) >= 0;
      const off = (fwd ? 1 : -1) * r.w[i] * 0.5;
      return {
        x: r.x[i] + Math.cos(h) * off,
        z: r.z[i] - Math.sin(h) * off,
        yaw: fwd ? h : h + Math.PI,
      };
    }
    return this.village.respawnPoint(v.x, v.z, v.yaw);
  }

  public nextZone(row: number, inVillage: boolean): { name: string; row: number } {
    const cur = inVillage ? -1000 : row * DS;
    const cyc = Math.floor(Math.max(0, cur) / CYCLE) * CYCLE;
    const base = cur % CYCLE;
    let z = ZONES.find((q) => q.s > base + 150);
    let s: number;
    if (z) {
      s = cyc + z.s;
    } else {
      z = ZONES[0];
      s = cyc + CYCLE + z.s;
    }
    return { name: z.name, row: Math.max(2, Math.round(s / DS)) };
  }

  public teleportRow(row: number): { x: number; z: number; yaw: number } {
    this.hf.ensureIndex(row + 470);
    const r = this.road;
    const h = r.h[row];
    const off = r.w[row] * 0.5;
    if (this.chunks) {
      this.chunks.clear();
      this.chunks.prewarm(row, r.x[row], r.z[row]);
    }
    return {
      x: r.x[row] + Math.cos(h) * off,
      z: r.z[row] - Math.sin(h) * off,
      yaw: h,
    };
  }

  public fell(v: Vehicle): boolean {
    return (
      v.st.dom === 1 &&
      !v.st.inTunnel &&
      v.y < this.road.y[v.st.i] - (v.st.sty === 1 ? 6 : 30)
    );
  }

  public step(dt: number, v: Vehicle, isDarkOrTunnel: boolean = false): void {
    this.traffic.update(dt, v, isDarkOrTunnel);
    this.traffic.collide(v);
    this.vtraffic.update(dt, v, isDarkOrTunnel);
    this.vtraffic.collide(v);
  }

  public menuStep(dt: number, v: Vehicle): void {
    this.vtraffic.update(dt, v);
  }

  public getNearestFuelStation(x: number, z: number, speedKmh: number) {
    return this.fuelManager.getNearestStation(x, z, speedKmh);
  }

  public frame(
    v: Vehicle,
    camPos: THREE.Vector3,
    dt: number = 0.016,
    nightFactor: number = 0,
    sunColor: THREE.Color = new THREE.Color(1, 1, 1)
  ): void {
    const en = v.st.dom === 1;
    this.row = en ? v.st.i : 0;
    if (this.chunks) {
      this.chunks.update(this.row, en ? v.x : 2000, en ? v.z : V.exit.z);
    }
    this.village.update(camPos.x, camPos.z, this.dist * 160 + 80);
    this.fuelManager.update(v.isRefueling, v.refuelProgress);
    this.monastery.update(dt, nightFactor);
    this.buddhistAssets.update(nightFactor);
    this.kanchenjunga.update(camPos.x, camPos.z, sunColor, nightFactor);
  }
}
