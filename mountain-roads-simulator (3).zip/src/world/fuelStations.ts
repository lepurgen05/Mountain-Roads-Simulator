/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { FuelStation } from '../types.ts';
import { canvasTex } from '../core/assets.ts';

export const FUEL_STATIONS: FuelStation[] = [
  {
    id: 'gairigaon_depot',
    name: 'Gairigaon Hill Fuel Depot',
    locationName: 'Gairigaon (Pushpa Store)',
    x: 136,
    y: 0, // dynamically placed on ground
    z: 374,
    yaw: -Math.PI / 2,
    radius: 9.5,
    pricePerLiter: 97.4,
    fuelType: 'Petrol & Diesel',
  },
  {
    id: 'rimbick_pump',
    name: 'Indian Oil - Rimbick Auto Fuels',
    locationName: 'Rimbick Bazaar',
    x: 1448,
    y: 0,
    z: 494,
    yaw: 0.12,
    radius: 12.0,
    pricePerLiter: 96.8,
    fuelType: 'Petrol & Diesel',
  },
  {
    id: 'highway_oasis',
    name: 'Bharat Petroleum - Sukhia Oasis',
    locationName: 'Endless Mountain Highway',
    x: 3500,
    y: 0,
    z: 524,
    yaw: 0,
    radius: 14.0,
    pricePerLiter: 94.6,
    fuelType: 'Petrol & Diesel',
  },
];

export interface FuelStationModel {
  root: THREE.Group;
  station: FuelStation;
  nozzleGroup?: THREE.Group;
  flowLight?: THREE.PointLight;
  pumpScreens?: THREE.Mesh[];
  setPumpingState: (isPumping: boolean, progress: number) => void;
}

export class FuelStationManager {
  private scene: THREE.Scene;
  private stationModels: FuelStationModel[] = [];
  public stations: FuelStation[] = FUEL_STATIONS;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  public init(groundAt: (x: number, z: number) => number): void {
    // Clear existing
    this.dispose();

    for (const station of this.stations) {
      const y = groundAt(station.x, station.z);
      station.y = y;
      const model = this.buildStationMesh(station);
      this.scene.add(model.root);
      this.stationModels.push(model);
    }
  }

  public getNearestStation(
    x: number,
    z: number,
    speedKmh: number
  ): { station: FuelStation; distance: number; inBay: boolean; model: FuelStationModel } | null {
    let nearest: FuelStationModel | null = null;
    let minD = 1e9;

    for (const sm of this.stationModels) {
      const d = Math.hypot(x - sm.station.x, z - sm.station.z);
      if (d < minD) {
        minD = d;
        nearest = sm;
      }
    }

    if (!nearest) return null;

    const inBay = minD <= nearest.station.radius && Math.abs(speedKmh) < 6.0;

    return {
      station: nearest.station,
      distance: minD,
      inBay,
      model: nearest,
    };
  }

  public update(isRefueling: boolean, refuelProgress: number, activeStationId?: string): void {
    for (const sm of this.stationModels) {
      const isActive = isRefueling && sm.station.id === activeStationId;
      sm.setPumpingState(isActive, refuelProgress);
    }
  }

  private buildStationMesh(station: FuelStation): FuelStationModel {
    const root = new THREE.Group();
    root.position.set(station.x, station.y, station.z);
    root.rotation.y = station.yaw;

    const isDepot = station.id === 'gairigaon_depot';

    // Materials
    const concreteMat = new THREE.MeshStandardMaterial({
      color: 0x4a4d52,
      roughness: 0.9,
    });
    const yellowCurbMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.6,
    });
    const canopyRoofMat = new THREE.MeshStandardMaterial({
      color: isDepot ? 0x8b5a2b : 0x0f2d59,
      roughness: 0.4,
      metalness: 0.2,
    });
    const orangeStripeMat = new THREE.MeshStandardMaterial({
      color: 0xf97316,
      roughness: 0.3,
    });
    const whiteMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.5,
    });
    const steelMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.8,
      roughness: 0.3,
    });
    const hoseMat = new THREE.MeshStandardMaterial({
      color: 0x111827,
      roughness: 0.9,
    });
    const screenLitMat = new THREE.MeshBasicMaterial({
      color: 0x22d3ee,
    });

    const pumpScreens: THREE.Mesh[] = [];

    if (isDepot) {
      // === GAIRIGAON ROADSIDE FUEL DEPOT (Rustic Himalayan Barrels & Mobile Pump) ===
      // Wood-and-tin sheltered platform
      const basePlatform = new THREE.Mesh(new THREE.BoxGeometry(7, 0.25, 4.5), concreteMat);
      basePlatform.position.set(0, 0.125, 0);
      basePlatform.receiveShadow = true;
      root.add(basePlatform);

      // Stacked 200L Diesel/Petrol drums
      const drumGeo = new THREE.CylinderGeometry(0.38, 0.38, 1.1, 14);
      const drumMats = [
        new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.5, metalness: 0.4 }), // blue
        new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.5, metalness: 0.4 }), // red
        new THREE.MeshStandardMaterial({ color: 0x047857, roughness: 0.5, metalness: 0.4 }), // green
      ];

      for (let i = 0; i < 6; i++) {
        const dMesh = new THREE.Mesh(drumGeo, drumMats[i % drumMats.length]);
        dMesh.position.set(-2.2 + (i % 3) * 0.85, 0.68, -0.9 + Math.floor(i / 3) * 0.9);
        dMesh.castShadow = true;
        root.add(dMesh);
      }

      // 2 horizontal barrels resting on rack
      const rack = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.5, 1.2), steelMat);
      rack.position.set(1.5, 0.35, -0.8);
      root.add(rack);

      for (let i = 0; i < 2; i++) {
        const hDrum = new THREE.Mesh(drumGeo, drumMats[i]);
        hDrum.rotation.z = Math.PI / 2;
        hDrum.position.set(1.1 + i * 0.8, 0.9, -0.8);
        hDrum.castShadow = true;
        root.add(hDrum);
      }

      // Hand-cranked meter dispenser unit
      const pumpBody = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.4, 0.6), orangeStripeMat);
      pumpBody.position.set(0.1, 0.825, 0.2);
      pumpBody.castShadow = true;
      root.add(pumpBody);

      // Digital / clockwork meter screen
      const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.28), screenLitMat);
      screen.position.set(0.1, 1.2, 0.51);
      root.add(screen);
      pumpScreens.push(screen);

      // Rustic corrugated tin roof awning
      const postGeo = new THREE.CylinderGeometry(0.06, 0.06, 3.2, 8);
      for (const [px, pz] of [
        [-3.2, -1.9],
        [3.2, -1.9],
        [-3.2, 1.9],
        [3.2, 1.9],
      ]) {
        const post = new THREE.Mesh(postGeo, steelMat);
        post.position.set(px, 1.6, pz);
        post.castShadow = true;
        root.add(post);
      }

      const awning = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.1, 4.6), canopyRoofMat);
      awning.position.set(0, 3.2, 0);
      awning.rotation.x = -0.08;
      awning.castShadow = true;
      root.add(awning);

      // Signboard
      const signTex = canvasTex(
        'GAIRIGAON FUEL DEPOT \u00b7 2486m',
        1024,
        256,
        '#78350f',
        '#fef08a',
        'bold 64px Arial'
      );
      const sign = new THREE.Mesh(
        new THREE.PlaneGeometry(4.8, 1.2),
        new THREE.MeshBasicMaterial({ map: signTex })
      );
      sign.position.set(0, 3.65, 2.1);
      root.add(sign);
    } else {
      // === MODERN COMMERCIAL INDIAN OIL PETROL PUMP ===
      // Raised concrete fueling island
      const island = new THREE.Mesh(new THREE.BoxGeometry(9.5, 0.3, 4.0), concreteMat);
      island.position.set(0, 0.15, 0);
      island.receiveShadow = true;
      root.add(island);

      // Yellow curb borders
      const curbGeo = new THREE.BoxGeometry(9.7, 0.34, 0.18);
      for (const cz of [-2.05, 2.05]) {
        const curb = new THREE.Mesh(curbGeo, yellowCurbMat);
        curb.position.set(0, 0.17, cz);
        root.add(curb);
      }

      // Dual digital commercial dispensers (Pump 1 & Pump 2)
      for (const px of [-2.4, 2.4]) {
        // Base plinth
        const plinth = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.2, 0.7), steelMat);
        plinth.position.set(px, 0.4, 0);
        root.add(plinth);

        // Main housing (Indian Oil blue & orange)
        const pumpBody = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.85, 0.6), whiteMat);
        pumpBody.position.set(px, 1.325, 0);
        pumpBody.castShadow = true;
        root.add(pumpBody);

        const brandBand = new THREE.Mesh(new THREE.BoxGeometry(1.02, 0.35, 0.62), orangeStripeMat);
        brandBand.position.set(px, 1.85, 0);
        root.add(brandBand);

        const navyBand = new THREE.Mesh(new THREE.BoxGeometry(1.02, 0.35, 0.62), canopyRoofMat);
        navyBand.position.set(px, 0.75, 0);
        root.add(navyBand);

        // Dual sided digital backlit meter screens
        for (const side of [-1, 1]) {
          const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.65, 0.38), screenLitMat);
          screen.position.set(px, 1.45, side * 0.315);
          if (side < 0) screen.rotation.y = Math.PI;
          root.add(screen);
          pumpScreens.push(screen);

          // Hanging hose
          const hose = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.035, 6, 12, Math.PI), hoseMat);
          hose.position.set(px + side * 0.4, 1.1, side * 0.32);
          hose.rotation.y = side > 0 ? 0 : Math.PI;
          root.add(hose);

          // Nozzle holster
          const nozzle = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.3, 0.08), steelMat);
          nozzle.position.set(px + side * 0.45, 1.35, side * 0.33);
          root.add(nozzle);
        }

        // Crash bollards on both sides of pump
        const bollardGeo = new THREE.CylinderGeometry(0.1, 0.1, 0.9, 10);
        for (const bx of [-0.85, 0.85]) {
          const bollard = new THREE.Mesh(bollardGeo, yellowCurbMat);
          bollard.position.set(px + bx, 0.75, 0);
          bollard.castShadow = true;
          root.add(bollard);
        }
      }

      // Canopy Pillars (4 structural steel pillars)
      const pillarGeo = new THREE.BoxGeometry(0.35, 4.8, 0.35);
      for (const [px, pz] of [
        [-4.2, -2.4],
        [4.2, -2.4],
        [-4.2, 2.4],
        [4.2, 2.4],
      ]) {
        const pillar = new THREE.Mesh(pillarGeo, steelMat);
        pillar.position.set(px, 2.4, pz);
        pillar.castShadow = true;
        root.add(pillar);
      }

      // Overhead Canopy Roof
      const canopy = new THREE.Mesh(new THREE.BoxGeometry(14.0, 0.8, 9.5), canopyRoofMat);
      canopy.position.set(0, 4.8, 0);
      canopy.castShadow = true;
      root.add(canopy);

      // Canopy Fascia border (Indian Oil bright orange)
      const fascia = new THREE.Mesh(new THREE.BoxGeometry(14.2, 0.35, 9.7), orangeStripeMat);
      fascia.position.set(0, 4.8, 0);
      root.add(fascia);

      // Canopy signage on front & back
      const logoTex = canvasTex(
        'INDIAN OIL \u00b7 RIMBICK AUTO FUELS',
        1024,
        160,
        '#0f2d59',
        '#f97316',
        'bold 48px Arial'
      );
      for (const sz of [-4.86, 4.86]) {
        const logoMesh = new THREE.Mesh(
          new THREE.PlaneGeometry(10.5, 0.7),
          new THREE.MeshBasicMaterial({ map: logoTex })
        );
        logoMesh.position.set(0, 4.8, sz);
        if (sz < 0) logoMesh.rotation.y = Math.PI;
        root.add(logoMesh);
      }

      // Canopy underside lamps
      for (const lx of [-3, 0, 3]) {
        const lampFixture = new THREE.Mesh(
          new THREE.BoxGeometry(1.2, 0.1, 0.6),
          new THREE.MeshBasicMaterial({ color: 0xfff7ed })
        );
        lampFixture.position.set(lx, 4.35, 0);
        root.add(lampFixture);
      }

      // High-standing Roadside Totem Sign (Pylon)
      const totem = new THREE.Group();
      totem.position.set(6.8, 0, 4.0);

      const totemPole = new THREE.Mesh(new THREE.BoxGeometry(0.3, 5.0, 0.3), steelMat);
      totemPole.position.set(0, 2.5, 0);
      totem.add(totemPole);

      const boardTex = canvasTex(
        'INDIAN OIL\nPETROL  \u20b996.80\nDIESEL  \u20b989.40',
        512,
        512,
        '#0f2d59',
        '#facc15',
        'bold 46px Arial'
      );
      const totemBoard = new THREE.Mesh(
        new THREE.PlaneGeometry(1.8, 2.2),
        new THREE.MeshBasicMaterial({ map: boardTex })
      );
      totemBoard.position.set(0, 4.2, 0.16);
      totem.add(totemBoard);
      const totemBoardBack = new THREE.Mesh(
        new THREE.PlaneGeometry(1.8, 2.2),
        new THREE.MeshBasicMaterial({ map: boardTex })
      );
      totemBoardBack.position.set(0, 4.2, -0.16);
      totemBoardBack.rotation.y = Math.PI;
      totem.add(totemBoardBack);
      root.add(totem);
    }

    // Yellow ground Refuel Bay bounding box marking
    const bayCanvas = document.createElement('canvas');
    bayCanvas.width = 512;
    bayCanvas.height = 256;
    const bctx = bayCanvas.getContext('2d')!;
    bctx.strokeStyle = '#f59e0b';
    bctx.lineWidth = 14;
    bctx.strokeRect(10, 10, 492, 236);
    bctx.fillStyle = '#f59e0b';
    bctx.font = 'bold 36px Arial';
    bctx.textAlign = 'center';
    bctx.textBaseline = 'middle';
    bctx.fillText('\u26fd REFUEL BAY \u26fd', 256, 128);

    const bayTex = new THREE.CanvasTexture(bayCanvas);
    const bayMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(isDepot ? 6.5 : 8.5, isDepot ? 4.5 : 5.0),
      new THREE.MeshBasicMaterial({
        map: bayTex,
        transparent: true,
        opacity: 0.85,
        polygonOffset: true,
        polygonOffsetFactor: -3,
        polygonOffsetUnits: -3,
      })
    );
    bayMesh.rotation.x = -Math.PI / 2;
    bayMesh.position.set(0, 0.04, 0);
    root.add(bayMesh);

    // Active Refuel Flow Light Indicator
    const flowLight = new THREE.PointLight(0xf59e0b, 0, 12);
    flowLight.position.set(0, 2.2, 0);
    root.add(flowLight);

    const setPumpingState = (isPumping: boolean, progress: number) => {
      flowLight.intensity = isPumping ? 1.8 + Math.sin(progress * 40) * 0.8 : 0;
      flowLight.color.setHex(progress >= 100 ? 0x22c55e : 0xf59e0b);

      const screenColor = isPumping
        ? (progress >= 100 ? 0x22c55e : 0xf59e0b)
        : 0x22d3ee;
      screenLitMat.color.setHex(screenColor);
    };

    return {
      root,
      station,
      flowLight,
      pumpScreens,
      setPumpingState,
    };
  }

  public dispose(): void {
    for (const sm of this.stationModels) {
      this.scene.remove(sm.root);
      sm.root.traverse((o) => {
        if ((o as THREE.Mesh).isMesh) {
          const m = o as THREE.Mesh;
          m.geometry?.dispose();
          if (Array.isArray(m.material)) m.material.forEach((mat) => mat.dispose());
          else m.material?.dispose();
        }
      });
    }
    this.stationModels = [];
  }
}
