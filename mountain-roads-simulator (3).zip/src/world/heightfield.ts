/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { fbm2, sstep } from '../core/noise.ts';
import { BASE_ALT, Road } from './road.ts';
import { RoadSampleState } from '../types.ts';
import { TunnelPass } from './tunnel.ts';

const CELL = 48;
const K = (a: number, b: number) => a * 8192 + b;

export class Heightfield {
  public seed: number;
  public road: Road;
  public seam: (z: number) => number;
  public tunnelPass: TunnelPass | null = null;
  public hash: Map<number, number[]> = new Map();
  public indexed: number = 0;
  public Mi: number[] = [];
  public sc: Map<number, number> = new Map();
  public q = { d: 0, i: 0, L: 0, M: 0 };

  constructor(seed: number, road: Road, seam: (z: number) => number) {
    this.seed = seed | 0;
    this.road = road;
    this.seam = seam;
  }

  public setTunnelPass(tp: TunnelPass): void {
    this.tunnelPass = tp;
  }

  public macro(x: number, z: number): number {
    return 140 * (fbm2(this.seed + 44, x / 900, z / 900, 3) - 0.5) * 2;
  }

  public detail(x: number, z: number): number {
    return 38 * (fbm2(this.seed + 45, x / 170, z / 170, 4) - 0.5) * 2;
  }

  public ensureIndex(n: number): void {
    const r = this.road;
    r.ensure(n);
    for (let i = this.indexed; i <= n; i++) {
      const k = K(Math.floor(r.x[i] / CELL), Math.floor(r.z[i] / CELL));
      let a = this.hash.get(k);
      if (!a) this.hash.set(k, (a = []));
      a.push(i);
      this.Mi[i] = this.macro(r.x[i], r.z[i]);
    }
    this.indexed = Math.max(this.indexed, n + 1);
  }

  public near(x: number, z: number, rad: number): boolean {
    const r = this.road;
    const c = Math.ceil(rad / CELL);
    const cx = Math.floor(x / CELL);
    const cz = Math.floor(z / CELL);
    const r2 = rad * rad;
    for (let a = -c; a <= c; a++) {
      for (let b = -c; b <= c; b++) {
        const arr = this.hash.get(K(cx + a, cz + b));
        if (arr) {
          for (let k = 0; k < arr.length; k++) {
            const i = arr[k];
            const dx = x - r.x[i];
            const dz = z - r.z[i];
            if (dx * dx + dz * dz < r2) return true;
          }
        }
      }
    }
    return false;
  }

  public query(x: number, z: number): boolean {
    const r = this.road;
    const cx = Math.floor(x / CELL);
    const cz = Math.floor(z / CELL);
    const q = this.q;
    let bd = 1e18;
    let bi = -1;
    let sw = 0;
    let sl = 0;
    let sm = 0;

    for (let a = -2; a <= 2; a++) {
      for (let b = -2; b <= 2; b++) {
        const arr = this.hash.get(K(cx + a, cz + b));
        if (!arr) continue;
        for (let k = 0; k < arr.length; k++) {
          const i = arr[k];
          const dx = x - r.x[i];
          const dz = z - r.z[i];
          const d2 = dx * dx + dz * dz;
          if (d2 < bd) {
            bd = d2;
            bi = i;
          }
          if (d2 < 14400) {
            const w = 1 / ((d2 + 16) * (d2 + 16));
            sw += w;
            sl += w * r.y[i];
            sm += w * this.Mi[i];
          }
        }
      }
    }

    if (bi < 0) {
      for (let a = -9; a <= 9; a++) {
        for (let b = -9; b <= 9; b++) {
          const arr = this.hash.get(K(cx + a, cz + b));
          if (!arr) continue;
          for (let k = 0; k < arr.length; k++) {
            const i = arr[k];
            const dx = x - r.x[i];
            const dz = z - r.z[i];
            const d2 = dx * dx + dz * dz;
            if (d2 < bd) {
              bd = d2;
              bi = i;
            }
          }
        }
      }
      if (bi < 0) return false;
    }

    q.i = bi;
    q.d = Math.sqrt(bd);
    q.L = sw > 0 ? sl / sw : r.y[bi];
    q.M = sw > 0 ? sm / sw : this.Mi[bi];
    return true;
  }

  public heightAt(x: number, z: number): number {
    return this.query(x, z) ? this.finish(x, z) : NaN;
  }

  public finish(x: number, z: number): number {
    const q = this.q;
    const r = this.road;
    const i = q.i;
    const d = q.d;
    const L = q.L;
    const M = q.M;

    // Check if within tunnel pass
    const isTunnel = this.tunnelPass ? this.tunnelPass.isInside(i) : false;

    const pf = sstep(250, 700, L + BASE_ALT) * (1 - 0.75 * r.hz[i]);
    let y = L - 0.25;

    if (isTunnel) {
      // In tunnel sections, terrain arches naturally overhead (+12m to +40m mountain ridge above road)
      // providing seamless transition without mountain cuts clipping the road!
      const mountainRidge = 16 + 22 * sstep(0, 40, d) + Math.abs(this.macro(x, z) - M) * 0.4;
      y = L + mountainRidge;
    } else {
      // Normal road section: smooth embankment that never rises above road at distance < hw
      const hw = r.w[i];
      const embankmentBlend = sstep(hw + 0.5, hw + 16, d);
      y = L - 0.25 + embankmentBlend * pf * (this.macro(x, z) - M + this.detail(x, z));

      const yz = r.yz[i];
      if (yz > 0.01) {
        const hd = r.h[i];
        const l = (x - r.x[i]) * Math.cos(hd) - (z - r.z[i]) * Math.sin(hd);
        y += yz * (-130 * sstep(hw + 10.5, hw + 24, l) + 60 * sstep(hw + 9.5, hw + 19, -l));
      }
    }

    y -= 120 * sstep(190, 270, d);

    if (x < 2400 && x >= 2000) {
      const t = 1 - sstep(0, 400, x - 2000);
      if (t > 0) y += this.edge(z) * t * sstep(5, 30, d);
    }
    return y;
  }

  public edge(z: number): number {
    const k = Math.round(z / 8);
    let v = this.sc.get(k);
    if (v !== undefined) return v;
    const q = this.q;
    const sv = [q.d, q.i, q.L, q.M];
    const zz = k * 8;
    v = 0;
    if (this.query(2000.5, zz)) {
      const p = this.q;
      const y0 =
        p.L -
        0.25 +
        sstep(14, 55, p.d) *
          sstep(250, 700, p.L + BASE_ALT) *
          (this.macro(2000.5, zz) - p.M + this.detail(2000.5, zz));
      v = this.seam(zz) - y0;
    }
    q.d = sv[0];
    q.i = sv[1];
    q.L = sv[2];
    q.M = sv[3];
    this.sc.set(k, v);
    return v;
  }

  public groundAt(x: number, z: number, st: RoadSampleState): number {
    const r = this.road;
    if (!this.query(x, z)) {
      st.off = 999;
      st.hw = 3;
      st.endless = true;
      st.inTunnel = false;
      return r.y[Math.max(0, st.i)] - 120;
    }
    const q = this.q;
    const i = q.i;
    const hd = r.h[i];
    const s = Math.sin(hd);
    const c = Math.cos(hd);
    const dx = x - r.x[i];
    const dz = z - r.z[i];
    const off = dx * c - dz * s;
    const along = dx * s + dz * c;
    const hw = r.w[i];

    const inTunnel = this.tunnelPass ? this.tunnelPass.isInside(i) : false;
    st.i = i;
    st.off = off;
    st.rx = c;
    st.rz = -s;
    st.hw = hw;
    st.sty = r.sty[i];
    st.endless = true;
    st.inTunnel = inTunnel;

    const j2 = along >= 0 ? i + 1 : Math.max(0, i - 1);
    r.ensure(j2 + 1);
    const ry = r.y[i] + (r.y[j2] - r.y[i]) * Math.min(1, Math.abs(along) / 4) - 0.03;

    if (inTunnel) {
      // Inside tunnel, car drives on road floor; ceiling is high above
      return ry;
    }

    const bl = sstep(-0.1, 0.8, Math.abs(off) - hw);
    if (bl <= 0) return ry;
    return ry + (this.finish(x, z) - ry) * bl;
  }
}
