/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

export interface MonasteryWorldInterface {
  hAt(x: number, z: number): number;
}

export class Monastery {
  public group: THREE.Group;
  public prayerWheels: THREE.Group[] = [];
  public lanterns: THREE.PointLight[] = [];
  public x: number = 230;
  public z: number = 275;
  public y: number = 0;

  constructor(scene: THREE.Scene, world: MonasteryWorldInterface) {
    this.group = new THREE.Group();
    this.x = 230;
    this.z = 275;
    this.y = world.hAt(this.x, this.z);

    this.group.position.set(this.x, this.y, this.z);
    this.buildMonastery();
    scene.add(this.group);
  }

  private buildMonastery(): void {
    // -------------------------------------------------------------------------
    // Materials
    // -------------------------------------------------------------------------
    const matStoneBase = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.88,
      metalness: 0.05,
    });
    const matCrimsonWall = new THREE.MeshStandardMaterial({
      color: 0x881337, // Authentic Tibetan monastery crimson
      roughness: 0.75,
      metalness: 0.1,
    });
    const matUpperWall = new THREE.MeshStandardMaterial({
      color: 0x9f1239,
      roughness: 0.72,
    });
    const matGoldRoof = new THREE.MeshStandardMaterial({
      color: 0xd97706, // Gilded brass / golden copper
      roughness: 0.32,
      metalness: 0.78,
    });
    const matPureGold = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.22,
      metalness: 0.9,
    });
    const matTimberDark = new THREE.MeshStandardMaterial({
      color: 0x271911,
      roughness: 0.85,
    });
    const matVermilion = new THREE.MeshStandardMaterial({
      color: 0xdc2626,
      roughness: 0.65,
    });
    const matWhiteStucco = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.9,
    });
    const matFlagColors = [0x2563eb, 0xf8fafc, 0xdc2626, 0x16a34a, 0xeab308];

    // Helper functions
    const addBox = (w: number, h: number, d: number, mat: THREE.Material, px = 0, py = 0, pz = 0) => {
      const geo = new THREE.BoxGeometry(w, h, d);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(px, py + h / 2, pz);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.group.add(mesh);
      return mesh;
    };

    // -------------------------------------------------------------------------
    // 1. Terraced Stone Courtyard & Deep Bedrock Foundation Plinth (Himalayan Dzong Ramparts)
    // -------------------------------------------------------------------------
    // Deep monolithic bedrock foundation core (extends 38m deep down into the mountainside bedrock)
    // Eliminates any floating or ground gap regardless of steep mountain slope gradients!
    addBox(44, 38, 42, matStoneBase, 0, -38, 2);

    // Multi-tiered stepped cyclopean stone ramparts terracing down the south hillside facing the valley road
    addBox(46, 14, 44, matStoneBase, 0, -14, 3);
    addBox(48, 16, 46, matStoneBase, 0, -28, 5);
    addBox(52, 18, 48, matStoneBase, 0, -44, 7);

    // 4 Massive sloping stone buttresses on the downhill cliffside face (facing +z toward the valley road)
    for (const bx of [-15, -5, 5, 15]) {
      const buttress = addBox(3.2, 28, 4.5, matStoneBase, bx, -28, 21.5);
      buttress.rotation.x = 0.12; // Inward battered authentic Dzong fortress wall slope
    }

    // Courtyard stone perimeter parapet wall (keeps courtyard defined above the mountain drop)
    addBox(42, 1.1, 0.6, matStoneBase, 0, 0, 20.8);  // Front parapet
    addBox(0.6, 1.1, 38, matStoneBase, -20.8, 0, 2); // West parapet
    addBox(0.6, 1.1, 38, matStoneBase, 20.8, 0, 2);  // East parapet
    addBox(42, 1.1, 0.6, matStoneBase, 0, 0, -16.8); // North rear parapet

    // Upper temple terrace
    addBox(32, 1.8, 28, matStoneBase, 0, 0, 0);

    // Monumental descending stone entrance stairway winding down the mountain ridge toward the road
    for (let s = 0; s < 18; s++) {
      const stepY = -s * 0.45;
      const stepZ = 20.5 + s * 0.95;
      const stepW = Math.max(7, 12 - s * 0.28);
      addBox(stepW, 0.65, 1.2, matStoneBase, 0, stepY, stepZ);
      // Flanking stone step balustrades
      addBox(0.5, 1.15, 1.2, matStoneBase, -stepW / 2 - 0.25, stepY, stepZ);
      addBox(0.5, 1.15, 1.2, matStoneBase, stepW / 2 + 0.25, stepY, stepZ);
    }

    // -------------------------------------------------------------------------
    // 2. Ground Floor Main Dukhang (Great Assembly Hall)
    // -------------------------------------------------------------------------
    const gw = 26;
    const gh = 7.5;
    const gd = 22;
    addBox(gw, gh, gd, matCrimsonWall, 0, 1.8, 0);

    // Stone plinth molding & cornice
    addBox(gw + 0.8, 0.6, gd + 0.8, matTimberDark, 0, 1.8, 0);
    addBox(gw + 1.2, 0.8, gd + 1.2, matVermilion, 0, 1.8 + gh - 0.8, 0);
    addBox(gw + 1.8, 0.4, gd + 1.8, matPureGold, 0, 1.8 + gh, 0);

    // Grand Entrance Portico (4 Red & Gold Pillars)
    const porticoW = 14;
    const porticoH = 6.2;
    const porticoD = 4.2;
    const porticoY = 1.8;
    const porticoZ = gd / 2 + porticoD / 2;

    // Portico Roof
    addBox(porticoW + 1.5, 0.5, porticoD + 1.2, matGoldRoof, 0, porticoY + porticoH, porticoZ);

    // 4 Tall vermilion columns
    const pillarPositions = [-5.2, -1.8, 1.8, 5.2];
    for (const px of pillarPositions) {
      // Base
      const baseGeo = new THREE.CylinderGeometry(0.55, 0.65, 0.6, 14);
      const baseMesh = new THREE.Mesh(baseGeo, matStoneBase);
      baseMesh.position.set(px, porticoY + 0.3, porticoZ + 1.4);
      this.group.add(baseMesh);

      // Vermilion Column Shaft
      const colGeo = new THREE.CylinderGeometry(0.42, 0.45, porticoH - 1.2, 16);
      const colMesh = new THREE.Mesh(colGeo, matVermilion);
      colMesh.position.set(px, porticoY + 0.6 + (porticoH - 1.2) / 2, porticoZ + 1.4);
      colMesh.castShadow = true;
      this.group.add(colMesh);

      // Gilded Capital
      const capGeo = new THREE.BoxGeometry(1.2, 0.6, 1.2);
      const capMesh = new THREE.Mesh(capGeo, matPureGold);
      capMesh.position.set(px, porticoY + porticoH - 0.3, porticoZ + 1.4);
      this.group.add(capMesh);
    }

    // Great Ceremonial Entry Doors (Tibetan lacquered mahogany with brass studs)
    const doorFrame = addBox(4.6, 5.0, 0.4, matTimberDark, 0, porticoY, gd / 2);
    doorFrame.castShadow = true;
    addBox(2.0, 4.6, 0.15, matVermilion, -1.1, porticoY + 0.1, gd / 2 + 0.15);
    addBox(2.0, 4.6, 0.15, matVermilion, 1.1, porticoY + 0.1, gd / 2 + 0.15);
    // Brass ring handles
    for (const dx of [-0.4, 0.4]) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.04, 10, 16), matPureGold);
      ring.position.set(dx, porticoY + 2.2, gd / 2 + 0.3);
      this.group.add(ring);
    }

    // -------------------------------------------------------------------------
    // 3. Second Floor Sanctuary (Lhakhang) & Upper Tier
    // -------------------------------------------------------------------------
    const uw = 20;
    const uh = 6.0;
    const ud = 16;
    const uy = 1.8 + gh + 0.4;
    addBox(uw, uh, ud, matUpperWall, 0, uy, -1);

    // Traditional Tibetan trapezoidal windows
    for (const wx of [-6.5, 0, 6.5]) {
      // Window frame
      addBox(2.2, 2.6, 0.3, matTimberDark, wx, uy + 1.6, -1 + ud / 2);
      // Traditional pleated white valance (shambu)
      addBox(2.4, 0.5, 0.4, matWhiteStucco, wx, uy + 3.8, -1 + ud / 2);
    }
    // Windows on sides
    for (const wz of [-5, 0, 4]) {
      for (const sx of [-1, 1]) {
        addBox(0.3, 2.2, 2.0, matTimberDark, sx * (uw / 2), uy + 1.6, wz);
      }
    }

    // -------------------------------------------------------------------------
    // 4. Sweeping Gilded Pagoda Roof (Ganjira & Eaves)
    // -------------------------------------------------------------------------
    const roofY = uy + uh;
    const roofW = uw + 4.5;
    const roofD = ud + 4.5;

    // Sloping tiered roof eaves
    const roofGeo = new THREE.ConeGeometry(roofW * 0.72, 3.2, 4);
    roofGeo.rotateY(Math.PI / 4);
    const roofMesh = new THREE.Mesh(roofGeo, matGoldRoof);
    roofMesh.position.set(0, roofY + 1.6, -1);
    roofMesh.scale.set(1.0, 1.0, (roofD / roofW));
    roofMesh.castShadow = true;
    this.group.add(roofMesh);

    // Eave trim
    addBox(roofW, 0.5, roofD, matTimberDark, 0, roofY, -1);
    addBox(roofW + 0.6, 0.25, roofD + 0.6, matPureGold, 0, roofY + 0.3, -1);

    // Top Pavilion Cupola
    const cupolaY = roofY + 3.2;
    addBox(6.5, 2.8, 6.5, matUpperWall, 0, cupolaY, -1);
    const cupRoofGeo = new THREE.ConeGeometry(5.2, 2.0, 4);
    cupRoofGeo.rotateY(Math.PI / 4);
    const cupRoof = new THREE.Mesh(cupRoofGeo, matGoldRoof);
    cupRoof.position.set(0, cupolaY + 2.8 + 1.0, -1);
    cupRoof.castShadow = true;
    this.group.add(cupRoof);

    // -------------------------------------------------------------------------
    // 5. Sacred Gilded Dharmachakra & Two Golden Deer (Roof Crest Landmark)
    // -------------------------------------------------------------------------
    const crestY = cupolaY + 4.8;
    const crestGroup = new THREE.Group();
    crestGroup.position.set(0, crestY, -1);

    // Central Dharmachakra (8-Spoked Wheel of Dharma)
    const wheelRim = new THREE.Mesh(new THREE.TorusGeometry(1.3, 0.16, 12, 32), matPureGold);
    crestGroup.add(wheelRim);
    const wheelHub = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.3, 16), matPureGold);
    wheelHub.rotation.x = Math.PI / 2;
    crestGroup.add(wheelHub);

    // 8 Spokes
    for (let sp = 0; sp < 8; sp++) {
      const ang = (sp / 8) * Math.PI;
      const spoke = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.3, 8), matPureGold);
      spoke.rotation.z = ang;
      crestGroup.add(spoke);
    }

    // Sacred Ser-tok (Victory Pinnacle Spire)
    const spireGeo = new THREE.CylinderGeometry(0.12, 0.5, 2.2, 10);
    const spire = new THREE.Mesh(spireGeo, matPureGold);
    spire.position.set(0, 1.8, 0);
    crestGroup.add(spire);

    // Two Kneeling Golden Deer (Flanking the Wheel facing inwards)
    for (const dir of [-1, 1]) {
      const deer = new THREE.Group();
      deer.position.set(dir * 2.2, -0.4, 0);
      deer.scale.set(dir * 0.75, 0.75, 0.75);

      // Body
      const bodyM = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.5, 1.4, 10), matPureGold);
      bodyM.rotation.z = Math.PI / 2;
      deer.add(bodyM);

      // Neck & Head
      const neckM = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.28, 0.9, 8), matPureGold);
      neckM.position.set(-0.5, 0.6, 0);
      neckM.rotation.z = -0.3;
      deer.add(neckM);

      const headM = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.6, 8), matPureGold);
      headM.position.set(-0.7, 1.0, 0);
      headM.rotation.z = -Math.PI / 2.5;
      deer.add(headM);

      // Antlers
      const antler = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.6, 6), matPureGold);
      antler.position.set(-0.6, 1.3, 0.1);
      antler.rotation.z = 0.3;
      deer.add(antler);

      crestGroup.add(deer);
    }
    this.group.add(crestGroup);

    // -------------------------------------------------------------------------
    // 6. Mani Khorlo Cloister (Gallery of Golden Prayer Wheels)
    // -------------------------------------------------------------------------
    // Left & Right covered perimeter colonnade with rotating prayer wheels
    const pwZ = gd / 2 + 1.2;
    for (const sx of [-1, 1]) {
      const arcadeW = 6.2;
      const arcadeH = 2.8;
      const arcadeX = sx * 9.5;

      // Canopy roof
      addBox(arcadeW, 0.3, 2.2, matGoldRoof, arcadeX, 1.8 + arcadeH, pwZ);

      // 4 Prayer wheels in each wing
      for (let wi = 0; wi < 4; wi++) {
        const wheelGroup = new THREE.Group();
        const wx = arcadeX - (arcadeW / 2) + 0.9 + wi * 1.4;
        wheelGroup.position.set(wx, 1.8 + 1.2, pwZ);

        // Cylinder drum
        const drumGeo = new THREE.CylinderGeometry(0.34, 0.34, 1.1, 16);
        const drumMesh = new THREE.Mesh(drumGeo, matPureGold);
        drumMesh.castShadow = true;
        wheelGroup.add(drumMesh);

        // Decorative Lotus top and bottom cap
        for (const ty of [-0.6, 0.6]) {
          const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.38, 0.14, 16), matVermilion);
          cap.position.set(0, ty, 0);
          wheelGroup.add(cap);
        }

        // Spindle axis
        const axis = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.8, 8), matTimberDark);
        wheelGroup.add(axis);

        this.prayerWheels.push(wheelGroup);
        this.group.add(wheelGroup);
      }
    }

    // -------------------------------------------------------------------------
    // 7. Darchor (Tall 14m White Prayer Flag Poles with Pennants)
    // -------------------------------------------------------------------------
    const flagPoles = [
      { x: -16, z: 16 },
      { x: 16, z: 16 },
      { x: -16, z: -14 },
      { x: 16, z: -14 },
    ];

    for (const fp of flagPoles) {
      // Stone plinth
      addBox(2.2, 1.2, 2.2, matStoneBase, fp.x, 0, fp.z);

      // Timber Mast
      const mastGeo = new THREE.CylinderGeometry(0.16, 0.24, 14, 10);
      const mast = new THREE.Mesh(mastGeo, matTimberDark);
      mast.position.set(fp.x, 1.2 + 7, fp.z);
      mast.castShadow = true;
      this.group.add(mast);

      // Golden Trident finial
      const topSpire = new THREE.Mesh(new THREE.ConeGeometry(0.3, 1.2, 8), matPureGold);
      topSpire.position.set(fp.x, 1.2 + 14.4, fp.z);
      this.group.add(topSpire);

      // Vertical White Prayer Flag fabric banner
      const bannerGeo = new THREE.PlaneGeometry(1.6, 11);
      const bannerMat = new THREE.MeshStandardMaterial({
        color: 0xf8fafc,
        side: THREE.DoubleSide,
        roughness: 0.9,
      });
      const banner = new THREE.Mesh(bannerGeo, bannerMat);
      banner.position.set(fp.x + 0.85, 1.2 + 8.5, fp.z);
      this.group.add(banner);

      // Colorful flag ties along the pole
      for (let ti = 0; ti < 5; ti++) {
        const tie = new THREE.Mesh(
          new THREE.CylinderGeometry(0.28, 0.28, 0.2, 8),
          new THREE.MeshStandardMaterial({ color: matFlagColors[ti] })
        );
        tie.position.set(fp.x, 1.2 + 3 + ti * 2.2, fp.z);
        this.group.add(tie);
      }
    }

    // -------------------------------------------------------------------------
    // 8. Sangbum (Incense Burner Stupa) in Front Courtyard
    // -------------------------------------------------------------------------
    const sbX = 0;
    const sbZ = 12;
    addBox(3.0, 1.0, 3.0, matStoneBase, sbX, 0, sbZ);
    const sbBase = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.3, 1.8, 12), matWhiteStucco);
    sbBase.position.set(sbX, 1.9, sbZ);
    this.group.add(sbBase);

    // Incense chamber niche
    addBox(0.8, 0.8, 0.8, matTimberDark, sbX, 1.5, sbZ + 0.6);

    // Stupa dome top & finial
    const sbDome = new THREE.Mesh(new THREE.SphereGeometry(1.0, 14, 10), matWhiteStucco);
    sbDome.position.set(sbX, 3.2, sbZ);
    this.group.add(sbDome);

    const sbSpire = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.6, 8), matPureGold);
    sbSpire.position.set(sbX, 4.4, sbZ);
    this.group.add(sbSpire);

    // -------------------------------------------------------------------------
    // 9. Diagonal Prayer Flag Swags (Lungta) from Temple Roof to Poles
    // -------------------------------------------------------------------------
    this.buildCourtyardFlags();

    // -------------------------------------------------------------------------
    // 10. Warm Night Lanterns (Chome / Butter Lamps)
    // -------------------------------------------------------------------------
    const lanternPositions = [
      [-6, 1.8 + 2.5, gd / 2 + 1.6],
      [6, 1.8 + 2.5, gd / 2 + 1.6],
      [0, 1.8 + 4.5, gd / 2 + 1.6],
      [-16, 2.5, 16],
      [16, 2.5, 16],
    ];

    for (const [lx, ly, lz] of lanternPositions) {
      // Visual butter lamp lantern fixture
      const lampHousing = addBox(0.4, 0.6, 0.4, matTimberDark, lx, ly, lz);
      lampHousing.castShadow = false;

      const pt = new THREE.PointLight(0xffb24d, 0, 24, 1.6);
      pt.position.set(lx, ly + 0.3, lz);
      this.group.add(pt);
      this.lanterns.push(pt);
    }
  }

  private buildCourtyardFlags(): void {
    const flagColors = [0x2563eb, 0xf8fafc, 0xdc2626, 0x16a34a, 0xeab308];
    const swags = [
      { from: new THREE.Vector3(0, 16, 0), to: new THREE.Vector3(-16, 10, 16) },
      { from: new THREE.Vector3(0, 16, 0), to: new THREE.Vector3(16, 10, 16) },
      { from: new THREE.Vector3(0, 16, 0), to: new THREE.Vector3(-16, 10, -14) },
      { from: new THREE.Vector3(0, 16, 0), to: new THREE.Vector3(16, 10, -14) },
    ];

    for (const swag of swags) {
      const steps = 18;
      for (let i = 0; i < steps; i++) {
        const t = (i + 0.5) / steps;
        const pos = new THREE.Vector3().lerpVectors(swag.from, swag.to, t);
        // Sag catenary
        pos.y -= Math.sin(t * Math.PI) * 2.8;

        const fGeo = new THREE.PlaneGeometry(0.7, 0.55);
        const fMat = new THREE.MeshStandardMaterial({
          color: flagColors[i % flagColors.length],
          side: THREE.DoubleSide,
          roughness: 0.9,
        });
        const flag = new THREE.Mesh(fGeo, fMat);
        flag.position.copy(pos);
        flag.rotation.x = 0.25;
        flag.rotation.y = Math.atan2(swag.to.x - swag.from.x, swag.to.z - swag.from.z);
        this.group.add(flag);
      }
    }
  }

  public update(dt: number, nightFactor: number): void {
    // Smooth prayer wheel rotation in the courtyard
    const rotSpeed = 0.65;
    for (const pw of this.prayerWheels) {
      pw.rotation.y += rotSpeed * dt;
    }

    // Warm golden nocturnal butter lamp illumination
    const lampIntensity = nightFactor > 0.1 ? (nightFactor * 65) : 0;
    for (const lt of this.lanterns) {
      lt.intensity = lampIntensity;
    }
  }
}
