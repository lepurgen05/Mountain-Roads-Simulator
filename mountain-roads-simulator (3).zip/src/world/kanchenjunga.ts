/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

export class KanchenjungaMassif {
  public group: THREE.Group;
  public snowMat: THREE.MeshStandardMaterial;
  public rockMat: THREE.MeshStandardMaterial;
  public iceMat: THREE.MeshStandardMaterial;
  public foothillMat: THREE.MeshStandardMaterial;

  constructor(scene: THREE.Scene) {
    this.group = new THREE.Group();

    // Himalayan Alpine Materials
    this.snowMat = new THREE.MeshStandardMaterial({
      color: 0xfafafa,
      roughness: 0.42,
      metalness: 0.1,
      fog: false, // Ensures towering snow summits remain majestic and visible through atmospheric haze
    });

    this.iceMat = new THREE.MeshStandardMaterial({
      color: 0xdbeafe, // Glacial blue-white
      roughness: 0.28,
      metalness: 0.25,
      fog: false,
    });

    this.rockMat = new THREE.MeshStandardMaterial({
      color: 0x334155, // Sheer Himalayan granite precipices
      roughness: 0.88,
      metalness: 0.15,
      fog: false,
    });

    this.foothillMat = new THREE.MeshStandardMaterial({
      color: 0x1e3a5f, // Distant hazy deep-blue sub-Himalayan ridges
      roughness: 0.95,
      fog: false,
    });

    this.buildMassif();
    scene.add(this.group);
  }

  private buildMassif(): void {
    // -------------------------------------------------------------------------
    // The Sacred "Five Treasures of Snow" (Kanchenjunga 8,586m & Flanking Summits)
    // -------------------------------------------------------------------------
    const peaks = [
      // Name, relX, peakY, relZ, width, depth, peakHeight
      { name: 'Kanchenjunga Main (8586m)', x: 0, y: 380, z: 0, w: 720, d: 520, h: 580 },
      { name: 'Yalung Kang / West (8505m)', x: -440, y: 350, z: -80, w: 580, d: 460, h: 510 },
      { name: 'Kanchenjunga Central (8482m)', x: 220, y: 360, z: -40, w: 500, d: 420, h: 520 },
      { name: 'Kanchenjunga South (8494m)', x: 540, y: 340, z: -60, w: 560, d: 450, h: 490 },
      { name: 'Kangbachen (7903m)', x: -820, y: 310, z: -120, w: 620, d: 480, h: 440 },
      { name: 'Kabru North (7412m)', x: 920, y: 290, z: -140, w: 580, d: 450, h: 420 },
      { name: 'Pandim (6691m)', x: -1240, y: 260, z: -180, w: 640, d: 500, h: 380 },
    ];

    for (const p of peaks) {
      this.createPeakPyramid(p.x, p.y, p.z, p.w, p.d, p.h);
    }

    // -------------------------------------------------------------------------
    // Layered Foothill Ridges in Front (Creates Deep Aerial Himalayan Perspective)
    // -------------------------------------------------------------------------
    const foothillSpans = [
      { x: -600, y: 140, z: 220, w: 1400, h: 260, d: 380 },
      { x: 500, y: 130, z: 240, w: 1500, h: 250, d: 380 },
      { x: -100, y: 90, z: 420, w: 2200, h: 220, d: 420 },
    ];

    for (const f of foothillSpans) {
      const geo = new THREE.ConeGeometry(f.w * 0.55, f.h, 7);
      geo.rotateY(Math.PI / 5);
      const mesh = new THREE.Mesh(geo, this.foothillMat);
      mesh.position.set(f.x, f.y + f.h / 2, f.z);
      mesh.scale.set(1.0, 1.0, f.d / f.w);
      this.group.add(mesh);
    }
  }

  private createPeakPyramid(px: number, py: number, pz: number, w: number, d: number, h: number): void {
    // 1. Lower Rocky Mountain Bastion & Buttress (Sheer Granite Gneiss)
    const baseGeo = new THREE.ConeGeometry(w * 0.5, h * 0.65, 6);
    baseGeo.rotateY(Math.PI / 6);
    const baseMesh = new THREE.Mesh(baseGeo, this.rockMat);
    baseMesh.position.set(px, py + (h * 0.65) / 2, pz);
    baseMesh.scale.set(1.0, 1.0, d / w);
    this.group.add(baseMesh);

    // 2. Middle Fluted Glacial Ice Face & Seracs
    const iceH = h * 0.6;
    const iceGeo = new THREE.ConeGeometry(w * 0.38, iceH, 6);
    iceGeo.rotateY(Math.PI / 6 + 0.2);
    const iceMesh = new THREE.Mesh(iceGeo, this.iceMat);
    iceMesh.position.set(px, py + h * 0.35 + iceH / 2, pz);
    iceMesh.scale.set(1.0, 1.0, d / w);
    this.group.add(iceMesh);

    // 3. Soaring Razor-Sharp Snow Summit Pyramid (Pure Glistering White)
    const snowH = h * 0.52;
    const snowGeo = new THREE.ConeGeometry(w * 0.28, snowH, 5);
    snowGeo.rotateY(Math.PI / 5);
    const snowMesh = new THREE.Mesh(snowGeo, this.snowMat);
    snowMesh.position.set(px, py + h * 0.58 + snowH / 2, pz);
    snowMesh.scale.set(1.0, 1.0, d / w);
    this.group.add(snowMesh);

    // 4. Knife-Edge Ridges (Arêtes) radiating from the summit
    for (let ri = 0; ri < 3; ri++) {
      const ang = (ri / 3) * Math.PI * 2 + 0.3;
      const ridgeLen = w * 0.42;
      const rGeo = new THREE.BoxGeometry(w * 0.05, h * 0.45, ridgeLen);
      rGeo.rotateX(0.4);
      const ridgeMesh = new THREE.Mesh(rGeo, this.snowMat);
      ridgeMesh.position.set(
        px + Math.sin(ang) * (w * 0.18),
        py + h * 0.45,
        pz + Math.cos(ang) * (d * 0.18)
      );
      ridgeMesh.rotation.y = ang;
      this.group.add(ridgeMesh);
    }
  }

  public update(cameraX: number, cameraZ: number, sunColor: THREE.Color, nightFactor: number): void {
    // Parallax tracking: Mount Kanchenjunga is distant on the northern horizon
    // It stays north of the camera at a fixed distance so it is never culled by far plane
    const baseZ = cameraZ - 1350;
    const baseX = cameraX * 0.12 + 850; // Gentle parallax sweep as you travel between Gairigaon (x: 120) and Rimbick (x: 1800)

    this.group.position.set(baseX, 0, baseZ);

    // Dynamic Alpenglow & Lighting responsiveness:
    // At sunrise/sunset, Himalayan snow glows vivid gold and rose
    // At night, moon turns snow into luminous cool silver
    if (nightFactor > 0.4) {
      // Moonlit Himalayan night
      this.snowMat.color.setRGB(0.25, 0.32, 0.48);
      this.iceMat.color.setRGB(0.18, 0.25, 0.42);
      this.rockMat.color.setRGB(0.1, 0.14, 0.22);
      this.foothillMat.color.setRGB(0.06, 0.09, 0.16);
    } else {
      // Daytime / Sunset Alpenglow tinting
      const r = 0.88 + sunColor.r * 0.12;
      const g = 0.88 + sunColor.g * 0.12;
      const b = 0.92 + sunColor.b * 0.08;
      this.snowMat.color.setRGB(r, g, b);
      this.iceMat.color.setRGB(r * 0.92, g * 0.95, 1.0);
      this.rockMat.color.setRGB(0.24, 0.28, 0.35);
      this.foothillMat.color.setRGB(0.12, 0.22, 0.38);
    }
  }
}
