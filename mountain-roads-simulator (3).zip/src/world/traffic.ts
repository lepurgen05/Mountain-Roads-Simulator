/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { buildModel, VehicleModelResult } from '../vehicle/model.ts';
import { VEHICLES } from '../vehicle/definitions.ts';
import { mulberry32 } from '../core/noise.ts';
import { DS, Road } from './road.ts';
import { Vehicle } from '../vehicle/vehicle.ts';
import { Village, VillagePath } from './village.ts';
import { VehicleDefinition } from '../types.ts';
import { sound } from '../audio/SoundEngine.ts';

const MIX_HWY = ['mazda', 'mazda', 'bus', 'bus', 'hatch800', 'thar'];
const MIX = ['hatch800', 'hatch800', 'hatch800', 'thar', 'thar', 'mazda', 'mazda', 'bus'];
const SPEED: Record<string, number> = { hatch800: 13, thar: 15, mazda: 10, bus: 10.5 };
const COLORS: Record<string, number[]> = {
  hatch800: [0xe9e7e1, 0xb3262b, 0x2d4f8b, 0xcfcfcf, 0x3a6b4a],
  thar: [0x222222, 0xb3262b, 0xe9e7e1, 0x7a5b2e],
  mazda: [0x1f5fa8, 0xd6a21a, 0x2f7a46, 0xb3262b],
  bus: [0xb3262b, 0x1f5fa8, 0xd6a21a],
};

function disposeModel(root: THREE.Group): void {
  root.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      const mesh = o as THREE.Mesh;
      mesh.geometry.dispose();
      for (const m of [].concat(mesh.material as any)) {
        if ((m as any).map) (m as any).map.dispose();
        (m as any).dispose();
      }
    }
  });
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export interface TrafficCar {
  def: VehicleDefinition;
  model: VehicleModelResult;
  row: number;
  dir: number; // 1 = forward with road, -1 = reverse
  vt: number; // target speed
  speed: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  braking: boolean;
}

export class Traffic {
  public scene: THREE.Scene;
  public cars: TrafficCar[] = [];
  public on: boolean = true;
  public max: number = 7;
  public rng: () => number;
  public road: Road | null = null;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.rng = mulberry32(1);
  }

  public reset(road: Road): void {
    this.clear();
    this.road = road;
    this.rng = mulberry32(road.seed * 7 + 3);
  }

  public setOptions(on: boolean, density: number): void {
    this.on = on;
    this.max = Math.round((density / 100) * 10);
  }

  public clear(): void {
    for (const c of this.cars) {
      this.scene.remove(c.model.root);
      disposeModel(c.model.root);
    }
    this.cars = [];
  }

  public spawn(pr: number): void {
    if (!this.road) return;
    const r = this.rng;
    const mix =
      this.road.sty[Math.min(this.road.sty.length - 1, Math.ceil(pr + 100 / DS))] === 2 ? MIX_HWY : MIX;
    const key = mix[(r() * mix.length) | 0];
    const dir = r() < 0.5 ? 1 : -1;
    const row = pr + ((dir > 0 ? 90 : 160) + r() * 260) / DS;
    const cols = COLORS[key];

    for (const o of this.cars) {
      if (o.dir === dir && Math.abs(o.row - row) * DS < 45) return;
    }

    this.road.ensure(Math.ceil(row) + 8);
    const def: VehicleDefinition = {
      ...VEHICLES[key],
      color: cols[(r() * cols.length) | 0],
      accent: cols[(r() * cols.length) | 0],
    };
    const model = buildModel(def, { lights: true, bake: false });
    this.scene.add(model.root);
    model.root.rotation.order = 'YXZ';

    this.cars.push({
      def,
      model,
      row,
      dir,
      vt: SPEED[key] * (0.85 + r() * 0.35),
      speed: SPEED[key] * 0.8,
      x: 0,
      y: 0,
      z: 0,
      yaw: 0,
      braking: false,
    });
  }

  public update(dt: number, v: Vehicle, isDarkOrTunnel: boolean = false): void {
    if (!this.road || !this.on || v.st.dom !== 1) {
      if (this.cars.length) this.clear();
      return;
    }

    const road = this.road;
    const pr = v.st.i;

    for (let n = this.cars.length - 1; n >= 0; n--) {
      const c = this.cars[n];
      const gap = (c.row - pr) * DS;
      if (Math.abs(gap) > 650 || (c.dir > 0 && gap < -120) || (c.dir < 0 && gap < -150)) {
        this.scene.remove(c.model.root);
        disposeModel(c.model.root);
        this.cars.splice(n, 1);
      }
    }

    if (this.cars.length < this.max && this.rng() < dt * 0.8) {
      this.spawn(pr);
    }

    for (const c of this.cars) {
      const i = Math.floor(c.row);
      road.ensure(i + 6);
      const hw = road.w[i];
      const sty = road.sty[i];
      let targetSpeed =
        c.vt * (sty === 2 ? 2.4 : sty === 1 ? 0.6 : 0.5 + 0.5 * clamp((hw - 2) / 2, 0, 1));

      // Intelligent Driver Model (IDM) following distance
      let shouldBrake = false;
      for (const o of this.cars) {
        if (o === c) continue;
        const g = (o.row - c.row) * c.dir * DS;
        if (o.dir === c.dir && g > 0 && g < 36) {
          // Following leader vehicle
          const desiredGap = 8 + c.speed * 1.5;
          if (g < desiredGap) {
            targetSpeed = Math.min(targetSpeed, o.speed * (g < 10 ? 0.4 : 0.85));
            shouldBrake = true;
          }
        } else if (o.dir !== c.dir && hw < 2.9 && g > 0 && g < 45) {
          // Oncoming car on narrow road: slow down & yield
          targetSpeed = Math.min(targetSpeed, 3);
          shouldBrake = true;
        }
      }

      // Check distance to player vehicle
      if (c.dir > 0) {
        const g = (pr - c.row) * DS;
        if (g > 0 && g < 32 && Math.abs(v.st.off - hw * 0.5) < 2.2) {
          targetSpeed = Math.min(targetSpeed, Math.max(0, v.vf * 0.9));
          shouldBrake = true;
        }
      }

      c.braking = shouldBrake || targetSpeed < c.speed * 0.85;
      c.model.setBrakeLights(c.braking);
      c.model.setHeadlights(isDarkOrTunnel || sty === 1);

      c.speed += clamp(targetSpeed - c.speed, -5.5 * dt, 1.6 * dt);
      c.row += (c.dir * c.speed * dt) / DS;

      const j = Math.floor(c.row);
      const f = c.row - j;
      road.ensure(j + 3);
      const l = (a: number[]) => a[j] + (a[j + 1] - a[j]) * f;
      const h = l(road.h);
      const lane = Math.max(
        0.3,
        Math.min(road.w[j] * 0.55, road.w[j] - c.def.width / 2 - 0.35)
      );
      const off = c.dir > 0 ? lane : -lane;
      const y = l(road.y) - 0.03;

      c.x = l(road.x) + Math.cos(h) * off;
      c.z = l(road.z) - Math.sin(h) * off;
      c.y = y;
      c.yaw = c.dir > 0 ? h : h + Math.PI;

      c.model.root.position.set(c.x, y, c.z);
      c.model.root.rotation.set(
        -Math.atan((c.dir * (road.y[j + 1] - road.y[j])) / DS),
        c.yaw,
        0,
        'YXZ'
      );
      for (const w of c.model.wheels) {
        w.spin.rotation.x += (c.speed * dt) / c.def.wheelR;
      }
    }
  }

  public collide(v: Vehicle): void {
    if (v.st.dom !== 1) return;
    for (const c of this.cars) {
      const dx = v.x - c.x;
      const dz = v.z - c.z;
      const s = Math.sin(c.yaw);
      const co = Math.cos(c.yaw);
      const lx = dx * co - dz * s;
      const lz = dx * s + dz * co;
      const px = c.def.width / 2 + v.def.width / 2 - Math.abs(lx);
      const pz = c.def.length / 2 + v.def.length / 2 - Math.abs(lz);

      if (px > 0 && pz > 0) {
        // Calculate collision relative velocity
        const cvx = Math.sin(c.yaw) * c.speed * c.dir;
        const cvz = Math.cos(c.yaw) * c.speed * c.dir;
        const relSpeed = Math.hypot(v.vx - cvx, v.vz - cvz);

        if (px < pz) {
          const g = Math.sign(lx) || 1;
          v.x += g * px * co;
          v.z -= g * px * s;
        } else {
          const g = Math.sign(lz) || 1;
          v.x += g * pz * s;
          v.z += g * pz * co;
        }

        // Apply crash damage & audio
        if (relSpeed > 1.8) {
          sound.crash(Math.min(1.5, relSpeed / 9));
          const force = relSpeed * (c.def.mass / 1000);
          const impactLocalV = new THREE.Vector3(-lx, 0.4, -lz);
          const impactLocalC = new THREE.Vector3(lx, 0.4, lz);
          v.applyDamage(impactLocalV, force);
          c.model.applyDamage(impactLocalC, force);
          v.w += (Math.random() - 0.5) * relSpeed * 0.35;
        }

        // Elastic-plastic impulse exchange
        v.vx *= 0.45;
        v.vz *= 0.45;
        c.speed *= 0.4;
      }
    }
  }
}

export interface VillageTrafficCar {
  def: VehicleDefinition;
  model: VehicleModelResult;
  p: number;
  s: number;
  dir: number;
  vt: number;
  speed: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  i: number;
  grade: number;
  braking: boolean;
}

const VSPEED: Record<string, number> = { hatch800: 9.5, thar: 11.5, mazda: 7.5, bus: 8.0 };

export class VillageTraffic {
  public scene: THREE.Scene;
  public v: Village;
  public cars: VillageTrafficCar[] = [];
  public on: boolean = true;
  public max: number = 6;
  public rng: () => number;

  constructor(scene: THREE.Scene, village: Village) {
    this.scene = scene;
    this.v = village;
    this.rng = mulberry32(77);
  }

  public setOptions(on: boolean, density: number): void {
    this.on = on;
    this.max = density > 0 ? 2 + Math.round((density / 100) * 7) : 0;
    if (!on || this.max === 0) this.clear();
    else this.fill();
  }

  public clear(): void {
    for (const c of this.cars) {
      this.scene.remove(c.model.root);
      disposeModel(c.model.root);
    }
    this.cars = [];
  }

  public fill(): void {
    const P = this.v.paths;
    const r = this.rng;
    let tot = 0;
    for (const p of P) tot += p.len;

    for (let tries = 0; this.cars.length < this.max && tries < 300; tries++) {
      let a = r() * tot;
      let pi = 0;
      for (; pi < P.length - 1 && a > P[pi].len; pi++) a -= P[pi].len;
      if (P[pi].len < 80) continue;

      const key = MIX[(r() * MIX.length) | 0];
      const cols = COLORS[key];
      const def: VehicleDefinition = {
        ...VEHICLES[key],
        color: cols[(r() * cols.length) | 0],
        accent: cols[(r() * cols.length) | 0],
      };
      const c: VillageTrafficCar = {
        def,
        model: null as unknown as VehicleModelResult,
        p: pi,
        s: 20 + (P[pi].len - 40) * r(),
        dir: r() < 0.5 ? 1 : -1,
        vt: VSPEED[key] * (0.85 + r() * 0.3),
        speed: 0,
        x: 0,
        y: 0,
        z: 0,
        yaw: 0,
        i: 0,
        grade: 0,
        braking: false,
      };
      this.pose(c);

      if (
        Math.hypot(c.x - this.v.startX, c.z - this.v.startZ) < 70 ||
        this.cars.some((o) => Math.hypot(o.x - c.x, o.z - c.z) < 25)
      )
        continue;

      c.model = buildModel(def, { lights: true, bake: false });
      c.model.root.rotation.order = 'YXZ';
      this.scene.add(c.model.root);
      c.speed = c.vt * 0.7;
      this.cars.push(c);
      this.place(c, 0);
    }
  }

  private pose(c: VillageTrafficCar): void {
    const P = this.v.paths[c.p];
    const n = P.pts.length;
    let i = Math.min(n - 2, Math.max(0, Math.floor(c.s / (P.len / (n - 1)))));
    while (i > 0 && P.arc[i] > c.s) i--;
    while (i < n - 2 && P.arc[i + 1] < c.s) i++;

    const f = Math.min(1, Math.max(0, (c.s - P.arc[i]) / (P.arc[i + 1] - P.arc[i] || 1)));
    const a = P.pts[i];
    const b = P.pts[i + 1];
    let tx = b[0] - a[0];
    let tz = b[1] - a[1];
    const L = Math.hypot(tx, tz) || 1;
    tx = (tx / L) * c.dir;
    tz = (tz / L) * c.dir;

    const lane = clamp(2.55 - c.def.width / 2 - 0.3, 0.3, 1.2);
    c.x = a[0] + (b[0] - a[0]) * f + tz * lane;
    c.z = a[1] + (b[1] - a[1]) * f - tx * lane;
    c.yaw = Math.atan2(tx, tz);
    c.y = P.lv[i] + (P.lv[i + 1] - P.lv[i]) * f - 0.03 + (P.bias || 0);
    c.grade = (c.dir * (P.lv[i + 1] - P.lv[i])) / L;
    c.i = i;
  }

  private place(c: VillageTrafficCar, dt: number): void {
    c.model.root.position.set(c.x, c.y, c.z);
    c.model.root.rotation.set(-Math.atan(c.grade), c.yaw, 0, 'YXZ');
    for (const w of c.model.wheels) {
      w.spin.rotation.x += (c.speed * dt) / c.def.wheelR;
    }
  }

  private turn(c: VillageTrafficCar): void {
    const P = this.v.paths;
    const Q = P[c.p];
    const atEnd = c.s >= Q.len;
    const e = atEnd ? Q.pts[Q.pts.length - 1] : Q.pts[0];
    const cand: [number, number, number][] = [];

    P.forEach((q, qi) => {
      if (qi === c.p) return;
      if (Math.hypot(q.pts[0][0] - e[0], q.pts[0][1] - e[1]) < 8) cand.push([qi, 1, 0.5]);
      const l = q.pts[q.pts.length - 1];
      if (Math.hypot(l[0] - e[0], l[1] - e[1]) < 8) cand.push([qi, -1, q.len - 0.5]);
    });

    if (cand.length) {
      const k = cand[(this.rng() * cand.length) | 0];
      c.p = k[0];
      c.dir = k[1];
      c.s = k[2];
    } else {
      c.dir = -c.dir;
      c.s = clamp(c.s, 0.5, Q.len - 0.5);
      c.speed = Math.min(c.speed, 2);
    }
  }

  public update(dt: number, v: Vehicle, isNight: boolean = false): void {
    const active = this.on && v.st.dom === 0;
    for (const c of this.cars) c.model.root.visible = active;
    if (!active) return;

    for (const c of this.cars) {
      const P = this.v.paths[c.p];
      const i = c.i;
      let targetSpeed = c.vt;

      if (i > 0 && i < P.pts.length - 2) {
        const a = P.pts[i - 1];
        const b = P.pts[i + 1];
        const d = P.pts[i + 2];
        const h1 = Math.atan2(b[0] - a[0], b[1] - a[1]);
        const h2 = Math.atan2(d[0] - b[0], d[1] - b[1]);
        let dh = Math.abs(h2 - h1);
        if (dh > Math.PI) dh = 2 * Math.PI - dh;
        targetSpeed = Math.min(targetSpeed, Math.sqrt(2.4 / (dh / 6 + 1e-3)));
      }
      if (c.grade > 0.06) {
        targetSpeed *= Math.max(0.5, 1 - (c.grade - 0.06) * 4);
      }

      const sy = Math.sin(c.yaw);
      const cy = Math.cos(c.yaw);
      const look = 10 + c.speed * 1.5;
      let shouldBrake = false;

      const watch = (x: number, z: number, sp: number, oy: number) => {
        const dx = x - c.x;
        const dz = z - c.z;
        const f = dx * sy + dz * cy;
        const l = dx * cy - dz * sy;
        const opp = Math.cos(c.yaw - oy) < -0.3;
        if (f > 0 && f < look && Math.abs(l) < (opp ? 1.3 : 2.1)) {
          targetSpeed = Math.min(targetSpeed, f < 6 ? 0 : sp * 0.9);
          shouldBrake = true;
        }
      };

      for (const o of this.cars) {
        if (o !== c) watch(o.x, o.z, o.speed, o.yaw);
      }
      watch(v.x, v.z, Math.abs(v.vf), v.yaw);

      c.braking = shouldBrake || targetSpeed < c.speed * 0.85;
      c.model.setBrakeLights(c.braking);
      c.model.setHeadlights(isNight);

      c.speed += clamp(targetSpeed - c.speed, -6 * dt, 1.5 * dt);
      c.s += c.dir * c.speed * dt;
      if (c.s <= 0 || c.s >= P.len) this.turn(c);
      this.pose(c);
      this.place(c, dt);
    }
  }

  public collide(v: Vehicle): void {
    if (v.st.dom !== 0) return;
    for (const c of this.cars) {
      const dx = v.x - c.x;
      const dz = v.z - c.z;
      const s = Math.sin(c.yaw);
      const co = Math.cos(c.yaw);
      const lx = dx * co - dz * s;
      const lz = dx * s + dz * co;
      const px = c.def.width / 2 + v.def.width / 2 - Math.abs(lx);
      const pz = c.def.length / 2 + v.def.length / 2 - Math.abs(lz);

      if (px > 0 && pz > 0) {
        const cvx = Math.sin(c.yaw) * c.speed * c.dir;
        const cvz = Math.cos(c.yaw) * c.speed * c.dir;
        const relSpeed = Math.hypot(v.vx - cvx, v.vz - cvz);

        if (px < pz) {
          const g = Math.sign(lx) || 1;
          v.x += g * px * co;
          v.z -= g * px * s;
        } else {
          const g = Math.sign(lz) || 1;
          v.x += g * pz * s;
          v.z += g * pz * co;
        }

        if (relSpeed > 1.8) {
          sound.crash(Math.min(1.5, relSpeed / 9));
          const force = relSpeed * (c.def.mass / 1000);
          const impactLocalV = new THREE.Vector3(-lx, 0.4, -lz);
          const impactLocalC = new THREE.Vector3(lx, 0.4, lz);
          v.applyDamage(impactLocalV, force);
          c.model.applyDamage(impactLocalC, force);
          v.w += (Math.random() - 0.5) * relSpeed * 0.35;
        }

        v.vx *= 0.45;
        v.vz *= 0.45;
        c.speed *= 0.4;
      }
    }
  }
}
