/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { VILLAGE as V } from '../data/village.ts';
import { mulberry32, sstep, fbm2 } from '../core/noise.ts';
import {
  C,
  canvasTex,
  inst,
  put,
  done,
  groundMat,
  roadMat,
  pineGeo,
  cedarGeo,
  leafGeo,
  bushGeo,
  grassGeo,
  treeMat,
  bushMat,
  grassMat,
  boxGeo,
  roofGeo,
  wallMat,
  roofMat,
  winMat,
  lampGeo,
  lampMat,
} from '../core/assets.ts';
import { Vehicle } from '../vehicle/vehicle.ts';
import { RoadSampleState } from '../types.ts';

export const VILLAGE_ELEV = 183;
export const START_Y = 383;
const X0 = -500;
const Z0 = -500;
const XW = 2500;
const ZW = 2000;
const CELL = 5;
const NX = XW / CELL + 1;
const NZ = ZW / CELL + 1;
const FC = 4;
const FX = Math.floor(XW / FC) + 1;
const FZ = Math.floor(ZW / FC) + 1;

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const col = C.col;
const SIDE = 0.06;

const z0 = (x: number) =>
  V.start.z + (V.exit.z - V.start.z) * clamp((x - V.start.x) / (2000 - V.start.x), 0, 1);
const taper = (x: number) => 1 - sstep(1550, 2000, x);

let MS: { x: Float32Array; z: Float32Array; l: Float32Array; n: number } | null = null;

const Elow = (x: number, z: number) => {
  if (!MS) return 0;
  let sw = 0;
  let sl = 0;
  let sz = 0;
  for (let i = 0; i < MS.n; i++) {
    const dx = x - MS.x[i];
    const dz = z - MS.z[i];
    const d2 = dx * dx + dz * dz;
    const w = 1 / ((d2 + 16) * (d2 + 16));
    sw += w;
    sl += w * MS.l[i];
    sz += w * MS.z[i];
  }
  return (
    sl / sw +
    taper(x) * (SIDE * (sz / sw - z) + 5 * (fbm2(777, x / 700, z / 700, 2) - 0.5) * 2 * sstep(180, 420, x))
  );
};

const hill = (x: number, z: number) =>
  taper(x) *
  (55 * (fbm2(778, x / 260, z / 260, 4) - 0.5) * 2 +
    80 * sstep(100, 500, z0(x) - z) -
    70 * sstep(150, 550, z - z0(x)));

const hwAt = (x: number, z: number) => 2.35 + 0.4 * fbm2(779, x / 120, z / 120, 2);

function field(stamp: (cb: (x: number, z: number, l: number) => void) => void) {
  const d = new Float32Array(FX * FZ).fill(1e4);
  const lv = new Float32Array(FX * FZ);
  const D = FC * 1.414;

  stamp((x, z, l) => {
    const i = Math.round((x - X0) / FC);
    const j = Math.round((z - Z0) / FC);
    if (i >= 0 && j >= 0 && i < FX && j < FZ) {
      d[j * FX + i] = 0;
      lv[j * FX + i] = l;
    }
  });

  const rel = (k: number, n: number, c: number) => {
    if (d[n] + c < d[k]) {
      d[k] = d[n] + c;
      lv[k] = lv[n];
    }
  };

  for (let j = 0; j < FZ; j++) {
    for (let i = 0; i < FX; i++) {
      const k = j * FX + i;
      if (i > 0) rel(k, k - 1, FC);
      if (j > 0) {
        rel(k, k - FX, FC);
        if (i > 0) rel(k, k - FX - 1, D);
        if (i < FX - 1) rel(k, k - FX + 1, D);
      }
    }
  }

  for (let j = FZ - 1; j >= 0; j--) {
    for (let i = FX - 1; i >= 0; i--) {
      const k = j * FX + i;
      if (i < FX - 1) rel(k, k + 1, FC);
      if (j < FZ - 1) {
        rel(k, k + FX, FC);
        if (i < FX - 1) rel(k, k + FX + 1, D);
        if (i > 0) rel(k, k + FX - 1, D);
      }
    }
  }

  const t = new Float32Array(FX * FZ);
  const R = 2;
  for (let it = 0; it < 2; it++) {
    for (let j = 0; j < FZ; j++) {
      for (let i = 0; i < FX; i++) {
        let a = 0;
        let c = 0;
        for (let q = Math.max(0, i - R); q <= Math.min(FX - 1, i + R); q++) {
          a += lv[j * FX + q];
          c++;
        }
        t[j * FX + i] = a / c;
      }
    }
    for (let j = 0; j < FZ; j++) {
      for (let i = 0; i < FX; i++) {
        let a = 0;
        let c = 0;
        for (let q = Math.max(0, j - R); q <= Math.min(FZ - 1, j + R); q++) {
          a += t[q * FX + i];
          c++;
        }
        lv[j * FX + i] = a / c;
      }
    }
  }
  return { d, lv };
}

function fs(d: Float32Array, x: number, z: number): number {
  const fx = clamp((x - X0) / FC, 0, FX - 1.001);
  const fz = clamp((z - Z0) / FC, 0, FZ - 1.001);
  const i = fx | 0;
  const j = fz | 0;
  const tx = fx - i;
  const tz = fz - j;
  const k = j * FX + i;
  return (
    d[k] * (1 - tx) * (1 - tz) +
    d[k + 1] * tx * (1 - tz) +
    d[k + FX] * (1 - tx) * tz +
    d[k + FX + 1] * tx * tz
  );
}

// Vibrant Himalayan village house walls (warm ochres, mountain sky blues, colonial whites, cedar woods, tea-estate mint)
const WALLS = [
  'e5b042', // Warm Darjeeling ochre
  'f7f2e6', // Crisp ivory whitewash
  '468ec4', // Mountain sky blue
  '4fa86c', // Tea-estate sage / alpine mint
  'd4644a', // Terracotta clay
  '7d5236', // Rich cedar timber lodge
  'dba030', // Saffron gold
  'e2d5c3', // Warm sandstone
  '5594b8', // Weathered cyan blue
  '66a378', // Mountain fir green
].map((h) => col(parseInt(h, 16)));

// Vivid painted corrugated tin roofs (crimson red, cobalt blue, forest emerald, rust copper, saffron)
const ROOFS = [
  'c52828', // Post-office crimson red
  '1d60c4', // Royal mountain cobalt blue
  '1b8543', // Forest ridge emerald green
  'c24419', // Rust terracotta copper
  'b51e1e', // Deep scarlet
  '174ea6', // Deep mountain blue
  'd97706', // Saffron marigold
  '5f6b78', // Weathered galvanized zinc steel
].map((h) => col(parseInt(h, 16)));

/**
 * Realistic road surface bumps along the Gairigaon -> Rimbick mountain road.
 * Models frost heaves, asphalt washboards, drainage culvert dips, speed humps, and potholes.
 */
export function villageRoadBump(x: number, z: number): number {
  if (x < 60 || x > 1920 || z < 150 || z > 850) return 0;

  let bump = 0;

  // Section 1: Weathered stretch past Pushpa Store (x: 180 to 480) - undulating heaves & asphalt dips
  if (x > 180 && x < 480) {
    const factor = Math.sin(((x - 180) / (480 - 180)) * Math.PI);
    const ripple = Math.sin(x * 0.85 + z * 0.4) * Math.cos(z * 1.1) * 0.055;
    const dip1 = Math.exp(-((x - 290) ** 2 + (z - 365) ** 2) / 4.0) * -0.065;
    const dip2 = Math.exp(-((x - 410) ** 2 + (z - 364) ** 2) / 4.5) * -0.06;
    bump += factor * (ripple + dip1 + dip2);
  }

  // Section 2: Mountain drainage culvert cross-dip & warning rumble before hairpins (x: 510 to 575)
  if (x > 510 && x < 575) {
    const culvertDip = -Math.exp(-((x - 538) ** 2) / 2.2) * 0.065;
    const rumble = Math.sin(x * 6.5) * 0.025 * Math.exp(-((x - 555) ** 2) / 12.0);
    bump += culvertDip + rumble;
  }

  // Section 3: Hairpin turns road washboard and potholes (x: 580 to 760)
  if (x > 580 && x < 760) {
    const factor = Math.sin(((x - 580) / (760 - 580)) * Math.PI);
    const washboard = Math.sin(x * 1.6 + z * 1.3) * 0.045;
    const pot = Math.exp(-((x - 655) ** 2 + (z - 420) ** 2) / 5.0) * -0.07;
    bump += factor * (washboard + pot);
  }

  // Section 4: Mid-valley old road downhill run (x: 880 to 1240) - wave heaves and patches
  if (x > 880 && x < 1240) {
    const factor = Math.sin(((x - 880) / (1240 - 880)) * Math.PI);
    const wave = Math.sin(x * 0.65 + z * 0.45) * 0.05;
    const asphaltPatch = Math.exp(-((x - 1020) ** 2 + (z - 485) ** 2) / 6.0) * 0.055;
    const pot2 = Math.exp(-((x - 1145) ** 2 + (z - 475) ** 2) / 4.0) * -0.065;
    bump += factor * (wave + asphaltPatch + pot2);
  }

  // Section 5: Paved stone drainage channel & entrance hump before Rimbick Bazaar (x: 1280 to 1345)
  if (x > 1280 && x < 1345) {
    const drainage = -Math.exp(-((x - 1308) ** 2) / 2.0) * 0.06;
    const speedHump = Math.exp(-((x - 1324) ** 2) / 2.5) * 0.055;
    bump += drainage + speedHump;
  }

  return bump;
}

const ease = (t: number) => {
  const r = 0.04;
  let F: number;
  if (t < r) {
    const u = t / r;
    F = r * (u ** 3 - u ** 4 / 2);
  } else if (t > 1 - r) {
    const u = (1 - t) / r;
    F = 1 - r - r * (u ** 3 - u ** 4 / 2);
  } else {
    F = r / 2 + (t - r);
  }
  return F / (1 - r);
};

function chaikin(p: [number, number][], it: number): [number, number][] {
  for (let k = 0; k < it; k++) {
    const q: [number, number][] = [p[0]];
    for (let i = 0; i < p.length - 1; i++) {
      q.push(
        [0.75 * p[i][0] + 0.25 * p[i + 1][0], 0.75 * p[i][1] + 0.25 * p[i + 1][1]],
        [0.25 * p[i][0] + 0.75 * p[i + 1][0], 0.25 * p[i][1] + 0.75 * p[i + 1][1]]
      );
    }
    q.push(p[p.length - 1]);
    p = q;
  }
  return p;
}

function resample(p: [number, number][], step: number): { pts: [number, number][]; arc: number[] } {
  const out: [number, number][] = [p[0]];
  const arc: number[] = [0];
  let acc = 0;
  let carry = 0;
  for (let i = 0; i < p.length - 1; i++) {
    const dx = p[i + 1][0] - p[i][0];
    const dz = p[i + 1][1] - p[i][1];
    const L = Math.hypot(dx, dz);
    let t = step - carry;
    while (t <= L) {
      out.push([p[i][0] + (dx * t) / L, p[i][1] + (dz * t) / L]);
      acc += step;
      arc.push(acc);
      t += step;
    }
    carry = L - (t - step);
  }
  out.push(p[p.length - 1]);
  arc.push(acc + carry);
  return { pts: out, arc };
}

function hairpinRoad(x0: number, z0: number, A: [number, number]): [number, number][] {
  let x = x0;
  let z = z0;
  let h = Math.PI / 2;
  const pts: [number, number][] = [[x, z]];
  const go = (len: number) => {
    const n = Math.max(1, Math.round(len / 3));
    const d = len / n;
    for (let i = 0; i < n; i++) {
      x += Math.sin(h) * d;
      z += Math.cos(h) * d;
      pts.push([x, z]);
    }
  };
  const arc = (R: number, deg: number, dir: number) => {
    const n = Math.max(4, Math.round((R * deg * Math.PI) / 180 / 3));
    const dh = ((dir * deg * Math.PI) / 180) / n;
    const d = R * Math.abs(dh);
    for (let i = 0; i < n; i++) {
      h += dh / 2;
      x += Math.sin(h) * d;
      z += Math.cos(h) * d;
      h += dh / 2;
      pts.push([x, z]);
    }
  };
  go(110);
  arc(20, 180, -1);
  go(55);
  arc(20, 180, 1);
  go(60);
  arc(20, 180, -1);
  go(55);
  arc(36, 180, 1);
  const wp: [number, number][] = [
    [x, z],
    [x + 40, z - 4],
    [800, 528],
    [950, 497],
    [1100, 478],
    [1250, 470],
    [1380, 473],
    [A[0] - 40, A[1] - 6],
    [A[0], A[1]],
  ];
  return pts.concat(resample(chaikin(wp, 3), 3).pts.slice(1));
}

export interface VillagePath {
  pts: [number, number][];
  lv: number[];
  arc: number[];
  len: number;
  bias?: number;
}

export class Village {
  public scene: THREE.Scene;
  public startX: number;
  public startZ: number;
  public group: THREE.Group;
  public veg: number = -1;
  public tiles: THREE.Group[] = [];
  public lines: [number, number][][];
  public paths: VillagePath[] = [];
  public dr: { d: Float32Array; lv: Float32Array };
  public df: { d: Float32Array; lv: Float32Array };
  public FG: Float32Array;
  public H: Float32Array;
  public samples: [number, number, number, number, number, number, number][] = [];
  public sgrid: Map<number, [number, number, number, number, number, number, number][]> = new Map();
  public hgrid: Map<number, number[]> = new Map();
  public rects: [number, number, number, number][] = [];
  public lit: THREE.InstancedMesh;
  public houseCount: number = 0;
  public store: { x: number; z: number; w: number; d: number; st: number; wc: THREE.Color; rc: THREE.Color; store?: boolean } | null = null;
  public routeLen: number = 0;
  public branch: [number, number] = [0, 0];
  public vegGroup: THREE.Group | null = null;
  public streetLamps: THREE.Group | null = null;

  private _q: [number, number, number, number, number, number, number] | null = null;
  private _hw: number = 3.4;
  private _lv: number = 0;

  constructor(scene: THREE.Scene, s: { vegetation: number }) {
    this.scene = scene;
    this.startX = V.start.x;
    this.startZ = V.start.z;
    this.group = new THREE.Group();
    scene.add(this.group);

    this.lines = V.roads.map((a: number[]) => {
      const p: [number, number][] = [];
      for (let i = 0; i < a.length; i += 2) p.push([a[i], a[i + 1]]);
      return p;
    });

    for (const p of this.lines) {
      for (const [e, last] of [
        [p[0], false],
        [p[p.length - 1], true],
      ] as const) {
        if (e[0] > 1985 && Math.abs(e[1] - V.exit.z) < 12) {
          last ? p.push([2003, V.exit.z]) : p.unshift([2003, V.exit.z]);
          break;
        }
      }
    }

    this.buildNetwork();

    this.paths = this.lines.map((p) => {
      const pts: [number, number][] = [];
      for (let i = 0; i < p.length - 1; i++) {
        const n = Math.max(1, Math.ceil(Math.hypot(p[i + 1][0] - p[i][0], p[i + 1][1] - p[i][1]) / 3));
        for (let k = 0; k < n; k++) {
          pts.push([
            p[i][0] + ((p[i + 1][0] - p[i][0]) * k) / n,
            p[i][1] + ((p[i + 1][1] - p[i][1]) * k) / n,
          ]);
        }
      }
      pts.push(p[p.length - 1]);
      const n = pts.length;
      const l0 = pts.map((q) => Elow(q[0], q[1]));
      const lv = l0.map((_, i) => {
        const w = Math.min(6, i, n - 1 - i);
        let a = 0;
        let c = 0;
        for (let k = i - w; k <= i + w; k++) {
          a += l0[k];
          c++;
        }
        return a / c;
      });
      const arc = [0];
      for (let i = 1; i < n; i++) {
        arc.push(arc[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
      }
      return { pts, lv, arc, len: arc[n - 1] };
    });

    const stampP = (put_: (x: number, z: number, l: number) => void) => {
      for (const P of this.paths) {
        for (let i = 0; i < P.pts.length - 1; i++) {
          const a = P.pts[i];
          const b = P.pts[i + 1];
          for (let k = 0; k <= 2; k++) {
            const f = k / 2;
            put_(a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, P.lv[i] + (P.lv[i + 1] - P.lv[i]) * f);
          }
        }
      }
    };

    this.dr = field(stampP);
    this.df = field((p_) => {
      stampP(p_);
      for (const [cx, cz, w, d] of V.houses) {
        const l = Elow(cx, cz);
        for (let x = cx - w / 2; x <= cx + w / 2; x += 3) {
          for (let z = cz - d / 2; z <= cz + d / 2; z += 3) {
            p_(x, z, l);
          }
        }
      }
      // Grade monastery terrace plateau so terrain supports the gompa complex smoothly
      const monoL = Elow(230, 275);
      for (let x = 230 - 24; x <= 230 + 24; x += 3) {
        for (let z = 275 - 24; z <= 275 + 24; z += 3) {
          p_(x, z, monoL);
        }
      }
    });

    this.paths.forEach((P, k) => {
      P.bias = k * 0.015;
    });

    this.buildSamples();

    this.FG = new Float32Array(251 * 201);
    for (let j = 0; j < 201; j++) {
      for (let i = 0; i < 251; i++) {
        const x = X0 + i * 10;
        const z = Z0 + j * 10;
        this.FG[j * 251 + i] = Elow(x, z) + hill(x, z);
      }
    }

    this.H = new Float32Array(NX * NZ);
    for (let j = 0; j < NZ; j++) {
      for (let i = 0; i < NX; i++) {
        const x = X0 + i * CELL;
        const z = Z0 + j * CELL;
        const Lr = fs(this.dr.lv, x, z);
        const Lf = fs(this.df.lv, x, z);
        const L = Lf + (Lr - Lf) * (1 - sstep(6, 16, fs(this.dr.d, x, z)));
        const w = sstep(13, 42, fs(this.df.d, x, z));
        let h = L - 0.2 + (w > 0.001 ? w * (this.far(x, z) - L) : 0);
        const dr_ = this.roadDist(x, z);
        const q = this._q;
        if (q) {
          const c = 1 - sstep(q[4] + 5, q[4] + 10, dr_);
          if (c > 0) h += c * (this._lv - 0.25 - h);
        }
        this.H[j * NX + i] = h;
      }
    }

    this.buildTerrain();
    this.buildRoads();
    this.indexSamples();
    this.lit = inst(this.group, boxGeo, new THREE.MeshBasicMaterial({ color: 0xffe899 }), 100, false);
    this.buildHouses();
    this.buildSigns();
    this.buildPrayerFlags();
    this.buildVeg(s.vegetation / 100);
  }

  private buildNetwork(): void {
    const L = this.lines;
    const l0 = L[0];
    let b = 0;
    let si = 0;
    let bd = 1e9;
    l0.forEach((q, i) => {
      const d = Math.hypot(q[0] - 585, q[1] - 356);
      if (d < bd) {
        bd = d;
        b = i;
      }
    });
    bd = 1e9;
    l0.forEach((q, i) => {
      const d = Math.hypot(q[0] - V.start.x, q[1] - V.start.z);
      if (d < bd) {
        bd = d;
        si = i;
      }
    });

    const lineE = l0.slice(0, b + 1);
    const lineW = l0.slice(b);
    const H = hairpinRoad(l0[b][0], l0[b][1], L[1][0]);
    const M = [...lineW.slice(0, si - b + 1).reverse(), ...H.slice(1), ...L[1].slice(1)];
    const R = resample(M, 3);
    const n = R.pts.length;
    const LM = R.arc[n - 1];
    const xs: number[] = [];
    const zs: number[] = [];
    const ls: number[] = [];
    for (let i = 0; i < n; i += 2) {
      xs.push(R.pts[i][0]);
      zs.push(R.pts[i][1]);
      ls.push(START_Y - (START_Y - VILLAGE_ELEV) * ease(R.arc[i] / LM));
    }
    MS = { x: Float32Array.from(xs), z: Float32Array.from(zs), l: Float32Array.from(ls), n: xs.length };
    this.routeLen = LM;
    this.branch = l0[b];
    this.lines = [lineE, ...L.slice(1), lineW, H];
  }

  public fallen(v: Vehicle): boolean {
    const d = this.roadDist(v.x, v.z);
    const q = this._q;
    return !!q && d < 120 && v.y < q[5] - 8;
  }

  public far(x: number, z: number): number {
    const fx = clamp((x - X0) / 10, 0, 249.001);
    const fz = clamp((z - Z0) / 10, 0, 199.001);
    const i = fx | 0;
    const j = fz | 0;
    const tx = fx - i;
    const tz = fz - j;
    const k = j * 251 + i;
    const G = this.FG;
    return (
      G[k] * (1 - tx) * (1 - tz) +
      G[k + 1] * tx * (1 - tz) +
      G[k + 251] * (1 - tx) * tz +
      G[k + 252] * tx * tz
    );
  }

  public hAt(x: number, z: number): number {
    const fx = clamp((x - X0) / CELL, 0, NX - 1.001);
    const fz = clamp((z - Z0) / CELL, 0, NZ - 1.001);
    const i = fx | 0;
    const j = fz | 0;
    const tx = fx - i;
    const tz = fz - j;
    const k = j * NX + i;
    const H = this.H;
    return (
      H[k] * (1 - tx) * (1 - tz) +
      H[k + 1] * tx * (1 - tz) +
      H[k + NX] * (1 - tx) * tz +
      H[k + NX + 1] * tx * tz
    );
  }

  public roadDist(x: number, z: number): number {
    const cx = Math.floor(x / 12);
    const cz = Math.floor(z / 12);
    let bd = 1e9;
    let q: [number, number, number, number, number, number, number] | null = null;
    let sw = 0;
    let sl = 0;

    for (let i = -1; i <= 1; i++) {
      for (let j = -1; j <= 1; j++) {
        const a = this.sgrid.get((cx + i) * 4096 + cz + j);
        if (a) {
          for (const r of a) {
            const d = (r[0] - x) ** 2 + (r[1] - z) ** 2;
            if (d < bd) {
              bd = d;
              q = r;
            }
            if (d < 100) {
              const w = 1 / ((d + 9) * (d + 9));
              sw += w;
              sl += w * r[5];
            }
          }
        }
      }
    }
    this._q = q;
    this._hw = q ? q[4] : 3.4;
    this._lv = sw > 0 ? sl / sw : q ? q[5] : 0;
    return Math.sqrt(bd);
  }

  public groundAt(x: number, z: number, st: RoadSampleState): number {
    const h = this.hAt(x, z);
    const d = this.roadDist(x, z);
    const hw = this._hw;
    const q = this._q;
    st.off = d < hw ? 0 : 10;
    st.hw = hw;
    st.endless = false;
    if (!q) return h;
    const k = 1 - sstep(hw - 0.4, hw + 0.6, d);
    if (k <= 0) return h;
    const bmp = villageRoadBump(x, z);
    return h + k * (this._lv + bmp - 0.03 - h);
  }

  private buildTerrain(): void {
    const V_ = NX * NZ;
    const pos = new Float32Array(V_ * 3);
    const uv = new Float32Array(V_ * 2);
    const cl = new Float32Array(V_ * 3);
    const idx = new Uint32Array((NX - 1) * (NZ - 1) * 6);

    for (let j = 0; j < NZ; j++) {
      for (let i = 0; i < NX; i++) {
        const v = j * NX + i;
        pos[v * 3] = X0 + i * CELL;
        pos[v * 3 + 1] = this.H[v];
        pos[v * 3 + 2] = Z0 + j * CELL;
        uv[v * 2] = pos[v * 3] / 9;
        uv[v * 2 + 1] = pos[v * 3 + 2] / 9;
      }
    }

    let q = 0;
    for (let j = 0; j < NZ - 1; j++) {
      for (let i = 0; i < NX - 1; i++) {
        const a = j * NX + i;
        const b = a + 1;
        const c = a + NX;
        const d = c + 1;
        idx[q++] = a;
        idx[q++] = c;
        idx[q++] = b;
        idx[q++] = b;
        idx[q++] = c;
        idx[q++] = d;
      }
    }

    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    g.setIndex(new THREE.BufferAttribute(idx, 1));
    g.computeVertexNormals();

    const nor = g.attributes.normal;
    const c = new THREE.Color();
    for (let v = 0; v < V_; v++) {
      const x = pos[v * 3];
      const z = pos[v * 3 + 2];
      const dr = fs(this.dr.d, x, z);
      const df = fs(this.df.d, x, z);
      const ny = nor.getY(v);

      // Lush green rolling mountain slope coloring
      c.copy(C.GA).lerp(C.GB, fbm2(861, x / 60, z / 60, 2));
      c.lerp(C.GC, sstep(0.45, 0.75, fbm2(862, x / 25, z / 25, 2)) * 0.6);
      c.lerp(C.PADDY, sstep(0.4, 0.7, fbm2(863, x / 80, z / 80, 2)) * 0.35);

      // Only steep sheer cliffs (> 57 degrees) show exposed rock
      const cliffRock = sstep(0.55, 0.35, ny);
      c.lerp(C.ROCK, cliffRock);

      // Road shoulder verge and house terrace foundation
      if (dr < 3.2) c.lerp(C.GRAVEL, 0.65);
      else if (dr < 5.5) c.lerp(C.GRAVEL, 0.2);
      else if (df < 4.0) c.lerp(C.DIRT, 0.4);

      cl[v * 3] = c.r;
      cl[v * 3 + 1] = c.g;
      cl[v * 3 + 2] = c.b;
    }
    g.setAttribute('color', new THREE.BufferAttribute(cl, 3));

    const m = new THREE.Mesh(g, groundMat);
    m.receiveShadow = true;
    this.group.add(m);
  }

  private buildRoads(): void {
    for (const P of this.paths) {
      const pts = P.pts;
      const n = pts.length;
      const pos = new Float32Array(n * 18);
      const cl = new Float32Array(n * 18);
      const uv = new Float32Array(n * 12);
      const ix: number[] = [];
      let arc = 0;

      for (let i = 0; i < n; i++) {
        const a = pts[Math.max(0, i - 1)];
        const b = pts[Math.min(n - 1, i + 1)];
        let tx = b[0] - a[0];
        let tz = b[1] - a[1];
        const l = Math.hypot(tx, tz) || 1;
        tx /= l;
        tz /= l;

        const [x, z] = pts[i];
        const hw = hwAt(x, z);
        const y = P.lv[i] - 0.03 + (P.bias || 0);
        const lx = tz;
        const lz = -tx;
        const dash = i % 4 < 2 ? C.LINE : C.ASPH;
        if (i) arc += Math.hypot(x - pts[i - 1][0], z - pts[i - 1][1]);

        const offs = [-hw, -0.1, -0.1, 0.1, 0.1, hw];
        const cs = [C.ASPH, C.ASPH, dash, dash, C.ASPH, C.ASPH];
        for (let k = 0; k < 6; k++) {
          const v = i * 6 + k;
          const px = x + lx * offs[k];
          const pz = z + lz * offs[k];
          const bmp = villageRoadBump(px, pz);
          pos[v * 3] = px;
          pos[v * 3 + 1] = y + bmp;
          pos[v * 3 + 2] = pz;

          // Road surface tar patch darkening over repaired dips and culverts
          const patchFactor = bmp > 0.015 ? 0.88 : bmp < -0.015 ? 0.82 : 1.0;
          cl[v * 3] = cs[k].r * patchFactor;
          cl[v * 3 + 1] = cs[k].g * patchFactor;
          cl[v * 3 + 2] = cs[k].b * patchFactor;
          uv[v * 2] = offs[k] / 3;
          uv[v * 2 + 1] = arc / 3;
        }

        if (i < n - 1) {
          for (const k of [0, 2, 4]) {
            const a0 = i * 6 + k;
            const b0 = a0 + 1;
            const c0 = a0 + 6;
            const d0 = c0 + 1;
            ix.push(a0, c0, b0, b0, c0, d0);
          }
        }
      }

      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      g.setAttribute('color', new THREE.BufferAttribute(cl, 3));
      g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
      g.setIndex(ix);
      g.computeVertexNormals();

      const m = new THREE.Mesh(g, roadMat);
      m.receiveShadow = true;
      this.group.add(m);
    }
  }

  public respawnPoint(x: number, z: number, yaw: number): { x: number; z: number; yaw: number } {
    const s = this.nearestRoad(x, z);
    let tx = s[2];
    let tz = s[3];
    if (tx * Math.sin(yaw) + tz * Math.cos(yaw) < 0) {
      tx = -tx;
      tz = -tz;
    }
    const lane = s[4] * 0.5;
    return {
      x: s[0] + tz * lane,
      z: s[1] - tx * lane,
      yaw: Math.atan2(tx, tz),
    };
  }

  public buildSamples(): void {
    this.samples = [];
    for (const P of this.paths) {
      const pts = P.pts;
      const n = pts.length;
      for (let i = 0; i < n; i++) {
        const ia = Math.max(0, i - 1);
        const ib = Math.min(n - 1, i + 1);
        let tx = pts[ib][0] - pts[ia][0];
        let tz = pts[ib][1] - pts[ia][1];
        const l = Math.hypot(tx, tz) || 1;
        tx /= l;
        tz /= l;
        const [x, z] = pts[i];
        this.samples.push([
          x,
          z,
          tx,
          tz,
          hwAt(x, z),
          P.lv[i] + (P.bias || 0),
          (P.lv[ib] - P.lv[ia]) / (P.arc[ib] - P.arc[ia] || 1),
        ]);
      }
    }
    this.indexSamples();
  }

  public blocked(x: number, z: number, m = 0): boolean {
    const ids = this.hgrid.get(Math.floor(x / 30) * 4096 + Math.floor(z / 30));
    if (!ids) return false;
    for (const id of ids) {
      const [cx, cz, hw, hd] = this.rects[id];
      if (Math.abs(x - cx) < hw + m && Math.abs(z - cz) < hd + m) return true;
    }
    return false;
  }

  public indexSamples(): void {
    this.sgrid = new Map();
    for (const q of this.samples) {
      const k = Math.floor(q[0] / 12) * 4096 + Math.floor(q[1] / 12);
      const arr = this.sgrid.get(k) || [];
      arr.push(q);
      this.sgrid.set(k, arr);
    }
  }

  public nearestRoad(x: number, z: number): [number, number, number, number, number, number, number] {
    let b: [number, number, number, number, number, number, number] = this.samples[0];
    let bd = 1e18;
    for (const s of this.samples) {
      const d = (s[0] - x) ** 2 + (s[1] - z) ** 2;
      if (d < bd) {
        bd = d;
        b = s;
      }
    }
    return b;
  }

  /**
   * Eliminates see-through walls by adding deep foundation skirts (y - 3.5m)
   * into the sloped terrain and using DoubleSide solid materials.
   */
  private buildHouses(): void {
    const rng = mulberry32(4242);
    const list: {
      x: number;
      z: number;
      w: number;
      d: number;
      st: number;
      wc: THREE.Color;
      rc: THREE.Color;
      store?: boolean;
    }[] = [];

    for (const [cx, cz, w, d] of V.houses) {
      const nx = Math.max(1, Math.round(w / 16));
      const nz = Math.max(1, Math.round(d / 16));
      const cw = w / nx;
      const cd = d / nz;
      const bazaar = cx > 1330;
      for (let i = 0; i < nx; i++) {
        for (let j = 0; j < nz; j++) {
          if (nx * nz > 3 && rng() < 0.12) continue;
          const hw_ = clamp(cw - 3 + rng() * 1.5, 5, 15);
          const hd_ = clamp(cd - 3 + rng() * 1.5, 5, 15);
          list.push({
            x: cx - w / 2 + cw * (i + 0.5),
            z: cz - d / 2 + cd * (j + 0.5),
            w: hw_,
            d: hd_,
            st: bazaar ? 2 + Math.floor(rng() * 2) : 1 + Math.floor(rng() * 2),
            wc: WALLS[Math.floor(rng() * WALLS.length)],
            rc: ROOFS[Math.floor(rng() * ROOFS.length)],
          });
        }
      }
    }

    let store = null;
    for (const h of list) {
      if (Math.abs(h.x - 50) < 50 && Math.abs(h.z - 401) < 50 && (!store || h.z < store.z)) {
        store = h;
      }
    }
    if (store) {
      store.wc = col(0xe4c15a);
      store.rc = col(0xa83a2e);
      store.st = 2;
      store.store = true;
      this.store = store;
    }

    const win: [number, number, number, number, number?][] = [];
    for (const h of list) {
      const longX = h.w >= h.d;
      const L = longX ? h.w : h.d;
      const n = Math.max(1, Math.floor(L / 3.4));
      for (let f = 0; f < h.st; f++) {
        for (let k = 0; k < n; k++) {
          for (const sd of [-1, 1]) {
            const u = ((k + 0.5) / n) * L - L / 2;
            const off = sd * ((longX ? h.d : h.w) / 2 + 0.03);
            win.push(
              longX
                ? [h.x + u, f * 3.1 + 1.9, h.z + off, 0]
                : [h.x + off, f * 3.1 + 1.9, h.z + u, Math.PI / 2]
            );
          }
        }
      }
      const dd = (longX ? h.d : h.w) / 2 + 0.05;
      win.push(longX ? [h.x, 1.05, h.z + dd, 0, 1] : [h.x + dd, 1.05, h.z, Math.PI / 2, 1]);
    }

    const walls = inst(this.group, boxGeo, wallMat, list.length);
    const roofs = inst(this.group, roofGeo, roofMat, list.length);
    const wins = inst(this.group, boxGeo, winMat, win.length);

    this.rects = list.map((h) => [h.x, h.z, h.w / 2, h.d / 2]);
    this.hgrid = new Map();

    list.forEach((h, id) => {
      const y = this.hAt(h.x, h.z);
      const H = h.st * 3.1;
      const longX = h.w >= h.d;
      // Foundation depth 3.5m embedded into ground eliminates any see-through bottom gaps on hillside slopes!
      const foundationDepth = 3.5;
      put(walls, h.x, y - foundationDepth, h.z, h.w, H + foundationDepth, h.d, 0, h.wc.r, h.wc.g, h.wc.b);
      put(
        roofs,
        h.x,
        y + H,
        h.z,
        (longX ? h.d : h.w) + 1.2,
        1.8,
        (longX ? h.w : h.d) + 1.2,
        longX ? Math.PI / 2 : 0,
        h.rc.r,
        h.rc.g,
        h.rc.b
      );

      for (let gx = Math.floor((h.x - h.w) / 30); gx <= Math.floor((h.x + h.w) / 30); gx++) {
        for (let gz = Math.floor((h.z - h.d) / 30); gz <= Math.floor((h.z + h.d) / 30); gz++) {
          const k = gx * 4096 + gz;
          const arr = this.hgrid.get(k) || [];
          arr.push(id);
          this.hgrid.set(k, arr);
        }
      }
    });

    for (const w of win) {
      const door = w[4];
      const y = this.hAt(w[0], w[2]) + w[1];
      if (door) {
        put(wins, w[0], y - 1.05, w[2], 1.1, 2.1, 0.12, w[3], 0.65, 0.38, 0.22);
      } else if (rng() < 0.4) {
        put(this.lit, w[0], y - 0.55, w[2], 0.9, 1.1, 0.12, w[3], 1, 0.7 + rng() * 0.15, 0.35);
      } else {
        put(wins, w[0], y - 0.55, w[2], 0.9, 1.1, 0.1, w[3], 0.95, 0.96, 0.98);
      }
    }

    done(walls);
    done(roofs);
    done(wins);
    done(this.lit);
    this.houseCount = list.length;
  }

  public sign(
    text: string,
    x: number,
    z: number,
    ry: number,
    w: number,
    h: number,
    bg: string,
    fg: string,
    y0: number
  ): void {
    const y = this.hAt(x, z);
    const tex = canvasTex(
      text,
      1024,
      Math.round((1024 * h) / w),
      bg,
      fg,
      `bold ${Math.round(((1024 * h) / w) * 0.5)}px Arial`
    );
    const b = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tex }));
    b.position.set(x, y + y0, z);
    b.rotation.y = ry;
    this.group.add(b);

    if (y0 > 3) {
      for (const sd of [-1, 1]) {
        const p = new THREE.Mesh(
          new THREE.BoxGeometry(0.15, y0 + h / 2, 0.15),
          new THREE.MeshStandardMaterial({ color: 0x555555 })
        );
        p.position.set(
          x + Math.cos(ry) * sd * (w / 2 - 0.3),
          y + (y0 + h / 2) / 2,
          z - Math.sin(ry) * sd * (w / 2 - 0.3)
        );
        this.group.add(p);
      }
    }
  }

  private buildSigns(): void {
    if (this.store) {
      this.sign(
        'PUSHPA STORE',
        this.store.x,
        this.store.z - this.store.d / 2 - 0.15,
        Math.PI,
        Math.min(this.store.w, 8),
        1.5,
        '#7a1d1d',
        '#ffe9a8',
        2.9
      );
    }
    const a = this.nearestRoad(V.start.x + 40, V.start.z);
    const b = this.nearestRoad(1340, 490);
    this.sign(
      'WELCOME TO GAIRIGAON \u00b7 2486 m',
      a[0],
      a[1] - a[4] - 4,
      -Math.PI / 2,
      8,
      1.8,
      '#14532d',
      '#ffffff',
      3.6
    );
    {
      const h = this.nearestRoad(560, 356);
      this.sign(
        'SHARP HAIRPIN BENDS AHEAD \u00b7 DRIVE WITH CARE',
        h[0],
        h[1] - h[4] - 4,
        -Math.PI / 2,
        8.5,
        1.8,
        '#b45309',
        '#ffffff',
        3.6
      );
    }
    this.sign(
      'RIMBICK BAZAAR \u00b7 2286 m',
      b[0],
      b[1] - b[4] - 4,
      -Math.PI / 2,
      8,
      1.8,
      '#1e3a8a',
      '#ffffff',
      3.6
    );

    // Street lamps along the main road
    const lamps = inst(this.group, lampGeo, lampMat, 30);
    for (let i = 0; i < this.samples.length; i += 22) {
      const sm = this.samples[i];
      const y = sm[5];
      const off = sm[4] + 1.2;
      const lx = sm[0] + sm[3] * off;
      const lz = sm[1] - sm[2] * off;
      put(lamps, lx, y, lz, 1, 1, 1, Math.atan2(sm[2], sm[3]), 1, 1, 1);
    }
    done(lamps);
  }

  /**
   * Authentic Himalayan Lungta (Tibetan Prayer Flags) along scenic mountain road crests.
   * Colors: Blue (sky), White (air), Red (fire), Green (water), Yellow (earth).
   */
  private buildPrayerFlags(): void {
    const flagColors = [0x2f6fd4, 0xf0f0f0, 0xd42f2f, 0x2fd44e, 0xf0cc2f];
    const flagGeo = new THREE.PlaneGeometry(0.35, 0.45);
    const flagMats = flagColors.map(
      (c) =>
        new THREE.MeshStandardMaterial({
          color: c,
          side: THREE.DoubleSide,
          roughness: 0.9,
        })
    );

    const passSpots = [
      [580, 360],
      [1400, 480],
      [1950, 515],
    ];

    for (const [px, pz] of passSpots) {
      const sm = this.nearestRoad(px, pz);
      const poleX = sm[0] + sm[3] * (sm[4] + 1.8);
      const poleZ = sm[1] - sm[2] * (sm[4] + 1.8);
      const y = sm[5];

      // Two wooden poles connected by rope
      for (let f = 0; f < 8; f++) {
        const mat = flagMats[f % flagMats.length];
        const flagMesh = new THREE.Mesh(flagGeo, mat);
        flagMesh.position.set(poleX + (f - 4) * 0.55, y + 2.4 - Math.sin((f / 7) * Math.PI) * 0.3, poleZ);
        flagMesh.rotation.y = Math.PI / 4 + Math.sin(f) * 0.2;
        this.group.add(flagMesh);
      }
    }
  }

  public setNight(f: number): void {
    this.lit.visible = f > 0.3;
  }

  public setVeg(v: number): void {
    if (Math.abs(v - this.veg) > 1e-3) this.buildVeg(v);
  }

  public buildVeg(veg: number): void {
    this.veg = veg;
    if (this.vegGroup) {
      this.group.remove(this.vegGroup);
      this.vegGroup.traverse((o) => {
        if ((o as THREE.InstancedMesh).isInstancedMesh) {
          (o as THREE.InstancedMesh).geometry.dispose();
        }
      });
    }
    const vg = (this.vegGroup = new THREE.Group());
    this.group.add(vg);
    this.tiles = [];
    const rng = mulberry32(99);
    const T = new Map<string, Record<string, number[][]>>();
    const STEP = 11;

    const add = (key: string, type: string, a: number[]) => {
      let t = T.get(key);
      if (!t) T.set(key, (t = { pine: [], cedar: [], leaf: [], bush: [], grass: [] }));
      t[type].push(a);
    };

    // Lush Euro Truck Simulator 2 roadside grass and wildflower tufts along both shoulders
    for (let i = 0; i < this.samples.length; i += 3) {
      const sm = this.samples[i];
      if (!sm || sm[0] < -80 || sm[0] > 1980) continue;
      const hw = sm[4];
      for (const side of [-1, 1]) {
        if (rng() > 0.82 * veg) continue;
        const distFromCenter = hw + 0.4 + rng() * 2.2;
        const gx = sm[0] + sm[3] * distFromCenter * side + (rng() - 0.5) * 0.8;
        const gz = sm[1] - sm[2] * distFromCenter * side + (rng() - 0.5) * 0.8;
        const df_ = fs(this.df.d, gx, gz);
        if (df_ < 2.5) continue;
        const key = Math.floor(gx / 250) + ',' + Math.floor(gz / 250);
        const gy = this.hAt(gx, gz);
        const gs = 0.85 + rng() * 0.65;
        const gk = 0.85 + rng() * 0.35;
        add(key, 'grass', [
          gx,
          gy,
          gz,
          gs,
          gs * (0.9 + rng() * 0.4),
          rng() * 6.28,
          gk,
          gk,
          gk * 0.9,
        ]);
      }
    }

    for (let x = -120; x < 2000; x += STEP) {
      for (let z = -170; z < 1170; z += STEP) {
        const px = x + (rng() - 0.5) * STEP;
        const pz = z + (rng() - 0.5) * STEP;
        const df = fs(this.df.d, px, pz);
        if (df < 7) {
          rng();
          rng();
          rng();
          continue;
        }
        const key = Math.floor(px / 250) + ',' + Math.floor(pz / 250);
        const y = this.hAt(px, pz);
        const sl = Math.abs(this.hAt(px + 5, pz) - y) + Math.abs(this.hAt(px, pz + 5) - y);
        const f = fbm2(791, px / 170, pz / 170, 3);
        const r1 = rng();
        const r2 = rng();
        const r3 = rng();
        const s = 0.7 + rng() * 0.9;
        const k = 0.8 + rng() * 0.4;

        if (df > 10 && sl < 8 && r1 < (0.18 + 0.75 * sstep(0.45, 0.62, f)) * veg * 0.95) {
          add(key, r2 < 0.35 ? 'pine' : r2 < 0.6 ? 'cedar' : 'leaf', [
            px,
            y - 0.1,
            pz,
            s,
            s * (0.85 + k * 0.3),
            rng() * 6.28,
            k,
            k * 0.95,
            k * 0.85,
          ]);
        }
        if (sl < 8 && r3 < (0.25 + 0.4 * sstep(0.4, 0.6, f)) * veg) {
          add(key, 'bush', [
            px + 3,
            this.hAt(px + 3, pz),
            pz,
            0.6 + s * 0.6,
            0.6 + s * 0.6,
            rng() * 6,
            k * 0.8,
            k,
            k * 0.7,
          ]);
        }
        if (df > 4 && rng() < 0.85 * veg) {
          const gx = px - 4;
          const gz = pz + 2;
          add(key, 'grass', [
            gx,
            this.hAt(gx, gz),
            gz,
            0.9 + s * 0.5,
            0.9 + s * 0.5,
            rng() * 6,
            k,
            k,
            k * 0.85,
          ]);
        }
      }
    }

    const spec: Record<string, [THREE.BufferGeometry, THREE.Material, boolean]> = {
      pine: [pineGeo, treeMat, true],
      cedar: [cedarGeo, treeMat, true],
      leaf: [leafGeo, treeMat, true],
      bush: [bushGeo, bushMat, false],
      grass: [grassGeo, grassMat, false],
    };

    for (const [key, t] of T) {
      const [ti, tj] = key.split(',').map(Number);
      const g = new THREE.Group();
      g.userData.c = [(ti + 0.5) * 250, (tj + 0.5) * 250];

      for (const type in spec) {
        const arr = t[type];
        if (!arr.length) continue;
        const m = inst(g, spec[type][0], spec[type][1], arr.length, spec[type][2]);
        for (const a of arr) {
          put(m, a[0], a[1], a[2], a[3], a[4], a[3], a[5], a[6], a[7], a[8]);
        }
        done(m);
      }
      vg.add(g);
      this.tiles.push(g);
    }
  }

  public update(cx: number, cz: number, dist: number): void {
    for (const g of this.tiles) {
      g.visible = Math.hypot(cx - g.userData.c[0], cz - g.userData.c[1]) < dist + 220;
    }
  }

  public collide(v: Vehicle): void {
    const r = Math.max(v.def.width / 2 + 0.3, 1.1);
    const ids = this.hgrid.get(Math.floor(v.x / 30) * 4096 + Math.floor(v.z / 30));
    if (!ids) return;

    for (const id of ids) {
      const [cx, cz, hw, hd] = this.rects[id];
      const dx = v.x - cx;
      const dz = v.z - cz;
      const px = hw + r - Math.abs(dx);
      const pz = hd + r - Math.abs(dz);

      if (px > 0 && pz > 0) {
        if (px < pz) {
          v.x += Math.sign(dx) * px;
          if (v.vx * dx < 0) v.vx *= -0.2;
        } else {
          v.z += Math.sign(dz) * pz;
          if (v.vz * dz < 0) v.vz *= -0.2;
        }
        v.vx *= 0.9;
        v.vz *= 0.9;
      }
    }
  }
}
