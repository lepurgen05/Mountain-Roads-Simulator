/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { fbm1, sstep, mulberry32 } from '../core/noise.ts';

export const DS = 4; // road sample spacing (m)
export const BASE_ALT = 2103; // altitude offset (Gairigaon = 2,103m)

// Altitude plan [from m, to m, grade]
export const WP: [number, number, number][] = [
  [2286, 1500, 0.09],
  [1500, 2000, 0.09],
  [2000, 1000, 0.09],
  [1000, 1500, 0.09],
  [1500, 500, 0.09],
  [500, 150, 0.035],
  [150, 2286, 0.09],
];

export interface Leg {
  a: number;
  b: number;
  s0: number;
  L: number;
}

export const LEG: Leg[] = [];
let TOT = 0;
for (const [a, b, g] of WP) {
  const L = Math.abs(b - a) / g;
  LEG.push({ a, b, s0: TOT, L });
  TOT += L;
}

const ease = (t: number) => {
  const r = 0.08;
  let F: number;
  if (t < r) {
    const u = t / r;
    F = r * (u ** 3 - u ** 4 / 2);
  } else if (t > 1 - r) {
    const u = (1 - t) / r;
    F = 1 - r - r * (u ** 3 - u ** 4 / 2);
  } else {
    F = r / 2 + (t - r);
  }
  return F / (1 - r);
};

export const CYCLE = TOT;

export const ZONES = (() => {
  const z = LEG.map((g, i) => ({
    name:
      Math.round(g.a) +
      ' \u2192 ' +
      Math.round(g.b) +
      ' m' +
      (i === 5 ? ' (Plains Highway)' : ''),
    s: g.s0 + 1,
  }));
  for (const [i, t] of [
    [0, 0.3],
    [2, 0.3],
    [4, 0.18],
  ] as const) {
    z.push({
      name: 'Narrow Cliff Road (Bolivia Yungas style)',
      s: LEG[i].s0 + LEG[i].L * t - 150,
    });
  }
  return z.sort((a, b) => a.s - b.s);
})();

export const legAt = (s: number): [number, number] => {
  s = s % TOT;
  let i = 0;
  while (i < LEG.length - 1 && s >= LEG[i].s0 + LEG[i].L) i++;
  return [i, (s - LEG[i].s0) / LEG[i].L];
};

export const altPlan = (s: number): number => {
  const [i, t] = legAt(s);
  const g = LEG[i];
  return g.a + (g.b - g.a) * ease(t);
};

// 0 = hill road, 1 = narrow cliff road (Bolivia Yungas style), 2 = Indian highway (plains)
export const styleAt = (s: number): number => {
  const [i, t] = legAt(s);
  if (i === 5 || (i === 6 && t < 0.12)) return 2;
  if (
    (i === 0 && t > 0.3 && t < 0.5) ||
    (i === 2 && t > 0.3 && t < 0.52) ||
    (i === 4 && t > 0.18 && t < 0.34)
  )
    return 1;
  return 0;
};

export class Road {
  public seed: number;
  public h0: number;
  public rng: () => number;
  public segs: [number, number, number][] = [];
  public sEnd: number = 0;
  public segI: number = 0;
  public rh: Map<number, number[]> = new Map();
  public hist: [number, number, number, number][] = [];
  public out: number = 0;
  public bt: number = 0;

  public x: number[];
  public z: number[];
  public h: number[];
  public y: number[];
  public w: number[];
  public sty: number[];
  public yz: number[];
  public hz: number[];
  public y0: number;

  constructor(seed: number, o: { h?: number; x?: number; z?: number } = {}) {
    this.seed = seed | 0;
    this.h0 = o.h || 0;
    this.rng = mulberry32(this.seed * 13 + 7);
    this.x = [o.x || 0];
    this.z = [o.z || 0];
    this.h = [this.h0];
    this.y = [altPlan(0) - BASE_ALT];
    this.w = [3.3];
    this.sty = [0];
    this.yz = [0];
    this.hz = [0];
    this.y0 = this.y[0];
    this.hashRow(0);
    this.seg(300, 0);
  }

  public seg(len: number, k: number): void {
    this.segs.push([this.sEnd, this.sEnd + len, k]);
    this.sEnd += len;
  }

  public arc(R: number, deg: number, dir: number): void {
    this.seg((R * deg * Math.PI) / 180, dir / R);
  }

  public build(): void {
    const r = this.rng;
    const st = styleAt(this.sEnd + 150);
    const e = this.h[this.h.length - 1] - this.h0;
    const dir = () => (r() < 0.5 + Math.max(-0.35, Math.min(0.35, -e * 0.5)) ? 1 : -1);
    const p = r();

    if (st === 2) {
      this.seg(400 + r() * 800, 0);
      const R = 700 + r() * 800;
      this.arc(R, 8 + r() * 14, dir());
      return;
    }

    if (st === 1) {
      if (p < 0.3) this.seg(60 + r() * 150, 0);
      else if (p < 0.65) this.arc(90 + r() * 120, 25 + r() * 55, dir());
      else {
        const R = 70 + r() * 50;
        const d = dir();
        this.arc(R, 40 + r() * 50, d);
        this.arc(R, 40 + r() * 50, -d);
      }
      return;
    }

    if (p < 0.1) {
      this.seg(40 + r() * 140, 0);
    } else if (p < 0.45) {
      this.arc(110 + r() * 200, 20 + r() * 60, dir());
    } else if (p < 0.8) {
      const R = 45 + r() * 70;
      const d = dir();
      this.arc(R, 50 + r() * 70, d);
      this.seg(8 + r() * 25, 0);
      this.arc(R, 50 + r() * 70, -d);
    } else {
      const R = 22 + r() * 14;
      const n = 2 * (1 + Math.floor(r() * 2));
      let d = dir();
      this.seg(15 + r() * 30, 0);
      for (let k = 0; k < n; k++) {
        this.arc(R, 170 + r() * 15, d);
        d = -d;
        if (k < n - 1) this.seg(40 + r() * 70, 0);
      }
    }
  }

  public kAt(s: number): number {
    let j = this.segI;
    while (this.segs[j][1] <= s) j++;
    this.segI = j;
    const sg = this.segs[j];
    let k = sg[2];
    if (j > 0 && s - sg[0] < 24) {
      k = this.segs[j - 1][2] + (k - this.segs[j - 1][2]) * sstep(0, 24, s - sg[0]);
    }
    return k;
  }

  public lay(): void {
    while ((this.x.length - 1) * DS < this.sEnd) {
      const i = this.x.length;
      const p = i - 1;
      const h = this.h[p];
      const s = p * DS;
      const s1 = i * DS;
      const st = styleAt(s1);

      this.x.push(this.x[p] + Math.sin(h) * DS);
      this.z.push(this.z[p] + Math.cos(h) * DS);
      this.h.push(h + (this.kAt(s) - (h - this.h0) * 0.0002) * DS);

      const tgt =
        st === 2
          ? 7.0
          : st === 1
          ? 1.7
          : 2.1 + 2.5 * sstep(0.4, 0.6, fbm1(this.seed + 31, s1 / 300, 2)) + 0.3 * fbm1(this.seed + 32, s1 / 70, 2);

      this.w.push(this.w[p] + (tgt - this.w[p]) * 0.12);
      this.sty.push(st);
      this.hz.push(this.hz[p] + ((st === 2 ? 1 : 0) - this.hz[p]) * 0.03);
      this.yz.push(this.yz[p] + ((st === 1 ? 1 : 0) - this.yz[p]) * 0.05);
      this.y.push(altPlan(s1) + 5 * (fbm1(this.seed + 21, s1 / 400, 2) - 0.5) * 2 * sstep(0, 400, s1) - BASE_ALT);
    }
  }

  public hashRow(i: number): void {
    const k = Math.floor(this.x[i] / 40) * 8192 + Math.floor(this.z[i] / 40);
    let a = this.rh.get(k);
    if (!a) this.rh.set(k, (a = []));
    a.push(i);
  }

  public conflict(n0: number): boolean {
    const EX = 14;
    const n = this.x.length;
    for (let i = n0; i < n; i += 2) {
      const x = this.x[i];
      const z = this.z[i];
      const cx = Math.floor(x / 40);
      const cz = Math.floor(z / 40);
      for (let a = -1; a <= 1; a++) {
        for (let b = -1; b <= 1; b++) {
          const arr = this.rh.get((cx + a) * 8192 + cz + b);
          if (arr) {
            for (const j of arr) {
              if (j < i - EX && (this.x[j] - x) ** 2 + (this.z[j] - z) ** 2 < 1600) return true;
            }
          }
        }
      }
      for (let j = n0; j < i - EX; j += 2) {
        if ((this.x[j] - x) ** 2 + (this.z[j] - z) ** 2 < 1600) return true;
      }
    }
    return false;
  }

  public trim(n: number): void {
    for (const a of [this.x, this.z, this.h, this.y, this.w, this.sty, this.yz, this.hz]) {
      a.length = n;
    }
  }

  public unhash(from: number): void {
    for (let i = this.x.length - 1; i >= from; i--) {
      const a = this.rh.get(Math.floor(this.x[i] / 40) * 8192 + Math.floor(this.z[i] / 40));
      if (a && a[a.length - 1] === i) a.pop();
    }
  }

  public extend(): void {
    for (;;) {
      const j0 = this.segs.length;
      const s0 = this.sEnd;
      const n0 = this.x.length;
      const si = this.segI;
      const reset = () => {
        this.segs.length = j0;
        this.sEnd = s0;
        this.segI = si;
        this.trim(n0);
      };
      const ok = () => !this.conflict(n0);
      const done = () => {
        for (let i = n0; i < this.x.length; i++) this.hashRow(i);
        this.hist.push([j0, s0, n0, si]);
        this.bt = 0;
      };

      for (let t = 0; t < 24; t++) {
        reset();
        this.build();
        this.lay();
        if (ok()) return done();
      }

      const hwy = styleAt(s0 + 150) === 2;
      const esc: [number, number][] = hwy
        ? [
            [0, 0],
            [500, 20],
            [500, -20],
            [350, 45],
            [350, -45],
            [250, 90],
            [250, -90],
            [200, 150],
            [200, -150],
          ]
        : [
            [0, 0],
            [60, 30],
            [60, -30],
            [60, 60],
            [60, -60],
            [50, 100],
            [50, -100],
            [40, 150],
            [40, -150],
            [22, 180],
            [22, -180],
          ];

      for (const [R, deg] of esc) {
        reset();
        if (R) {
          this.seg(30, 0);
          this.arc(R, Math.abs(deg), Math.sign(deg));
        } else {
          this.seg(60, 0);
        }
        this.lay();
        if (ok()) return done();
      }

      const last = this.hist[this.hist.length - 1];
      if (last && last[2] > this.out && this.bt < 400) {
        this.bt++;
        reset();
        for (let k = 0; k < 3 && this.hist.length && this.hist[this.hist.length - 1][2] > this.out; k++) {
          const [hj, hs, hn, hsi] = this.hist.pop()!;
          this.unhash(hn);
          this.segs.length = hj;
          this.sEnd = hs;
          this.segI = hsi;
          this.trim(hn);
        }
        continue;
      }

      reset();
      this.seg(60, 0);
      this.lay();
      return done();
    }
  }

  public ensure(n: number): void {
    while (this.x.length <= n + 800) this.extend();
    if (n > this.out) this.out = n;
  }
}
