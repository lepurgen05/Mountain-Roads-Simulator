/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface VehicleDefinition {
  key: string;
  type: 'hatch' | 'thar' | 'truck' | 'bus';
  name: string;
  tagline: string;
  color: number;
  accent?: number;
  mass: number;
  wheelR: number;
  tw: number;
  wheelbase: number;
  track: number;
  width: number;
  length: number;
  roofY: number;
  maxSpeed: number; // m/s
  gears: number[];
  reverseRatio: number;
  final: number;
  eta: number;
  idle: number;
  redline: number;
  upRpm: number;
  downRpm: number;
  clutchRpm: number;
  engBrake: number;
  maxReverse: number;
  maxSteer: number;
  torque: [number, number][];
  cdA: number;
  crr: number;
  mu: number;
  stiff: number;
  brakeG: number;
  driveShare: number;
  fuelCapacity: number; // Tank capacity in Liters
  fuelType: 'Petrol' | 'Diesel';
  fuelEfficiency: number; // km/L nominal rating
  cam: {
    s: number;
    cockpit: [number, number, number];
    hood: [number, number, number];
    tilt?: number;
    swR?: number;
  };
}

export interface FuelStation {
  id: string;
  name: string;
  locationName: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  radius: number; // trigger radius
  pricePerLiter: number; // in INR
  fuelType: 'Petrol & Diesel' | 'Diesel Only' | 'Petrol Only';
}

export interface FuelState {
  fuel: number; // current Liters
  capacity: number; // max Liters
  percent: number; // 0 - 100
  rateLps: number; // current consumption in L/s
  rateL100km: number; // instant L / 100km
  rangeKm: number; // estimated range in km
  isLow: boolean; // < 15%
  isCritical: boolean; // < 5%
  isOut: boolean; // 0 L
  isRefueling: boolean;
  refuelProgress: number; // 0 - 100%
  refueledLitersThisSession: number;
  totalCostThisSession: number;
  nearestStation: {
    station: FuelStation;
    distance: number;
    inBay: boolean;
  } | null;
}

export type GraphicsPreset = 'Low' | 'Medium' | 'High' | 'Ultra' | 'Custom';

export interface GameSettings {
  preset: GraphicsPreset;
  resolution: number; // 50 - 150 %
  renderDistance: number; // 3 - 10 (chunks ahead)
  shadows: 'Off' | 'Low' | 'High';
  antialias: boolean;
  vegetation: number; // 0 - 100 %
  effects: 'Low' | 'High';
  headlight: number; // 50 - 250 %
  lodScale: number; // 0.5 - 1.5
  traffic: boolean;
  trafficDensity: number; // 0 - 100 %
  autoWeather: boolean;
  liveWeather: boolean;
  autoTime: boolean;
  timeMode: 'Real time' | 'x10' | 'x60' | 'x300';
  fixedTimeHour: number; // -1 for dynamic, or 0-24
  camMode: number;
  fov: number;
  camDist: number;
  camHeight: number;
  camSens: number;
  shake: boolean;
  master: number;
  engineVol: number;
  envVol: number;
  weatherVol: number;
  vehicle: string;
  seed: string;
  manualGear: boolean;
  speedSteerEnabled?: boolean;
  speedSteerSensitivity?: number; // 0 - 100%
  steerSensitivity?: number; // 50 - 150%
}

export interface TunnelDef {
  startRow: number;
  endRow: number;
  length: number;
  name: string;
  portalStart: { x: number; y: number; z: number; yaw: number };
  portalEnd: { x: number; y: number; z: number; yaw: number };
}

export interface RoadSampleState {
  i: number;
  off: number;
  hw: number;
  rx: number;
  rz: number;
  sty?: number;
  endless?: boolean;
  dom?: number; // 0 = village, 1 = endless
  inTunnel?: boolean;
}

export interface WeatherState {
  cloud: number;
  rain: number;
  fog: number;
  snow: number;
  storm: number;
  temp: number;
  wet: number;
  flash: number;
  wind: number;
  label: string;
}

export type NavManeuverType =
  | 'straight'
  | 'slight_left'
  | 'slight_right'
  | 'turn_left'
  | 'turn_right'
  | 'sharp_left'
  | 'sharp_right'
  | 'hairpin_left'
  | 'hairpin_right'
  | 'tunnel_entry'
  | 'destination';

export interface NavInstruction {
  type: NavManeuverType;
  distanceM: number;
  text: string;
  roadName: string;
  subtext?: string;
  speedLimitKmh?: number;
}

export interface NavDestination {
  id: string;
  name: string;
  category: 'Village' | 'Fuel' | 'Pass' | 'Highway' | 'Scenic';
  x: number;
  z: number;
  description: string;
  icon?: string;
}

export interface MultiplayerPlayerState {
  id: string;
  name: string;
  vehicle: string;
  color: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  roll: number;
  speedKmh: number;
  lights: boolean;
  brake: boolean;
  horn: boolean;
  fuelLiters: number;
  lastSeen: number;
}

export interface MultiplayerChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
}

