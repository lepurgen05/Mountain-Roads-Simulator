/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { NavDestination, NavInstruction, NavManeuverType, RoadSampleState } from '../types.ts';
import { Road } from '../world/road.ts';
import { sound } from '../audio/SoundEngine.ts';

export const POPULAR_DESTINATIONS: NavDestination[] = [
  {
    id: 'rimbick_bazaar',
    name: 'Rimbick Bazaar',
    category: 'Village',
    x: 1450,
    z: 490,
    description: 'Central hill station marketplace, local tea stalls & workshops',
    icon: 'Store',
  },
  {
    id: 'gairigaon_monastery',
    name: 'Gairigaon Drukpa Gompa',
    category: 'Scenic',
    x: 230,
    z: 275,
    description: 'Grand Tibetan Buddhist monastery with golden Dharmachakra & prayer wheels',
    icon: 'Landmark',
  },
  {
    id: 'gairigaon_depot',
    name: 'Gairigaon Hill Fuel Depot',
    category: 'Fuel',
    x: 136,
    z: 374,
    description: 'Hilltop petrol & diesel refuel station near Pushpa General Store',
    icon: 'Fuel',
  },
  {
    id: 'rimbick_pump',
    name: 'Indian Oil - Rimbick Auto Fuels',
    category: 'Fuel',
    x: 1448,
    z: 494,
    description: 'Main highway pump bay with 24/7 high-octane petrol & diesel',
    icon: 'Fuel',
  },
  {
    id: 'rimbick_tunnel',
    name: 'Rimbick Pass Tunnel',
    category: 'Pass',
    x: 2350,
    z: 580,
    description: 'Mountain pass tunnel cutting through rocky cliffs at 2,240m elevation',
    icon: 'Milestone',
  },
  {
    id: 'highway_oasis',
    name: 'Bharat Petroleum - Sukhia Oasis',
    category: 'Highway',
    x: 3500,
    z: 524,
    description: 'Scenic highway rest stop, service station, and fuel pump',
    icon: 'Fuel',
  },
  {
    id: 'gairigaon_village',
    name: 'Gairigaon Village Square',
    category: 'Village',
    x: 180,
    z: 390,
    description: 'Traditional Himalayan village settlement and starting viewpoint',
    icon: 'Home',
  },
];

export class NavigationEngine {
  public destinations: NavDestination[] = POPULAR_DESTINATIONS;
  public activeDestination: NavDestination | null = POPULAR_DESTINATIONS[0]; // Default to Rimbick Bazaar
  public lastInstruction: NavInstruction = {
    type: 'straight',
    distanceM: 0,
    text: 'Proceed to route',
    roadName: 'Gairigaon - Rimbick Road',
    speedLimitKmh: 40,
  };
  private lastAlertManeuver: string = '';
  private chimeThrottle = 0;

  public setDestination(destId: string | null): void {
    if (!destId) {
      this.activeDestination = null;
      return;
    }
    const match = this.destinations.find((d) => d.id === destId);
    if (match) {
      this.activeDestination = match;
      sound.navChime();
    }
  }

  public update(
    dt: number,
    carX: number,
    carZ: number,
    carYaw: number,
    speedKmh: number,
    road: Road | null,
    st: RoadSampleState
  ): {
    instruction: NavInstruction;
    totalDistanceM: number;
    etaMinutes: number;
    remainingKm: number;
    bearingDeg: number;
    destinationName: string;
    isArrived: boolean;
  } {
    this.chimeThrottle = Math.max(0, this.chimeThrottle - dt);

    if (!this.activeDestination) {
      // Free roam mode - provide road curve warnings
      const curveInfo = this.analyzeUpcomingCurve(carX, carZ, carYaw, road, st);
      this.lastInstruction = curveInfo;
      return {
        instruction: curveInfo,
        totalDistanceM: 0,
        etaMinutes: 0,
        remainingKm: 0,
        bearingDeg: 0,
        destinationName: 'Free Driving',
        isArrived: false,
      };
    }

    const dest = this.activeDestination;
    const dx = dest.x - carX;
    const dz = dest.z - carZ;
    const directDist = Math.hypot(dx, dz);

    // Target bearing relative to car heading
    const targetAngle = Math.atan2(dx, dz);
    let relBearing = targetAngle - carYaw;
    while (relBearing > Math.PI) relBearing -= Math.PI * 2;
    while (relBearing < -Math.PI) relBearing += Math.PI * 2;
    const bearingDeg = Math.round(relBearing * (180 / Math.PI));

    const isArrived = directDist < 25;

    let instruction: NavInstruction;

    if (isArrived) {
      instruction = {
        type: 'destination',
        distanceM: Math.round(directDist),
        text: `You have arrived at ${dest.name}`,
        roadName: dest.description,
        speedLimitKmh: 20,
      };
      if (this.lastAlertManeuver !== 'arrived' && this.chimeThrottle <= 0) {
        this.lastAlertManeuver = 'arrived';
        this.chimeThrottle = 10;
        sound.navChime();
      }
    } else if (st.inTunnel) {
      instruction = {
        type: 'tunnel_entry',
        distanceM: Math.round(Math.min(300, directDist)),
        text: 'Continue through mountain tunnel',
        roadName: 'Headlights required · Watch for oncoming traffic',
        speedLimitKmh: 45,
      };
    } else {
      // Check upcoming sharp bends on road ahead
      const curve = this.analyzeUpcomingCurve(carX, carZ, carYaw, road, st);

      if (curve.type !== 'straight' && curve.distanceM < 160) {
        instruction = curve;
      } else {
        // Standard turn guidance toward destination
        const roadName =
          carX < 1900
            ? 'Gairigaon - Rimbick Hill Road'
            : carX < 2600
            ? 'Rimbick Pass Highway'
            : 'Sukhia High Elevation Corridor';

        let type: NavManeuverType = 'straight';
        let text = `Continue on ${roadName}`;

        if (directDist < 120) {
          if (bearingDeg < -35) {
            type = 'turn_left';
            text = `In ${Math.round(directDist)}m, destination is on your left`;
          } else if (bearingDeg > 35) {
            type = 'turn_right';
            text = `In ${Math.round(directDist)}m, destination is on your right`;
          } else {
            type = 'straight';
            text = `In ${Math.round(directDist)}m, arrive at ${dest.name}`;
          }
        } else if (Math.abs(bearingDeg) > 60) {
          type = bearingDeg < 0 ? 'turn_left' : 'turn_right';
          text = `Follow road toward ${dest.name}`;
        }

        const speedLimit = Math.abs(bearingDeg) > 40 ? 35 : 50;

        instruction = {
          type,
          distanceM: Math.round(directDist),
          text,
          roadName,
          speedLimitKmh: speedLimit,
        };
      }
    }

    // Trigger subtle Google Maps chime on significant turn warnings < 70m
    if (
      (instruction.type === 'hairpin_left' ||
        instruction.type === 'hairpin_right' ||
        instruction.type === 'sharp_left' ||
        instruction.type === 'sharp_right') &&
      instruction.distanceM < 65 &&
      this.lastAlertManeuver !== `${instruction.type}_${Math.floor(instruction.distanceM / 20)}` &&
      this.chimeThrottle <= 0
    ) {
      this.lastAlertManeuver = `${instruction.type}_${Math.floor(instruction.distanceM / 20)}`;
      this.chimeThrottle = 8;
      sound.navChime();
    }

    this.lastInstruction = instruction;

    const remainingKm = +(directDist / 1000).toFixed(1);
    const avgSpeed = Math.max(25, speedKmh);
    const etaMinutes = Math.max(1, Math.round((directDist / 1000 / avgSpeed) * 60));

    return {
      instruction,
      totalDistanceM: Math.round(directDist),
      etaMinutes,
      remainingKm,
      bearingDeg,
      destinationName: dest.name,
      isArrived,
    };
  }

  private analyzeUpcomingCurve(
    carX: number,
    carZ: number,
    carYaw: number,
    road: Road | null,
    st: RoadSampleState
  ): NavInstruction {
    if (!road || st.dom === 0) {
      // In village area
      return {
        type: 'straight',
        distanceM: 50,
        text: 'Proceed through Gairigaon Village',
        roadName: 'Pushpa Bazaar Lane',
        speedLimitKmh: 30,
      };
    }

    const curIdx = Math.max(0, Math.floor(st.i));
    const lookAheadIdx = Math.min(road.x.length - 1, curIdx + 12);
    const midIdx = Math.min(road.x.length - 1, curIdx + 6);

    if (curIdx >= road.x.length || !road.x[curIdx] || !road.x[lookAheadIdx]) {
      return {
        type: 'straight',
        distanceM: 100,
        text: 'Continue on Mountain Road',
        roadName: 'NH-710 Himalayan Highway',
        speedLimitKmh: 50,
      };
    }

    const p0 = { x: road.x[curIdx], z: road.z[curIdx] };
    const p1 = { x: road.x[midIdx], z: road.z[midIdx] };
    const p2 = { x: road.x[lookAheadIdx], z: road.z[lookAheadIdx] };

    const yaw0 = Math.atan2(p1.x - p0.x, p1.z - p0.z);
    const yaw1 = Math.atan2(p2.x - p1.x, p2.z - p1.z);

    let dyaw = yaw1 - yaw0;
    while (dyaw > Math.PI) dyaw -= Math.PI * 2;
    while (dyaw < -Math.PI) dyaw += Math.PI * 2;

    const distAhead = Math.round(Math.hypot(p2.x - carX, p2.z - carZ));

    if (Math.abs(dyaw) > 0.9) {
      // Hairpin
      const isLeft = dyaw < 0;
      return {
        type: isLeft ? 'hairpin_left' : 'hairpin_right',
        distanceM: Math.max(15, distAhead - 20),
        text: isLeft ? 'Sharp Hairpin Left ahead' : 'Sharp Hairpin Right ahead',
        roadName: 'Reduce speed · Extreme mountain curve',
        speedLimitKmh: 25,
      };
    } else if (Math.abs(dyaw) > 0.45) {
      const isLeft = dyaw < 0;
      return {
        type: isLeft ? 'sharp_left' : 'sharp_right',
        distanceM: Math.max(20, distAhead - 15),
        text: isLeft ? 'In ' + distAhead + 'm, sharp left bend' : 'In ' + distAhead + 'm, sharp right bend',
        roadName: 'Mountain Ridge Highway',
        speedLimitKmh: 35,
      };
    } else if (Math.abs(dyaw) > 0.2) {
      const isLeft = dyaw < 0;
      return {
        type: isLeft ? 'slight_left' : 'slight_right',
        distanceM: distAhead,
        text: isLeft ? 'Gentle curve left' : 'Gentle curve right',
        roadName: 'Scenic Himalayan Corridor',
        speedLimitKmh: 50,
      };
    }

    return {
      type: 'straight',
      distanceM: distAhead + 80,
      text: 'Continue straight',
      roadName: 'Himalayan Mountain Road',
      speedLimitKmh: 50,
    };
  }
}
