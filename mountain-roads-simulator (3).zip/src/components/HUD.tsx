/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Compass, Cloud, Gauge, Mountain, SunMedium, Moon, Wind } from 'lucide-react';
import { WeatherState } from '../types.ts';

interface HUDProps {
  speedKmh: number;
  rpm: number;
  redline: number;
  gear: number;
  altitude: number;
  slope: number;
  locationName: string;
  weather: WeatherState;
  timeLabel: string;
  isNight: boolean;
  toastMessage: string | null;
  inTunnel: boolean;
  fps: number;
}

export const HUD: React.FC<HUDProps> = ({
  speedKmh,
  rpm,
  redline,
  gear,
  altitude,
  slope,
  locationName,
  weather,
  timeLabel,
  isNight,
  toastMessage,
  inTunnel,
  fps,
}) => {
  const displaySpeed = Math.round(speedKmh);
  const rpmPercent = Math.min(100, (rpm / redline) * 100);
  const slopeDeg = Math.round(slope * 45);

  return (
    <div className="pointer-events-none fixed inset-0 select-none z-20 flex flex-col justify-between p-4 md:p-6 font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Bar: Weather, Location & Time */}
      <div className="flex items-start justify-between">
        {/* Location & Altitude */}
        <div className="flex flex-col gap-1 bg-[#0b1118]/80 backdrop-blur-md border border-white/10 px-3.5 py-2 rounded-xl shadow-xl">
          <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs tracking-wider uppercase">
            <Mountain className="w-3.5 h-3.5" />
            <span>{locationName}</span>
            {inTunnel && (
              <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] px-1.5 py-0.5 rounded">
                TUNNEL
              </span>
            )}
          </div>
          <div className="flex items-center gap-3 text-xs text-white/70">
            <span>Alt: <strong className="text-white font-mono">{Math.round(altitude)} m</strong></span>
            <span>Grade: <strong className="text-white font-mono">{slopeDeg > 0 ? `+${slopeDeg}` : slopeDeg}°</strong></span>
          </div>
        </div>

        {/* Toast Notification in Center */}
        {toastMessage && (
          <div className="animate-in fade-in slide-in-from-top-4 duration-200 bg-black/85 text-amber-300 border border-amber-500/30 px-5 py-2 rounded-full text-xs font-medium tracking-wide shadow-2xl backdrop-blur-md">
            {toastMessage}
          </div>
        )}

        {/* Time, Weather & FPS */}
        <div className="flex items-center gap-2.5 bg-[#0b1118]/80 backdrop-blur-md border border-white/10 px-3.5 py-2 rounded-xl shadow-xl text-xs">
          <div className="flex items-center gap-1.5 text-white/90">
            {isNight ? (
              <Moon className="w-3.5 h-3.5 text-indigo-300" />
            ) : (
              <SunMedium className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span className="font-mono">{timeLabel} IST</span>
          </div>
          <div className="h-3 w-px bg-white/20" />
          <div className="flex items-center gap-1.5 text-white/80">
            <Cloud className="w-3.5 h-3.5 text-sky-400" />
            <span>{weather.label}</span>
            <span className="font-mono text-white">{Math.round(weather.temp)}°C</span>
          </div>
          <div className="h-3 w-px bg-white/20" />
          <div className="font-mono text-[11px] text-emerald-400">
            {fps} FPS
          </div>
        </div>
      </div>

      {/* Center-Bottom Cockpit Cluster */}
      <div className="self-center flex flex-col items-center mb-16 md:mb-18">
        <div className="flex items-baseline gap-2 drop-shadow-[0_4px_16px_rgba(0,0,0,0.8)]">
          <span className="text-6xl md:text-7xl font-extralight tracking-tighter text-white font-mono">
            {displaySpeed}
          </span>
          <span className="text-xs uppercase tracking-widest text-amber-400/90 font-semibold">
            km/h
          </span>
        </div>

        {/* Tachometer & Gear Bar */}
        <div className="flex items-center gap-3 bg-black/60 backdrop-blur-md border border-white/10 px-4 py-1.5 rounded-full mt-1">
          <div className="flex items-center gap-1 text-sm font-bold font-mono">
            <span className="text-white/40 text-xs">GEAR</span>
            <span className={gear < 0 ? 'text-rose-400' : 'text-amber-400'}>
              {gear < 0 ? 'R' : gear}
            </span>
          </div>
          {/* RPM progress bar */}
          <div className="w-28 md:w-36 h-2 bg-white/10 rounded-full overflow-hidden flex">
            <div
              className={`h-full transition-all duration-75 ${
                rpmPercent > 88
                  ? 'bg-rose-500 shadow-[0_0_8px_#f43f5e]'
                  : rpmPercent > 70
                  ? 'bg-amber-400'
                  : 'bg-emerald-400'
              }`}
              style={{ width: `${rpmPercent}%` }}
            />
          </div>
          <span className="font-mono text-xs text-white/70">
            {Math.round(rpm / 50) * 50}
          </span>
        </div>
      </div>
    </div>
  );
};
