/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Users, Wifi, Copy, Check, Car, Palette, Compass, ArrowRight, X, Play } from 'lucide-react';
import { MultiplayerPlayerState } from '../types.ts';
import { VEHICLES } from '../vehicle/definitions.ts';

interface MultiplayerLobbyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onJoinConvoy: () => void;
  localName: string;
  onUpdateName: (name: string) => void;
  selectedVehicle: string;
  onSelectVehicle: (key: string) => void;
  remotePlayers: MultiplayerPlayerState[];
  isConnected: boolean;
  connectionStatus: 'connecting' | 'connected' | 'disconnected';
  sharedSeed: number | null;
  onShowToast: (msg: string) => void;
}

export const MultiplayerLobbyModal: React.FC<MultiplayerLobbyModalProps> = ({
  isOpen,
  onClose,
  onJoinConvoy,
  localName,
  onUpdateName,
  selectedVehicle,
  onSelectVehicle,
  remotePlayers,
  isConnected,
  connectionStatus,
  sharedSeed,
  onShowToast,
}) => {
  const [copied, setCopied] = useState(false);
  const [nameInput, setNameInput] = useState(localName);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    try {
      navigator.clipboard.writeText(window.location.origin);
      setCopied(true);
      onShowToast('Convoy invite link copied! Send to friends to join this road.');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      onShowToast('Share URL: ' + window.location.origin);
    }
  };

  const handleNameBlur = () => {
    if (nameInput.trim()) {
      onUpdateName(nameInput.trim());
    }
  };

  const currentVehicleDef = VEHICLES[selectedVehicle] || VEHICLES.hatch800;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md pointer-events-auto select-none"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-gray-950 border border-white/20 rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-emerald-950/80 via-gray-900 to-gray-900 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-white text-lg tracking-wide">
                  Mountain Convoy Multiplayer
                </h3>
                <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-950 border border-emerald-500/40 text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  {isConnected ? 'ONLINE SERVER' : connectionStatus.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">
                Real-time synchronized driving across Darjeeling & Rimbick mountain passes
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* Driver Call Sign & Share Link */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="bg-gray-900/90 border border-white/10 rounded-2xl p-3.5 flex flex-col justify-between">
              <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                Your Driver Call Sign
              </label>
              <input
                type="text"
                value={nameInput}
                maxLength={16}
                onChange={(e) => setNameInput(e.target.value)}
                onBlur={handleNameBlur}
                className="bg-black/40 border border-white/10 focus:border-emerald-500 rounded-xl px-3 py-2 text-sm font-bold text-white mt-2 focus:outline-none"
                placeholder="e.g. Hill_Cruiser"
              />
            </div>

            <div className="bg-gray-900/90 border border-white/10 rounded-2xl p-3.5 flex flex-col justify-between">
              <div>
                <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                  Invite Link
                </label>
                <div className="text-xs text-gray-400 truncate mt-1">
                  Share with friends to drive together
                </div>
              </div>
              <button
                onClick={handleCopyLink}
                className="mt-2 w-full py-2 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold flex items-center justify-center gap-2 border border-white/10 transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400">Link Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-gray-300" />
                    <span>Copy Invite Link</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Vehicle Selector */}
          <div className="bg-gray-900/90 border border-white/10 rounded-2xl p-3.5">
            <div className="flex items-center justify-between mb-2.5">
              <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                <Car className="w-3.5 h-3.5 text-emerald-400" />
                <span>Select Your Convoy Vehicle</span>
              </label>
              <span className="text-xs text-emerald-400 font-bold font-mono">
                {currentVehicleDef.name}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {Object.entries(VEHICLES).map(([key, def]) => {
                const isSelected = selectedVehicle === key;
                return (
                  <button
                    key={key}
                    onClick={() => onSelectVehicle(key)}
                    className={`p-2.5 rounded-xl border text-left transition-all flex flex-col gap-1 ${
                      isSelected
                        ? 'bg-emerald-950/70 border-emerald-500 ring-1 ring-emerald-500/50'
                        : 'bg-black/40 hover:bg-black/60 border-white/5'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-white truncate">{def.name}</span>
                      <div
                        className="w-3 h-3 rounded-full shrink-0"
                        style={{ backgroundColor: `#${def.color.toString(16).padStart(6, '0')}` }}
                      />
                    </div>
                    <span className="text-[10px] text-gray-400 truncate">{def.tagline}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Drivers Roster */}
          <div className="bg-gray-900/90 border border-white/10 rounded-2xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-emerald-400" />
                <span>Drivers on Road ({remotePlayers.length + 1})</span>
              </label>
              <span className="text-[10px] text-gray-500 font-mono">
                Shared Seed: {sharedSeed || '194723'}
              </span>
            </div>

            <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
              {/* You */}
              <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-xs">
                <div className="flex items-center gap-2 truncate">
                  <div
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: `#${currentVehicleDef.color.toString(16).padStart(6, '0')}` }}
                  />
                  <span className="font-bold text-white truncate">{nameInput || localName} (You)</span>
                  <span className="text-[10px] text-gray-400">· {currentVehicleDef.name}</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-400 font-bold">READY</span>
              </div>

              {/* Other players */}
              {remotePlayers.length === 0 ? (
                <div className="p-3 text-center rounded-xl bg-black/30 border border-white/5">
                  <p className="text-xs text-gray-400">
                    No other drivers connected right now.
                  </p>
                  <p className="text-[11px] text-gray-500 mt-0.5">
                    Open another tab or send the invite link to friends to drive in real time!
                  </p>
                </div>
              ) : (
                remotePlayers.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between p-2 rounded-xl bg-black/40 border border-white/5 text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <div
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: `#${p.color.toString(16).padStart(6, '0')}` }}
                      />
                      <span className="font-semibold text-gray-200 truncate">{p.name}</span>
                      <span className="text-[10px] text-gray-400">
                        · {VEHICLES[p.vehicle]?.name || p.vehicle}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400">
                      {p.speedKmh > 0 ? `${p.speedKmh} km/h` : 'Parked'}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Footer / Join Button */}
        <div className="p-5 bg-gray-950 border-t border-white/10 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs font-semibold transition-colors"
          >
            Cancel
          </button>

          <button
            onClick={() => {
              handleNameBlur();
              onJoinConvoy();
              onClose();
            }}
            className="flex-1 py-3 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-sm tracking-wide flex items-center justify-center gap-2 shadow-xl shadow-emerald-950/40 transition-all hover:scale-[1.01]"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>START CONVOY DRIVE</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
