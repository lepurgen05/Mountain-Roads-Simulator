/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Camera,
  Car,
  Lightbulb,
  RotateCcw,
  SlidersHorizontal,
  Volume2,
  VolumeX,
  ChevronDown,
  ChevronUp,
  MapPin,
  Volume,
} from 'lucide-react';
import { VEHICLES } from '../vehicle/definitions.ts';

interface DockProps {
  currentVehicle: string;
  onSelectVehicle: (key: string) => void;
  camMode: number;
  onSelectCam: (mode: number) => void;
  headlightsOn: boolean;
  onToggleHeadlights: () => void;
  onRespawn: () => void;
  onNextZone: () => void;
  onOpenSettings: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const Dock: React.FC<DockProps> = ({
  currentVehicle,
  onSelectVehicle,
  camMode,
  onSelectCam,
  headlightsOn,
  onToggleHeadlights,
  onRespawn,
  onNextZone,
  onOpenSettings,
  isMuted,
  onToggleMute,
}) => {
  const [collapsed, setCollapsed] = useState(false);
  const [showVehPicker, setShowVehPicker] = useState(false);

  const camLabels = ['Chase', 'Close', 'Cockpit', 'Hood', 'Aerial'];
  const vehKeys = Object.keys(VEHICLES);

  return (
    <div className="fixed bottom-3 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center select-none font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Collapse / Expand Toggle Button */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="mb-1 px-3 py-0.5 bg-[#0b1118]/80 hover:bg-[#16202c] text-white/70 hover:text-white border border-white/10 rounded-full text-[11px] flex items-center gap-1 shadow-lg backdrop-blur-md cursor-pointer transition-all"
        title="Toggle HUD Dock"
      >
        {collapsed ? <ChevronUp className="w-3.5 h-3.5 text-amber-400" /> : <ChevronDown className="w-3.5 h-3.5 text-amber-400" />}
        <span>{collapsed ? 'Show Controls' : 'Hide Controls'}</span>
      </button>

      {/* Main Dock Container */}
      {!collapsed && (
        <div className="animate-in fade-in slide-in-from-bottom-2 duration-200 flex items-center gap-1.5 md:gap-2.5 bg-[#0b1118]/90 border border-white/15 px-3 py-2 rounded-2xl shadow-2xl backdrop-blur-xl max-w-[96vw]">
          {/* Camera View Switcher */}
          <div className="flex items-center bg-white/5 border border-white/10 rounded-xl p-0.5">
            {camLabels.map((name, idx) => (
              <button
                key={name}
                onClick={() => onSelectCam(idx)}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all cursor-pointer ${
                  camMode === idx
                    ? 'bg-amber-500 text-slate-950 font-semibold shadow-md'
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
                title={`Switch to ${name} camera (Key ${idx + 1} or C)`}
              >
                {name}
              </button>
            ))}
          </div>

          <div className="h-6 w-px bg-white/15 hidden sm:block" />

          {/* Vehicle Switcher Button & Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowVehPicker(!showVehPicker)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/15 text-white border border-white/15 rounded-xl text-xs font-semibold cursor-pointer transition-all"
              title="Change vehicle"
            >
              <Car className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{VEHICLES[currentVehicle]?.name || 'Vehicle'}</span>
            </button>

            {showVehPicker && (
              <div className="absolute bottom-full mb-2 left-0 w-48 bg-[#0b1118] border border-white/20 rounded-xl shadow-2xl overflow-hidden p-1 flex flex-col gap-1 backdrop-blur-2xl">
                {vehKeys.map((key) => {
                  const v = VEHICLES[key];
                  const isSel = currentVehicle === key;
                  return (
                    <button
                      key={key}
                      onClick={() => {
                        onSelectVehicle(key);
                        setShowVehPicker(false);
                      }}
                      className={`flex items-center justify-between px-3 py-2 rounded-lg text-xs text-left cursor-pointer transition-all ${
                        isSel
                          ? 'bg-amber-500 text-slate-950 font-semibold'
                          : 'text-white/80 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <div>
                        <div className="font-semibold">{v.name}</div>
                        <div className={`text-[10px] ${isSel ? 'text-slate-900/80' : 'text-white/50'}`}>
                          {v.mass} kg · {v.type.toUpperCase()}
                        </div>
                      </div>
                      <span className="text-[10px] opacity-60">
                        {Math.round(v.maxSpeed * 3.6)} km/h
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Headlights Toggle */}
          <button
            onClick={onToggleHeadlights}
            className={`p-2 rounded-xl border text-xs cursor-pointer transition-all ${
              headlightsOn
                ? 'bg-amber-400/20 text-amber-300 border-amber-400/40 shadow-[0_0_12px_rgba(251,191,36,0.3)]'
                : 'bg-white/10 text-white/60 hover:text-white hover:bg-white/15 border-white/15'
            }`}
            title="Toggle Headlights (H)"
          >
            <Lightbulb className="w-4 h-4" />
          </button>

          {/* Respawn On Road */}
          <button
            onClick={onRespawn}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/15 text-white/70 hover:text-white border border-white/15 text-xs cursor-pointer transition-all"
            title="Reset on road (R)"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Next Zone / Region Fast-Travel */}
          <button
            onClick={onNextZone}
            className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white/80 hover:text-white border border-white/15 text-xs cursor-pointer transition-all"
            title="Jump to Next Road Zone (Y)"
          >
            <MapPin className="w-3.5 h-3.5 text-sky-400" />
            <span>Next Zone</span>
          </button>

          {/* Audio Mute */}
          <button
            onClick={onToggleMute}
            className={`p-2 rounded-xl border text-xs cursor-pointer transition-all ${
              isMuted
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                : 'bg-white/10 text-white/70 hover:text-white hover:bg-white/15 border-white/15'
            }`}
            title="Toggle Audio"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Settings Modal Launcher */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs cursor-pointer transition-all"
            title="Open Graphics & Physics Settings (Esc)"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
