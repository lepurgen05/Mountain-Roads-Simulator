/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Fuel, AlertTriangle, Zap, CheckCircle2 } from 'lucide-react';
import { FuelState } from '../types.ts';

interface FuelHUDProps {
  fuelState: FuelState;
  onStartRefueling: (price: number) => void;
  onStopRefueling: () => void;
  onEmergencyJerryCan: () => void;
  vehicleName: string;
}

export const FuelHUD: React.FC<FuelHUDProps> = ({
  fuelState,
  onStartRefueling,
  onStopRefueling,
  onEmergencyJerryCan,
}) => {
  const {
    fuel,
    capacity,
    percent,
    rangeKm,
    isLow,
    isCritical,
    isOut,
    isRefueling,
    refuelProgress,
    nearestStation,
  } = fuelState;

  const inBay = nearestStation?.inBay;
  const station = nearestStation?.station;

  // Color scheme
  const badgeColor = isCritical
    ? 'text-rose-400 bg-rose-950/80 border-rose-500/40 ring-1 ring-rose-500/30'
    : isLow
    ? 'text-amber-400 bg-amber-950/80 border-amber-500/40'
    : 'text-emerald-400 bg-gray-900/85 border-white/10';

  const barColor = isCritical
    ? 'bg-rose-500 shadow-[0_0_8px_#f43f5e]'
    : isLow
    ? 'bg-amber-400 shadow-[0_0_6px_#f59e0b]'
    : 'bg-emerald-400 shadow-[0_0_6px_#10b981]';

  return (
    <>
      {/* Sleek, compact fuel widget displaying exact Litres left */}
      <div className="fixed bottom-4 right-4 z-20 pointer-events-auto select-none">
        <div
          className={`flex items-center gap-2.5 px-3.5 py-2 rounded-2xl border backdrop-blur-md shadow-xl transition-all ${badgeColor}`}
        >
          <div className="relative flex items-center justify-center">
            <Fuel
              className={`w-4 h-4 ${
                isCritical
                  ? 'text-rose-400 animate-pulse'
                  : isLow
                  ? 'text-amber-400'
                  : 'text-emerald-400'
              }`}
            />
            {isCritical && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            )}
          </div>

          {/* Liters left & capacity */}
          <div className="flex flex-col">
            <div className="flex items-baseline gap-1">
              <span className="text-sm font-extrabold font-mono tracking-tight text-white">
                {fuel.toFixed(1)}
              </span>
              <span className="text-[10px] text-gray-400 font-medium">/ {capacity}L</span>
            </div>

            {/* Mini Progress Bar */}
            <div className="w-20 h-1.5 bg-white/10 rounded-full overflow-hidden mt-0.5">
              <div
                className={`h-full transition-all duration-300 rounded-full ${barColor}`}
                style={{ width: `${Math.max(3, percent)}%` }}
              />
            </div>
          </div>

          {/* Range estimate */}
          <div className="pl-1.5 border-l border-white/10 flex flex-col text-right">
            <span className="text-[10px] text-gray-400 font-medium">RANGE</span>
            <span className="text-xs font-mono font-bold text-gray-200">
              {isOut ? '0 km' : `${rangeKm}km`}
            </span>
          </div>

          {/* Emergency Jerry Can if empty or critical */}
          {isOut && (
            <button
              onClick={onEmergencyJerryCan}
              className="ml-1 px-2 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-[10px] font-bold shadow-md transition-colors animate-bounce"
              title="Add 2.5L emergency reserve"
            >
              +2.5L Can
            </button>
          )}
        </div>
      </div>

      {/* Pump Bay Refuel Quick Banner (Pops up when parked inside a station) */}
      {inBay && station && (
        <div className="fixed bottom-18 right-4 z-20 pointer-events-auto select-none animate-in fade-in slide-in-from-bottom-2 duration-200">
          <div className="bg-gray-900/95 border border-emerald-500/40 p-3 rounded-2xl shadow-2xl backdrop-blur-md flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-950/80 text-emerald-400">
              <Zap className="w-4 h-4" />
            </div>

            <div className="flex flex-col">
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>{station.name}</span>
                <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-500/30">
                  ₹{station.pricePerLiter}/L
                </span>
              </div>
              <div className="text-[10px] text-gray-400 mt-0.5">
                {isRefueling
                  ? `Pumping... ${(fuel).toFixed(1)} / ${capacity} L`
                  : 'Parked in Bay · Press E to refill tank'}
              </div>
            </div>

            {/* Refuel Action Button */}
            {isRefueling ? (
              <button
                onClick={onStopRefueling}
                className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow-lg transition-colors"
              >
                Stop
              </button>
            ) : (
              <button
                onClick={() => onStartRefueling(station.pricePerLiter)}
                disabled={fuel >= capacity - 0.2}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shadow-lg transition-all ${
                  fuel >= capacity - 0.2
                    ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/30'
                }`}
              >
                {fuel >= capacity - 0.2 ? 'Full' : 'Refuel [E]'}
              </button>
            )}
          </div>
        </div>
      )}
    </>
  );
};
