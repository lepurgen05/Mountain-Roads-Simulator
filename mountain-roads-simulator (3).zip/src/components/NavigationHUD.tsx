/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowUp,
  CornerUpLeft,
  CornerUpRight,
  ArrowUpLeft,
  ArrowUpRight,
  Compass,
  MapPin,
  Search,
  X,
  Volume2,
  VolumeX,
  Navigation,
  Fuel,
  Store,
  Milestone,
  Home,
  CheckCircle2,
} from 'lucide-react';
import { NavDestination, NavInstruction, MultiplayerPlayerState } from '../types.ts';
import { POPULAR_DESTINATIONS } from '../navigation/navigationEngine.ts';
import { sound } from '../audio/SoundEngine.ts';

interface NavigationHUDProps {
  instruction: NavInstruction;
  totalDistanceM: number;
  etaMinutes: number;
  remainingKm: number;
  bearingDeg: number;
  activeDestination: NavDestination | null;
  onSelectDestination: (destId: string | null) => void;
  playerPos: { x: number; z: number; yaw: number; speedKmh: number };
  remotePlayers?: MultiplayerPlayerState[];
  isMuted?: boolean;
  onToggleMute?: () => void;
}

export const NavigationHUD: React.FC<NavigationHUDProps> = ({
  instruction,
  etaMinutes,
  remainingKm,
  bearingDeg,
  activeDestination,
  onSelectDestination,
  playerPos,
  remotePlayers = [],
}) => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [collapsed, setCollapsed] = useState(false);
  const radarCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const getManeuverIcon = (type: string) => {
    switch (type) {
      case 'hairpin_left':
      case 'sharp_left':
        return <CornerUpLeft className="w-9 h-9 stroke-[3]" />;
      case 'hairpin_right':
      case 'sharp_right':
        return <CornerUpRight className="w-9 h-9 stroke-[3]" />;
      case 'slight_left':
      case 'turn_left':
        return <ArrowUpLeft className="w-9 h-9 stroke-[3]" />;
      case 'slight_right':
      case 'turn_right':
        return <ArrowUpRight className="w-9 h-9 stroke-[3]" />;
      case 'tunnel_entry':
        return (
          <div className="relative flex items-center justify-center w-9 h-9">
            <div className="w-7 h-7 rounded-t-full border-3 border-white border-b-0" />
            <div className="absolute bottom-1 w-4 h-1 bg-white rounded-full" />
          </div>
        );
      case 'destination':
        return <CheckCircle2 className="w-9 h-9 stroke-[2.5]" />;
      default:
        return <ArrowUp className="w-9 h-9 stroke-[3]" />;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Fuel':
        return <Fuel className="w-4 h-4 text-amber-400" />;
      case 'Village':
        return <Store className="w-4 h-4 text-emerald-400" />;
      case 'Pass':
        return <Milestone className="w-4 h-4 text-cyan-400" />;
      default:
        return <Home className="w-4 h-4 text-blue-400" />;
    }
  };

  // Format estimated arrival clock time
  const now = new Date();
  now.setMinutes(now.getMinutes() + Math.max(1, etaMinutes));
  const arrivalTimeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Render Google Maps Style vector radar
  useEffect(() => {
    const canvas = radarCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    const cx = w / 2;
    const cy = h / 2;

    ctx.clearRect(0, 0, w, h);

    // Dark Map Base
    ctx.fillStyle = '#1c2430';
    ctx.beginPath();
    ctx.arc(cx, cy, cx - 2, 0, Math.PI * 2);
    ctx.fill();

    // Map grid concentric rings
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, cx * 0.45, 0, Math.PI * 2);
    ctx.arc(cx, cy, cx * 0.85, 0, Math.PI * 2);
    ctx.stroke();

    ctx.save();
    ctx.translate(cx, cy);
    // Rotate radar so player heading is always facing UP (Track Up mode)
    ctx.rotate(-playerPos.yaw);

    // Draw route vector toward active destination if available
    if (activeDestination) {
      const dx = activeDestination.x - playerPos.x;
      const dz = activeDestination.z - playerPos.z;
      const scale = 0.12; // 1 pixel = ~8 meters

      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(dx * scale, dz * scale);
      ctx.strokeStyle = '#2b7fff';
      ctx.lineWidth = 4.5;
      ctx.lineCap = 'round';
      ctx.stroke();

      // Destination Pin
      ctx.fillStyle = '#ea4335';
      ctx.beginPath();
      ctx.arc(dx * scale, dz * scale, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    // Draw nearby multiplayer drivers
    for (const remote of remotePlayers) {
      const rx = (remote.x - playerPos.x) * 0.12;
      const rz = (remote.z - playerPos.z) * 0.12;
      const dist = Math.hypot(rx, rz);
      if (dist < cx * 0.9) {
        ctx.fillStyle = '#34a853';
        ctx.beginPath();
        ctx.arc(rx, rz, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }

    ctx.restore();

    // Player Directional Light Beam / Arrow (always pointing UP)
    ctx.save();
    ctx.translate(cx, cy);

    // Forward radar view cone
    const grad = ctx.createRadialGradient(0, 0, 4, 0, -28, 30);
    grad.addColorStop(0, 'rgba(66, 133, 244, 0.45)');
    grad.addColorStop(1, 'rgba(66, 133, 244, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, 36, -Math.PI / 2 - 0.5, -Math.PI / 2 + 0.5);
    ctx.closePath();
    ctx.fill();

    // Blue Navigation Dot
    ctx.fillStyle = '#1a73e8';
    ctx.beginPath();
    ctx.arc(0, 0, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Direction tip
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(4, -4);
    ctx.lineTo(-4, -4);
    ctx.closePath();
    ctx.fill();

    ctx.restore();

    // Compass North Indicator
    ctx.save();
    ctx.translate(cx, cy);
    const northAngle = -playerPos.yaw;
    const nx = Math.sin(northAngle) * (cx - 12);
    const ny = -Math.cos(northAngle) * (cy - 12);
    ctx.fillStyle = '#ea4335';
    ctx.beginPath();
    ctx.arc(nx, ny, 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }, [playerPos, activeDestination, remotePlayers]);

  return (
    <div className="pointer-events-none select-none">
      {/* Top Left: Compact Google Maps Turn Navigation Banner */}
      <div className="fixed top-2.5 left-2.5 z-30 pointer-events-auto flex flex-col gap-1.5 max-w-[240px] w-full">
        <div
          className={`overflow-hidden transition-all duration-300 shadow-xl rounded-xl border border-emerald-500/30 ${
            collapsed ? 'bg-[#0f5132]/95 backdrop-blur-md p-2' : 'bg-[#137333]/95 backdrop-blur-md'
          }`}
        >
          {collapsed ? (
            <div className="flex items-center justify-between text-white px-1.5 py-0.5">
              <div className="flex items-center gap-2">
                <div className="text-emerald-200 scale-90">{getManeuverIcon(instruction.type)}</div>
                <div className="text-xs font-semibold truncate max-w-[130px]">
                  {instruction.distanceM > 0 ? `In ${instruction.distanceM}m` : 'Arrived'} ·{' '}
                  {activeDestination?.name || 'Navigating'}
                </div>
              </div>
              <button
                onClick={() => setCollapsed(false)}
                className="text-[10px] bg-white/20 hover:bg-white/30 px-1.5 py-0.5 rounded text-white font-medium"
              >
                Expand
              </button>
            </div>
          ) : (
            <div>
              {/* Main Turn Direction Row - Compact */}
              <div className="flex items-start gap-2.5 p-2.5 text-white">
                <div className="flex flex-col items-center justify-center p-1.5 rounded-lg bg-black/20 text-emerald-200 shrink-0">
                  {getManeuverIcon(instruction.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-lg font-bold tracking-tight leading-snug">
                    {instruction.type === 'destination' ? (
                      'Arrived'
                    ) : instruction.distanceM > 1000 ? (
                      `${(instruction.distanceM / 1000).toFixed(1)} km`
                    ) : (
                      `${instruction.distanceM} m`
                    )}
                  </div>
                  <div className="text-xs font-semibold leading-tight truncate text-white mt-0.5">
                    {instruction.text}
                  </div>
                  <div className="text-[10px] text-emerald-100/75 truncate mt-0.5">
                    {instruction.roadName}
                  </div>
                </div>
                <button
                  onClick={() => setCollapsed(true)}
                  className="text-white/60 hover:text-white p-0.5 rounded hover:bg-white/10"
                  title="Collapse Navigation Card"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Sub-row: Upcoming maneuver or destination lane preview */}
              <div className="bg-[#0b5325] px-2.5 py-1 flex items-center justify-between text-[11px] text-emerald-100 border-t border-emerald-400/20">
                <div className="flex items-center gap-1.5 truncate">
                  <Navigation className="w-3 h-3 text-emerald-300 shrink-0" />
                  <span className="font-medium truncate max-w-[130px]">
                    {activeDestination ? `To: ${activeDestination.name}` : 'Free Roam'}
                  </span>
                </div>
                {instruction.speedLimitKmh && (
                  <div className="flex items-center gap-1 shrink-0 bg-white/15 px-1.5 py-0.5 rounded-full font-mono text-[10px] font-bold text-white">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                    <span>{instruction.speedLimitKmh}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Search / Set Destination Quick Pill */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setDrawerOpen(true)}
            className="flex-1 flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-gray-900/90 hover:bg-gray-800 text-white text-[11px] font-medium border border-white/10 backdrop-blur-md shadow-lg transition-colors"
          >
            <div className="flex items-center gap-1.5 truncate">
              <Search className="w-3 h-3 text-emerald-400 shrink-0" />
              <span className="truncate max-w-[130px]">
                {activeDestination ? activeDestination.name : 'Select Destination...'}
              </span>
            </div>
            <span className="text-[9px] text-gray-400 bg-white/10 px-1 py-0.5 rounded">Change</span>
          </button>
          {activeDestination && (
            <button
              onClick={() => onSelectDestination(null)}
              className="p-1.5 rounded-lg bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-500/30 backdrop-blur-md shadow-lg transition-colors"
              title="End Route"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={() => {
              setSoundEnabled(!soundEnabled);
              sound.navChime();
            }}
            className={`p-1.5 rounded-lg border backdrop-blur-md shadow-lg transition-colors ${
              soundEnabled
                ? 'bg-gray-900/90 text-emerald-400 border-emerald-500/30 hover:bg-gray-800'
                : 'bg-gray-900/90 text-gray-400 border-white/10 hover:bg-gray-800'
            }`}
            title={soundEnabled ? 'Mute Navigation Voice' : 'Unmute Navigation Voice'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Top Right: Google Maps Vector Radar & Compass */}
      <div className="fixed top-3 right-3 z-30 pointer-events-auto flex flex-col items-end gap-2">
        <div className="relative rounded-2xl overflow-hidden p-1 bg-gray-900/90 border border-white/15 shadow-2xl backdrop-blur-md">
          <canvas
            ref={radarCanvasRef}
            width={128}
            height={128}
            className="rounded-xl block"
          />
          {/* Compass Rose Badge */}
          <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm px-1.5 py-0.5 rounded text-[10px] font-mono font-bold text-gray-300 flex items-center gap-1">
            <Compass className="w-3 h-3 text-red-400" />
            <span>N</span>
          </div>

          {/* Speed Limit Circular Sign (Authentic Google Maps style) */}
          {instruction.speedLimitKmh && (
            <div className="absolute bottom-2 left-2 w-7 h-7 rounded-full bg-white border-2 border-red-600 flex items-center justify-center shadow-md">
              <span className="text-[10px] font-bold text-gray-950 font-sans leading-none">
                {instruction.speedLimitKmh}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Center: Google Maps Trip Status Bar (ETA, Remaining km, Time) */}
      {activeDestination && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-30 pointer-events-auto">
          <div className="flex items-center gap-3.5 bg-gray-950/92 backdrop-blur-md border border-white/15 px-4 py-2.5 rounded-2xl shadow-2xl text-white">
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-bold text-emerald-400 font-mono">{etaMinutes}</span>
              <span className="text-xs text-emerald-200/80 font-medium">min</span>
            </div>

            <div className="h-5 w-px bg-white/15" />

            <div className="flex items-baseline gap-1 text-xs">
              <span className="font-semibold text-gray-200">{remainingKm}</span>
              <span className="text-gray-400">km</span>
            </div>

            <div className="h-5 w-px bg-white/15" />

            <div className="flex items-baseline gap-1 text-xs">
              <span className="text-gray-400">ETA</span>
              <span className="font-semibold text-gray-200">{arrivalTimeStr}</span>
            </div>

            <div className="h-5 w-px bg-white/15" />

            <button
              onClick={() => onSelectDestination(null)}
              className="text-xs bg-red-600/80 hover:bg-red-600 px-2.5 py-1 rounded-lg font-medium transition-colors"
            >
              End
            </button>
          </div>
        </div>
      )}

      {/* Destination Picker Modal */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md pointer-events-auto">
          <div className="bg-gray-900 border border-white/15 rounded-3xl max-w-md w-full shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="p-4 bg-gray-800/80 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Navigation className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-white text-base">Himalayan Route Navigation</h3>
              </div>
              <button
                onClick={() => setDrawerOpen(false)}
                className="p-1 rounded-xl hover:bg-white/10 text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Destinations List */}
            <div className="p-4 space-y-2 max-h-[60vh] overflow-y-auto">
              {POPULAR_DESTINATIONS.map((dest) => {
                const isSelected = activeDestination?.id === dest.id;
                const d = Math.hypot(dest.x - playerPos.x, dest.z - playerPos.z);
                const km = (d / 1000).toFixed(1);

                return (
                  <button
                    key={dest.id}
                    onClick={() => {
                      onSelectDestination(dest.id);
                      setDrawerOpen(false);
                    }}
                    className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-start gap-3 ${
                      isSelected
                        ? 'bg-emerald-950/60 border-emerald-500 text-white ring-1 ring-emerald-500/50'
                        : 'bg-gray-800/50 hover:bg-gray-800 border-white/5 text-gray-200'
                    }`}
                  >
                    <div className="p-2.5 rounded-xl bg-gray-950/60 shrink-0 mt-0.5">
                      {getCategoryIcon(dest.category)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-sm truncate">{dest.name}</span>
                        <span className="text-xs font-mono text-emerald-400 shrink-0 font-medium">
                          {km} km
                        </span>
                      </div>
                      <div className="text-xs text-gray-400 line-clamp-1 mt-0.5">
                        {dest.description}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Free Roam Option */}
            <div className="p-4 bg-gray-950/60 border-t border-white/10 flex gap-2">
              <button
                onClick={() => {
                  onSelectDestination(null);
                  setDrawerOpen(false);
                }}
                className="w-full py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs font-semibold transition-colors"
              >
                Clear Route (Free Roam)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
