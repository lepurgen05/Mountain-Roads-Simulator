/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ChevronLeft, ChevronRight, ArrowUp, ArrowDown, Bell } from 'lucide-react';
import { Input } from '../core/input.ts';

interface MobileControlsProps {
  input: Input;
}

export const MobileControls: React.FC<MobileControlsProps> = ({ input }) => {
  return (
    <div className="md:hidden fixed inset-x-0 bottom-16 pointer-events-none z-20 flex justify-between px-4 select-none">
      {/* Steering Buttons */}
      <div className="flex gap-2 pointer-events-auto">
        <button
          onTouchStart={() => {
            input.left = true;
          }}
          onTouchEnd={() => {
            input.left = false;
          }}
          onMouseDown={() => {
            input.left = true;
          }}
          onMouseUp={() => {
            input.left = false;
          }}
          className="w-14 h-14 bg-black/60 active:bg-amber-500/40 border border-white/20 rounded-2xl flex items-center justify-center text-white active:scale-95 shadow-xl backdrop-blur-md transition-transform"
        >
          <ChevronLeft className="w-8 h-8" />
        </button>
        <button
          onTouchStart={() => {
            input.right = true;
          }}
          onTouchEnd={() => {
            input.right = false;
          }}
          onMouseDown={() => {
            input.right = true;
          }}
          onMouseUp={() => {
            input.right = false;
          }}
          className="w-14 h-14 bg-black/60 active:bg-amber-500/40 border border-white/20 rounded-2xl flex items-center justify-center text-white active:scale-95 shadow-xl backdrop-blur-md transition-transform"
        >
          <ChevronRight className="w-8 h-8" />
        </button>
      </div>

      {/* Pedals: Throttle, Brake, Handbrake */}
      <div className="flex items-end gap-2.5 pointer-events-auto">
        {/* Handbrake */}
        <button
          onTouchStart={() => {
            input.brake = true;
          }}
          onTouchEnd={() => {
            input.brake = false;
          }}
          onMouseDown={() => {
            input.brake = true;
          }}
          onMouseUp={() => {
            input.brake = false;
          }}
          className="w-11 h-11 bg-rose-950/60 active:bg-rose-600/70 border border-rose-500/30 rounded-xl flex items-center justify-center text-rose-300 font-bold text-xs active:scale-95 shadow-xl backdrop-blur-md transition-transform"
        >
          P
        </button>

        {/* Brake / Reverse Pedal */}
        <button
          onTouchStart={() => {
            input.down = true;
          }}
          onTouchEnd={() => {
            input.down = false;
          }}
          onMouseDown={() => {
            input.down = true;
          }}
          onMouseUp={() => {
            input.down = false;
          }}
          className="w-13 h-16 bg-black/70 active:bg-rose-500/50 border border-white/20 rounded-2xl flex flex-col items-center justify-center text-white active:scale-95 shadow-xl backdrop-blur-md transition-transform"
        >
          <ArrowDown className="w-6 h-6 text-rose-400" />
          <span className="text-[9px] uppercase tracking-wider text-white/50 font-semibold">Brake</span>
        </button>

        {/* Throttle Pedal */}
        <button
          onTouchStart={() => {
            input.up = true;
          }}
          onTouchEnd={() => {
            input.up = false;
          }}
          onMouseDown={() => {
            input.up = true;
          }}
          onMouseUp={() => {
            input.up = false;
          }}
          className="w-14 h-20 bg-black/70 active:bg-emerald-500/50 border border-white/20 rounded-2xl flex flex-col items-center justify-center text-white active:scale-95 shadow-xl backdrop-blur-md transition-transform"
        >
          <ArrowUp className="w-7 h-7 text-emerald-400" />
          <span className="text-[10px] uppercase tracking-wider text-white/60 font-semibold">Gas</span>
        </button>
      </div>
    </div>
  );
};
