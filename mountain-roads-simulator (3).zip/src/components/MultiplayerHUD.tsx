/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Users, Wifi, WifiOff, Volume2, MessageSquare, Send, X, Car } from 'lucide-react';
import { MultiplayerPlayerState, MultiplayerChatMessage } from '../types.ts';

interface MultiplayerHUDProps {
  isConnected: boolean;
  connectionStatus: 'connecting' | 'connected' | 'disconnected';
  localName: string;
  onUpdateName: (name: string) => void;
  remotePlayers: MultiplayerPlayerState[];
  messages: MultiplayerChatMessage[];
  onSendChat: (text: string) => void;
  onBroadcastHorn: () => void;
  playerPos: { x: number; z: number };
}

export const MultiplayerHUD: React.FC<MultiplayerHUDProps> = ({
  isConnected,
  connectionStatus,
  localName,
  onUpdateName,
  remotePlayers,
  messages,
  onSendChat,
  onBroadcastHorn,
  playerPos,
}) => {
  const [panelOpen, setPanelOpen] = useState(false);
  const [nameInput, setNameInput] = useState(localName);
  const [chatInput, setChatInput] = useState('');

  const quickMessages = [
    '👋 Namaste! Safe travels.',
    '⚠️ Slow down, hairpin fog ahead!',
    '⛽ Stopping at Fuel Pump.',
    '🏁 Passing on right side.',
    '🚗 Great driving!',
  ];

  const handleSendChat = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim()) return;
    onSendChat(chatInput.trim());
    setChatInput('');
  };

  const handleQuickSend = (text: string) => {
    onSendChat(text);
  };

  return (
    <>
      {/* Top Center-Right: Compact Multiplayer Status Pill */}
      <div className="fixed top-3 right-40 z-30 pointer-events-auto select-none">
        <button
          onClick={() => setPanelOpen(!panelOpen)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border backdrop-blur-md shadow-lg transition-all text-xs font-semibold ${
            isConnected
              ? 'bg-gray-900/90 text-emerald-400 border-emerald-500/30 hover:bg-gray-800'
              : connectionStatus === 'connecting'
              ? 'bg-amber-950/80 text-amber-300 border-amber-500/30 animate-pulse'
              : 'bg-gray-900/90 text-gray-400 border-white/10 hover:bg-gray-800'
          }`}
          title="Toggle Multiplayer Lobby"
        >
          {isConnected ? (
            <>
              <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
              <Users className="w-3.5 h-3.5" />
              <span>{remotePlayers.length + 1} Drivers</span>
            </>
          ) : connectionStatus === 'connecting' ? (
            <>
              <Wifi className="w-3.5 h-3.5 animate-spin" />
              <span>Connecting MP...</span>
            </>
          ) : (
            <>
              <WifiOff className="w-3.5 h-3.5 text-gray-500" />
              <span>MP Offline</span>
            </>
          )}
        </button>
      </div>

      {/* Multiplayer Panel / Drawer */}
      {panelOpen && (
        <div className="fixed top-14 right-4 z-40 w-80 max-h-[82vh] bg-gray-950/95 border border-white/15 rounded-3xl shadow-2xl backdrop-blur-xl p-4 flex flex-col gap-3 pointer-events-auto select-none animate-in fade-in zoom-in-95 duration-200">
          {/* Header */}
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">Mountain Convoy Lobby</h3>
            </div>
            <button
              onClick={() => setPanelOpen(false)}
              className="p-1 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Nickname setting */}
          <div className="flex items-center gap-2 bg-gray-900 p-2 rounded-xl border border-white/10">
            <span className="text-[11px] font-medium text-gray-400 shrink-0">Handle:</span>
            <input
              type="text"
              value={nameInput}
              maxLength={16}
              onChange={(e) => setNameInput(e.target.value)}
              onBlur={() => onUpdateName(nameInput)}
              className="bg-transparent text-white text-xs font-semibold focus:outline-none flex-1 min-w-0"
              placeholder="Your driver name"
            />
            <button
              onClick={onBroadcastHorn}
              className="px-2 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-lg text-[10px] font-bold flex items-center gap-1 border border-amber-500/30 transition-colors"
              title="Broadcast horn honk to all drivers"
            >
              <Volume2 className="w-3 h-3" />
              <span>Honk</span>
            </button>
          </div>

          {/* Active Drivers List */}
          <div className="flex flex-col gap-1.5 max-h-36 overflow-y-auto pr-1">
            <div className="text-[10px] font-bold uppercase tracking-wider text-gray-500 px-1">
              Active Drivers ({remotePlayers.length + 1})
            </div>

            {/* Local Player */}
            <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs">
              <div className="flex items-center gap-2 truncate">
                <Car className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-semibold text-white truncate">{localName} (You)</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400">Host</span>
            </div>

            {/* Remote Players */}
            {remotePlayers.length === 0 ? (
              <div className="text-[11px] text-gray-500 italic p-2 text-center bg-gray-900/50 rounded-xl">
                No other drivers on the mountain pass yet. Share the link to drive together!
              </div>
            ) : (
              remotePlayers.map((p) => {
                const dist = Math.round(Math.hypot(p.x - playerPos.x, p.z - playerPos.z));
                return (
                  <div
                    key={p.id}
                    className="flex items-center justify-between p-2 rounded-xl bg-gray-900/60 border border-white/5 text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <div
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: `#${p.color.toString(16).padStart(6, '0')}` }}
                      />
                      <span className="font-semibold text-gray-200 truncate">{p.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0 text-[10px] font-mono text-gray-400">
                      <span>{p.speedKmh} km/h</span>
                      <span>·</span>
                      <span className="text-emerald-400 font-bold">{dist}m</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Quick Road Signals */}
          <div className="flex flex-col gap-1 border-t border-white/10 pt-2">
            <div className="text-[10px] font-bold uppercase tracking-wider text-gray-500 px-1">
              Mountain Road Signals
            </div>
            <div className="flex flex-wrap gap-1">
              {quickMessages.map((msg, i) => (
                <button
                  key={i}
                  onClick={() => handleQuickSend(msg)}
                  className="px-2 py-1 bg-gray-900 hover:bg-gray-800 text-gray-300 hover:text-white rounded-lg text-[10px] font-medium border border-white/5 transition-colors"
                >
                  {msg}
                </button>
              ))}
            </div>
          </div>

          {/* Chat Stream & Input */}
          <div className="flex flex-col gap-1.5 border-t border-white/10 pt-2">
            <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-gray-500 px-1">
              <MessageSquare className="w-3 h-3" />
              <span>Radio Log</span>
            </div>

            <div className="h-24 overflow-y-auto bg-black/40 rounded-xl p-2 space-y-1 text-xs">
              {messages.length === 0 ? (
                <div className="text-[10px] text-gray-500 italic">No radio messages yet.</div>
              ) : (
                messages.map((m) => (
                  <div key={m.id} className="text-[11px] leading-tight">
                    <span className="font-bold text-emerald-400">{m.senderName}: </span>
                    <span className="text-gray-200">{m.text}</span>
                  </div>
                ))
              )}
            </div>

            <form onSubmit={handleSendChat} className="flex gap-1.5 mt-1">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Say something to convoy..."
                className="flex-1 bg-gray-900 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500/50"
              />
              <button
                type="submit"
                className="p-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl transition-colors shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
