/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GameSettings } from '../types.ts';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onResetDefaults: () => void;
}

const PRESETS = {
  Low: { resolution: 70, renderDistance: 4, shadows: 'Off' as const, antialias: false, vegetation: 30, effects: 'Low' as const },
  Medium: { resolution: 90, renderDistance: 6, shadows: 'Low' as const, antialias: true, vegetation: 60, effects: 'Low' as const },
  High: { resolution: 100, renderDistance: 7, shadows: 'High' as const, antialias: true, vegetation: 80, effects: 'High' as const },
  Ultra: { resolution: 120, renderDistance: 10, shadows: 'High' as const, antialias: true, vegetation: 100, effects: 'High' as const },
};

const GRAPHICS_KEYS = Object.keys(PRESETS.Low);

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onResetDefaults,
}) => {
  const [activeTab, setActiveTab] = useState<'Graphics' | 'Gameplay' | 'Camera' | 'Audio'>('Graphics');

  if (!isOpen) return null;

  const set = (k: keyof GameSettings, v: any) => {
    const next = { ...settings, [k]: v };
    if (k === 'preset' && (PRESETS as any)[v]) {
      Object.assign(next, (PRESETS as any)[v]);
    } else if (GRAPHICS_KEYS.includes(k)) {
      next.preset = 'Custom';
    }
    onUpdateSettings(next);
  };

  return (
    <div id="settings" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="box">
        <header>
          <h2>SETTINGS</h2>
          <div id="tabs">
            {(['Graphics', 'Gameplay', 'Camera', 'Audio'] as const).map((tabName) => (
              <button
                key={tabName}
                className={activeTab === tabName ? 'on' : ''}
                onClick={() => setActiveTab(tabName)}
              >
                {tabName.toUpperCase()}
              </button>
            ))}
          </div>
        </header>

        <div id="rows">
          {activeTab === 'Graphics' && (
            <>
              <div className="row">
                <label>Quality preset</label>
                <select
                  value={settings.preset}
                  onChange={(e) => set('preset', e.target.value)}
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                  <option value="Ultra">Ultra</option>
                  <option value="Custom">Custom</option>
                </select>
              </div>

              <div className="row">
                <label>Resolution scale</label>
                <div className="range">
                  <input
                    type="range"
                    min="50"
                    max="150"
                    step="10"
                    value={settings.resolution}
                    onChange={(e) => set('resolution', +e.target.value)}
                  />
                  <span className="val">{settings.resolution}%</span>
                </div>
              </div>

              <div className="row">
                <label>Render distance (x160 m)</label>
                <div className="range">
                  <input
                    type="range"
                    min="3"
                    max="10"
                    step="1"
                    value={settings.renderDistance}
                    onChange={(e) => set('renderDistance', +e.target.value)}
                  />
                  <span className="val">{settings.renderDistance}</span>
                </div>
              </div>

              <div className="row">
                <label>Shadows</label>
                <select
                  value={settings.shadows}
                  onChange={(e) => set('shadows', e.target.value)}
                >
                  <option value="Off">Off</option>
                  <option value="Low">Low</option>
                  <option value="High">High</option>
                </select>
              </div>

              <div className="row">
                <label>Anti-aliasing (applies after reload)</label>
                <button
                  className={`tog ${settings.antialias ? 'on' : ''}`}
                  onClick={() => set('antialias', !settings.antialias)}
                />
              </div>

              <div className="row">
                <label>Vegetation density</label>
                <div className="range">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="10"
                    value={settings.vegetation}
                    onChange={(e) => set('vegetation', +e.target.value)}
                  />
                  <span className="val">{settings.vegetation}%</span>
                </div>
              </div>

              <div className="row">
                <label>Effects quality (reflections)</label>
                <select
                  value={settings.effects}
                  onChange={(e) => set('effects', e.target.value)}
                >
                  <option value="Low">Low</option>
                  <option value="High">High</option>
                </select>
              </div>

              <div className="row">
                <label>Headlight brightness</label>
                <div className="range">
                  <input
                    type="range"
                    min="50"
                    max="250"
                    step="10"
                    value={settings.headlight}
                    onChange={(e) => set('headlight', +e.target.value)}
                  />
                  <span className="val">{settings.headlight}%</span>
                </div>
              </div>
            </>
          )}

          {activeTab === 'Gameplay' && (
            <>
              <div className="row">
                <label>Traffic</label>
                <button
                  className={`tog ${settings.traffic ? 'on' : ''}`}
                  onClick={() => set('traffic', !settings.traffic)}
                />
              </div>

              <div className="row">
                <label>Traffic density</label>
                <div className="range">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="10"
                    value={settings.trafficDensity}
                    onChange={(e) => set('trafficDensity', +e.target.value)}
                  />
                  <span className="val">{settings.trafficDensity}%</span>
                </div>
              </div>

              <div className="row">
                <label>Automatic weather</label>
                <button
                  className={`tog ${settings.autoWeather ? 'on' : ''}`}
                  onClick={() => set('autoWeather', !settings.autoWeather)}
                />
              </div>

              <div className="row">
                <label>Real weather (needs internet)</label>
                <button
                  className={`tog ${settings.liveWeather ? 'on' : ''}`}
                  onClick={() => set('liveWeather', !settings.liveWeather)}
                />
              </div>

              <div className="row">
                <label>Day/night cycle running</label>
                <button
                  className={`tog ${settings.autoTime ? 'on' : ''}`}
                  onClick={() => set('autoTime', !settings.autoTime)}
                />
              </div>

              <div className="row">
                <label>Time speed (Real = Indian Standard Time)</label>
                <select
                  value={settings.timeMode}
                  onChange={(e) => set('timeMode', e.target.value)}
                >
                  <option value="Real time">Real time</option>
                  <option value="x10">x10</option>
                  <option value="x60">x60</option>
                  <option value="x300">x300</option>
                </select>
              </div>

              <div className="row">
                <label>Speed-sensitive steering</label>
                <button
                  className={`tog ${settings.speedSteerEnabled !== false ? 'on' : ''}`}
                  onClick={() => set('speedSteerEnabled', settings.speedSteerEnabled === false ? true : false)}
                />
              </div>

              <div className="row">
                <label>Speed to steer sensitivity</label>
                <div className="range">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    value={settings.speedSteerSensitivity ?? 65}
                    onChange={(e) => set('speedSteerSensitivity', +e.target.value)}
                  />
                  <span className="val">{settings.speedSteerSensitivity ?? 65}%</span>
                </div>
              </div>

              <div className="row">
                <label>Steer response rate</label>
                <div className="range">
                  <input
                    type="range"
                    min="50"
                    max="150"
                    step="5"
                    value={settings.steerSensitivity ?? 100}
                    onChange={(e) => set('steerSensitivity', +e.target.value)}
                  />
                  <span className="val">{settings.steerSensitivity ?? 100}%</span>
                </div>
              </div>
            </>
          )}

          {activeTab === 'Camera' && (
            <>
              <div className="row">
                <label>Field of view</label>
                <div className="range">
                  <input
                    type="range"
                    min="50"
                    max="90"
                    step="1"
                    value={settings.fov}
                    onChange={(e) => set('fov', +e.target.value)}
                  />
                  <span className="val">{settings.fov}°</span>
                </div>
              </div>

              <div className="row">
                <label>Camera distance</label>
                <div className="range">
                  <input
                    type="range"
                    min="0.6"
                    max="1.8"
                    step="0.1"
                    value={settings.camDist}
                    onChange={(e) => set('camDist', +e.target.value)}
                  />
                  <span className="val">{settings.camDist.toFixed(1)}x</span>
                </div>
              </div>

              <div className="row">
                <label>Camera height</label>
                <div className="range">
                  <input
                    type="range"
                    min="0.6"
                    max="1.8"
                    step="0.1"
                    value={settings.camHeight}
                    onChange={(e) => set('camHeight', +e.target.value)}
                  />
                  <span className="val">{settings.camHeight.toFixed(1)}x</span>
                </div>
              </div>

              <div className="row">
                <label>Camera sensitivity</label>
                <div className="range">
                  <input
                    type="range"
                    min="0.5"
                    max="2"
                    step="0.1"
                    value={settings.camSens}
                    onChange={(e) => set('camSens', +e.target.value)}
                  />
                  <span className="val">{settings.camSens.toFixed(1)}x</span>
                </div>
              </div>

              <div className="row">
                <label>Camera shake</label>
                <button
                  className={`tog ${settings.shake ? 'on' : ''}`}
                  onClick={() => set('shake', !settings.shake)}
                />
              </div>
            </>
          )}

          {activeTab === 'Audio' && (
            <>
              <div className="row">
                <label>Master volume</label>
                <div className="range">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    value={settings.master}
                    onChange={(e) => set('master', +e.target.value)}
                  />
                  <span className="val">{settings.master}%</span>
                </div>
              </div>

              <div className="row">
                <label>Engine volume</label>
                <div className="range">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    value={settings.engineVol}
                    onChange={(e) => set('engineVol', +e.target.value)}
                  />
                  <span className="val">{settings.engineVol}%</span>
                </div>
              </div>

              <div className="row">
                <label>Environment volume</label>
                <div className="range">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    value={settings.envVol}
                    onChange={(e) => set('envVol', +e.target.value)}
                  />
                  <span className="val">{settings.envVol}%</span>
                </div>
              </div>

              <div className="row">
                <label>Weather volume</label>
                <div className="range">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    value={settings.weatherVol}
                    onChange={(e) => set('weatherVol', +e.target.value)}
                  />
                  <span className="val">{settings.weatherVol}%</span>
                </div>
              </div>
            </>
          )}
        </div>

        <footer>
          <button id="s-reset" onClick={onResetDefaults}>RESET DEFAULTS</button>
          <button id="s-back" onClick={onClose}>BACK</button>
        </footer>
      </div>
    </div>
  );
};
