/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

const VS = `
  uniform vec3 cam;
  uniform vec3 box;
  uniform float time, speed, len, sway;
  uniform vec2 wind;
  attribute vec3 seed;
  attribute float endp;
  varying float vF;

  void main() {
    vec3 b = seed * box;
    b.y -= time * speed;
    b.xz += wind * time * 0.4;
    vec3 loc = mod(b - cam, box) - box * 0.5;
    loc.x += sin(time * 0.7 + seed.z * 25.0) * sway;
    vec3 w = cam + loc;
    w += normalize(vec3(wind.x, -speed * 0.1, wind.y)) * len * endp;

    vF = (1.0 - smoothstep(box.x * 0.2, box.x * 0.5, length(loc.xz))) *
         (1.0 - smoothstep(box.y * 0.3, box.y * 0.5, abs(loc.y)));

    vec4 mv = viewMatrix * vec4(w, 1.0);
    gl_Position = projectionMatrix * mv;
    gl_PointSize = sway > 0.0 ? clamp(70.0 / (-mv.z), 1.5, 9.0) : 1.0;
  }
`;

const FS = `
  uniform float opacity;
  uniform vec3 color;
  uniform float round_;
  varying float vF;

  void main() {
    float a = opacity * vF;
    if (round_ > 0.5) {
      vec2 p = gl_PointCoord - 0.5;
      a *= 1.0 - smoothstep(0.1, 0.5, length(p));
    }
    gl_FragColor = vec4(color, a);
  }
`;

export class Precip {
  public rain: THREE.LineSegments;
  public snow: THREE.Points;

  constructor(scene: THREE.Scene) {
    const mk = (
      N: number,
      line: boolean,
      speed: number,
      len: number,
      sway: number,
      color: number,
      round_: number
    ) => {
      const seed = new Float32Array(N * (line ? 6 : 3));
      const endp = new Float32Array(N * (line ? 2 : 1));
      for (let i = 0; i < N; i++) {
        const a = Math.random();
        const b = Math.random();
        const c = Math.random();
        if (line) {
          seed.set([a, b, c, a, b, c], i * 6);
          endp[i * 2] = 0;
          endp[i * 2 + 1] = 1;
        } else {
          seed.set([a, b, c], i * 3);
        }
      }

      const g = new THREE.BufferGeometry();
      g.setAttribute('seed', new THREE.BufferAttribute(seed, 3));
      g.setAttribute('endp', new THREE.BufferAttribute(endp, 1));
      g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(seed.length), 3));

      const m = new THREE.ShaderMaterial({
        vertexShader: VS,
        fragmentShader: FS,
        transparent: true,
        depthWrite: false,
        uniforms: {
          cam: { value: new THREE.Vector3() },
          box: { value: new THREE.Vector3(45, 30, 45) },
          time: { value: 0 },
          speed: { value: speed },
          len: { value: len },
          sway: { value: sway },
          wind: { value: new THREE.Vector2(1, 0.4) },
          opacity: { value: 0 },
          color: { value: new THREE.Color(color) },
          round_: { value: round_ },
        },
      });

      const o = line ? new THREE.LineSegments(g, m) : new THREE.Points(g, m);
      o.frustumCulled = false;
      o.visible = false;
      scene.add(o);
      return o;
    };

    this.rain = mk(4500, true, 26, 0.95, 0, 0xb0c4de, 0) as THREE.LineSegments;
    this.snow = mk(2800, false, 2.2, 0, 0.6, 0xffffff, 1) as THREE.Points;
  }

  public update(t: number, cam: THREE.Vector3, rain: number, snow: number, wind: number): void {
    for (const [o, v] of [
      [this.rain, rain],
      [this.snow, snow],
    ] as const) {
      const u = (o.material as THREE.ShaderMaterial).uniforms;
      o.visible = v > 0.02;
      u.time.value = t;
      u.cam.value.copy(cam);
      u.opacity.value = Math.min(1, v) * (o === this.rain ? 0.45 : 0.9);
      u.wind.value.set(wind * 4, wind * 1.6);
    }
  }
}
