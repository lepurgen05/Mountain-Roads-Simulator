/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { sstep } from '../core/noise.ts';

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export const WEATHER_NAMES = [
  'clear',
  'partly',
  'cloudy',
  'drizzle',
  'rain',
  'heavy',
  'thunder',
  'fog',
  'snow',
] as const;

export type WeatherCondition = typeof WEATHER_NAMES[number];

// [cloud, rain, fog, snow, storm]
const COND: Record<WeatherCondition, [number, number, number, number, number]> = {
  clear: [0.06, 0, 0, 0, 0],
  partly: [0.4, 0, 0, 0, 0],
  cloudy: [0.75, 0, 0.05, 0, 0],
  drizzle: [0.85, 0.2, 0.08, 0, 0],
  rain: [0.92, 0.55, 0.12, 0, 0],
  heavy: [1, 1, 0.22, 0, 0],
  thunder: [1, 0.85, 0.15, 0, 1],
  fog: [0.55, 0, 0.9, 0, 0],
  snow: [0.95, 0, 0.2, 0.6, 0],
};

const HILL = [
  [30, 25, 15, 3, 2, 0, 0, 22, 3],
  [15, 25, 22, 8, 10, 4, 10, 6, 0],
  [3, 7, 18, 18, 22, 17, 5, 10, 0],
  [35, 25, 12, 3, 4, 1, 3, 17, 0],
];
const PLAIN = [
  [20, 20, 15, 2, 2, 0, 0, 40, 0],
  [28, 30, 12, 3, 5, 2, 20, 0, 0],
  [4, 12, 22, 18, 22, 14, 8, 0, 0],
  [45, 30, 10, 2, 3, 0, 3, 7, 0],
];
const SEV = [0, 1, 2, 3, 4, 5, 6, 2, 4];
const MTEMP = [17, 20, 25, 28, 29, 29, 29, 29, 28, 26, 21, 17];
const season = (m: number) => (m === 11 || m < 2 ? 0 : m < 5 ? 1 : m < 9 ? 2 : 3);

export class Weather {
  public cur: [number, number, number, number, number] = [0.1, 0, 0, 0, 0];
  public tgt: [number, number, number, number, number] = [0.1, 0, 0, 0, 0];
  public temp: number = 20;
  public wet: number = 0;
  public flash: number = 0;
  public timer: number = 0;
  public cond: WeatherCondition = 'clear';
  public live: { hill: { v: number[]; t: number; el: number }; plain: { v: number[]; t: number; el: number } } | null = null;
  public liveOK: boolean = false;
  public lastAlt: number | null = null;
  public fl: number = 3;
  public wind: number = 0.3;
  public label: string = 'Clear';
  public source: string = 'sim';
  public nextFetch: number = 0;
  public fetching: boolean = false;
  public tempLive: number = 20;

  get cloud(): number { return this.cur[0]; }
  get rain(): number { return this.cur[1]; }
  get fog(): number { return this.cur[2]; }
  get snow(): number { return this.cur[3]; }
  get storm(): number { return this.cur[4]; }

  public setCondition(cond: WeatherCondition): void {
    this.cond = cond;
    this.tgt = [...COND[cond]];
    this.timer = 600; // hold manual selection
  }

  public pickNext(alt: number, month: number, hour: number): WeatherCondition {
    const a = sstep(300, 1500, alt);
    const s = season(month);
    let w = WEATHER_NAMES.map((_, i) => PLAIN[s][i] * (1 - a) + HILL[s][i] * a);
    const morning = hour >= 3 && hour <= 9;
    const aft = hour >= 13 && hour <= 19;
    w[7] *= morning ? 3 : 0.4;
    w[6] *= aft ? 2.5 : 0.3;
    if (alt < 1800 || s !== 0) w[8] = 0;
    else w[8] *= clamp((alt - 1800) / 500, 0, 1);

    const c = WEATHER_NAMES.indexOf(this.cond);
    w = w.map((x, i) => x * (Math.abs(SEV[i] - SEV[c]) <= 2 ? 1 : 0.3) * (i === c ? 0.6 : 1));
    let t = Math.random() * w.reduce((p, q) => p + q, 0);
    let i = 0;
    while (i < w.length - 1 && t > w[i]) t -= w[i++];
    return WEATHER_NAMES[i];
  }

  private conv(j: { current: { weather_code: number; precipitation?: number; cloud_cover?: number; temperature_2m: number }; elevation?: number }) {
    const c = j.current;
    const code = c.weather_code;
    const pr = c.precipitation || 0;
    let rain = pr <= 0 ? 0 : pr < 0.3 ? 0.25 : pr < 1 ? 0.45 : pr < 3 ? 0.7 : 1;
    if (code >= 51 && code <= 57) rain = Math.max(rain, 0.2);
    if (code >= 61 && code <= 67) rain = Math.max(rain, 0.45);
    if (code >= 80 && code <= 82) rain = Math.max(rain, 0.55);
    if (code === 65 || code === 82) rain = Math.max(rain, 0.9);
    const storm = code >= 95 ? 1 : 0;
    if (storm) rain = Math.max(rain, 0.8);
    const snow = (code >= 71 && code <= 77) || code === 85 || code === 86 ? 0.6 : 0;
    if (snow) rain = 0;
    let cloud = clamp((c.cloud_cover || 0) / 100, 0, 1);
    if (code === 3) cloud = Math.max(cloud, 0.9);
    if (rain > 0) cloud = Math.max(cloud, 0.85);
    return {
      v: [cloud, rain, code === 45 || code === 48 ? 0.9 : 0, snow, storm],
      t: c.temperature_2m,
      el: j.elevation || 0,
    };
  }

  public async fetchLive(): Promise<void> {
    this.fetching = true;
    try {
      const ac = new AbortController();
      const to = setTimeout(() => ac.abort(), 7000);
      const r = await fetch(
        'https://api.open-meteo.com/v1/forecast?latitude=27.12,26.72&longitude=88.13,88.43&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,cloud_cover,wind_speed_10m&timezone=Asia%2FKolkata',
        { signal: ac.signal }
      );
      clearTimeout(to);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const j = await r.json();
      const arr = Array.isArray(j) ? j : [j];
      if (arr.length < 2) throw new Error('bad reply');
      this.live = { hill: this.conv(arr[0]), plain: this.conv(arr[1]) };
      this.liveOK = true;
    } catch {
      this.liveOK = false;
    }
    this.fetching = false;
  }

  public maybeFetch(enabled: boolean): void {
    const now = Date.now();
    if (enabled && !this.fetching && now > this.nextFetch) {
      this.nextFetch = now + 600000;
      this.fetchLive();
    }
  }

  public update(
    dt: number,
    c: { alt: number; month: number; hour: number; auto: boolean; live: boolean; day: number }
  ): void {
    const alt = c.alt;
    if (c.live && this.liveOK && this.live) {
      this.source = 'live';
      const a = sstep(600, 1100, alt);
      const h = this.live.hill;
      const p = this.live.plain;
      for (let i = 0; i < 5; i++) this.tgt[i] = p.v[i] * (1 - a) + h.v[i] * a;
      this.tempLive =
        (p.t - (6.5 * (alt - p.el)) / 1000) * (1 - a) +
        (h.t - (6.5 * (alt - h.el)) / 1000) * a;
    } else if (c.auto) {
      this.source = 'sim';
      if (this.lastAlt === null) this.lastAlt = alt;
      if (Math.abs(alt - this.lastAlt) > 350) {
        this.timer = 0;
        this.lastAlt = alt;
      }
      this.timer -= dt;
      if (this.timer <= 0) {
        this.cond = this.pickNext(alt, c.month, c.hour);
        this.tgt = [...COND[this.cond]];
        this.timer = 240 + Math.random() * 600;
      }
    }

    const k = 1 - Math.exp(-dt / 25);
    for (let i = 0; i < 5; i++) this.cur[i] += (this.tgt[i] - this.cur[i]) * k;

    const tT =
      c.live && this.liveOK
        ? this.tempLive
        : MTEMP[c.month] +
          5.5 * Math.cos(((c.hour - 14) / 24) * 2 * Math.PI) -
          (6.5 * (alt - 120)) / 1000 -
          2.5 * this.rain -
          1.5 * this.cloud * c.day;
    this.temp += (tT - this.temp) * (1 - Math.exp(-dt / 60));
    this.wet = clamp(this.wet + (this.rain > 0.08 ? (this.rain * dt) / 25 : -dt / 300), 0, 1);

    this.flash *= Math.exp(-dt * 6);
    if (this.storm > 0.4) {
      this.fl -= dt;
      if (this.fl <= 0) {
        this.flash = 1;
        this.fl = 4 + Math.random() * 16;
      }
    }

    this.wind = 0.15 + this.cloud * 0.35 + this.storm * 0.4;
    const [cl, r, f, s, st] = this.cur;
    this.label =
      st > 0.5
        ? 'Thunderstorm'
        : s > 0.5
        ? 'Snow'
        : s > 0.15
        ? 'Light snow'
        : r > 0.75
        ? 'Heavy rain'
        : r > 0.35
        ? 'Rain'
        : r > 0.08
        ? 'Light rain'
        : f > 0.5
        ? 'Fog'
        : f > 0.25
        ? 'Mist'
        : cl > 0.85
        ? 'Overcast'
        : cl > 0.55
        ? 'Cloudy'
        : cl > 0.2
        ? 'Partly cloudy'
        : c.day < 0.2
        ? 'Clear night'
        : 'Clear';
  }
}
