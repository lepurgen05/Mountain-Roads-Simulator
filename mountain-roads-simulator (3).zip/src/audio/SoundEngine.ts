/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private engineGain: GainNode | null = null;
  private tireGain: GainNode | null = null;
  private windGain: GainNode | null = null;
  private hornGain: GainNode | null = null;
  private rainGain: GainNode | null = null;

  // Engine oscillators
  private osc1: OscillatorNode | null = null;
  private osc2: OscillatorNode | null = null;
  private subOsc: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;

  // Noise buffers for tires and wind
  private tireFilter: BiquadFilterNode | null = null;
  private windFilter: BiquadFilterNode | null = null;

  // Horn
  private hornOsc1: OscillatorNode | null = null;
  private hornOsc2: OscillatorNode | null = null;

  // Refuel Pump Sound
  private refuelOsc: OscillatorNode | null = null;
  private refuelGain: GainNode | null = null;
  private refuelInterval: number | null = null;

  private isMuted: boolean = false;
  private masterVol: number = 0.8;
  private engineVol: number = 0.8;
  private isRunning: boolean = false;
  private inTunnel: boolean = false;

  constructor() {
    // Initialized lazily on first user interaction
  }

  public init(): void {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();

      const ctx = this.ctx;
      this.masterGain = ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.masterVol, ctx.currentTime);
      this.masterGain.connect(ctx.destination);

      // Engine Sound Chain
      this.engineGain = ctx.createGain();
      this.engineGain.gain.setValueAtTime(0.001, ctx.currentTime);

      this.engineFilter = ctx.createBiquadFilter();
      this.engineFilter.type = 'lowpass';
      this.engineFilter.frequency.setValueAtTime(400, ctx.currentTime);
      this.engineFilter.Q.setValueAtTime(2.5, ctx.currentTime);

      this.osc1 = ctx.createOscillator();
      this.osc1.type = 'sawtooth';
      this.osc1.frequency.setValueAtTime(35, ctx.currentTime);

      this.osc2 = ctx.createOscillator();
      this.osc2.type = 'triangle';
      this.osc2.frequency.setValueAtTime(70, ctx.currentTime);

      this.subOsc = ctx.createOscillator();
      this.subOsc.type = 'sine';
      this.subOsc.frequency.setValueAtTime(25, ctx.currentTime);

      this.osc1.connect(this.engineFilter);
      this.osc2.connect(this.engineFilter);
      this.subOsc.connect(this.engineFilter);
      this.engineFilter.connect(this.engineGain);
      this.engineGain.connect(this.masterGain);

      this.osc1.start();
      this.osc2.start();
      this.subOsc.start();

      // Tire Slip / Screech Noise
      const bufferSize = ctx.sampleRate * 2;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      this.tireFilter = ctx.createBiquadFilter();
      this.tireFilter.type = 'bandpass';
      this.tireFilter.frequency.setValueAtTime(950, ctx.currentTime);
      this.tireFilter.Q.setValueAtTime(3.0, ctx.currentTime);

      this.tireGain = ctx.createGain();
      this.tireGain.gain.setValueAtTime(0, ctx.currentTime);

      whiteNoise.connect(this.tireFilter);
      this.tireFilter.connect(this.tireGain);
      this.tireGain.connect(this.masterGain);
      whiteNoise.start();

      // Wind Rush Noise
      const windNoise = ctx.createBufferSource();
      windNoise.buffer = noiseBuffer;
      windNoise.loop = true;

      this.windFilter = ctx.createBiquadFilter();
      this.windFilter.type = 'lowpass';
      this.windFilter.frequency.setValueAtTime(200, ctx.currentTime);
      this.windFilter.Q.setValueAtTime(0.5, ctx.currentTime);

      this.windGain = ctx.createGain();
      this.windGain.gain.setValueAtTime(0, ctx.currentTime);

      windNoise.connect(this.windFilter);
      this.windFilter.connect(this.windGain);
      this.windGain.connect(this.masterGain);
      windNoise.start();

      // Rain Sound
      const rainNoise = ctx.createBufferSource();
      rainNoise.buffer = noiseBuffer;
      rainNoise.loop = true;

      const rainFilter = ctx.createBiquadFilter();
      rainFilter.type = 'highpass';
      rainFilter.frequency.setValueAtTime(1200, ctx.currentTime);

      this.rainGain = ctx.createGain();
      this.rainGain.gain.setValueAtTime(0, ctx.currentTime);

      rainNoise.connect(rainFilter);
      rainFilter.connect(this.rainGain);
      this.rainGain.connect(this.masterGain);
      rainNoise.start();

      // Dual-tone Indian Vehicle Horn
      this.hornGain = ctx.createGain();
      this.hornGain.gain.setValueAtTime(0, ctx.currentTime);

      this.hornOsc1 = ctx.createOscillator();
      this.hornOsc1.type = 'sawtooth';
      this.hornOsc1.frequency.setValueAtTime(420, ctx.currentTime);

      this.hornOsc2 = ctx.createOscillator();
      this.hornOsc2.type = 'sawtooth';
      this.hornOsc2.frequency.setValueAtTime(505, ctx.currentTime);

      const hornFilter = ctx.createBiquadFilter();
      hornFilter.type = 'bandpass';
      hornFilter.frequency.setValueAtTime(1000, ctx.currentTime);
      hornFilter.Q.setValueAtTime(1.2, ctx.currentTime);

      this.hornOsc1.connect(hornFilter);
      this.hornOsc2.connect(hornFilter);
      hornFilter.connect(this.hornGain);
      this.hornGain.connect(this.masterGain);

      this.hornOsc1.start();
      this.hornOsc2.start();

      this.isRunning = true;
    } catch (e) {
      console.warn('Web Audio could not be initialized:', e);
    }
  }

  public resume(): void {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public update(params: {
    rpm: number;
    throttle: number;
    speedKmh: number;
    slip: number;
    rain: number;
    inTunnel?: boolean;
  }): void {
    if (!this.ctx || !this.isRunning || this.isMuted) return;

    const t = this.ctx.currentTime;
    const { rpm, throttle, speedKmh, slip, rain, inTunnel } = params;

    this.inTunnel = !!inTunnel;

    // Base engine cylinder firing rate
    const baseFreq = Math.max(18, (rpm / 60) * 1.8);
    if (this.osc1 && this.osc2 && this.subOsc && this.engineFilter && this.engineGain) {
      this.osc1.frequency.setTargetAtTime(baseFreq, t, 0.05);
      this.osc2.frequency.setTargetAtTime(baseFreq * 2.01, t, 0.05);
      this.subOsc.frequency.setTargetAtTime(baseFreq * 0.5, t, 0.05);

      // Filter cutoff opens up with throttle and RPM
      const tunnelBoost = this.inTunnel ? 1.4 : 1.0;
      const targetCutoff = (300 + (rpm / 6000) * 2200 + throttle * 800) * tunnelBoost;
      this.engineFilter.frequency.setTargetAtTime(Math.min(8000, targetCutoff), t, 0.04);

      // Engine volume scales with throttle + base idle
      const engVolume = (0.15 + (rpm / 7000) * 0.25 + throttle * 0.35) * this.engineVol;
      this.engineGain.gain.setTargetAtTime(engVolume, t, 0.05);
    }

    // Tire slip screech
    if (this.tireGain && this.tireFilter) {
      const slipAmount = Math.max(0, Math.min(1, slip));
      const targetTireVol = slipAmount > 0.15 ? Math.pow(slipAmount, 1.5) * 0.45 : 0;
      this.tireGain.gain.setTargetAtTime(targetTireVol, t, 0.03);
      this.tireFilter.frequency.setTargetAtTime(800 + slipAmount * 900, t, 0.05);
    }

    // Wind rush with speed
    if (this.windGain && this.windFilter) {
      const speedNorm = Math.min(1.5, speedKmh / 100);
      const windVol = Math.pow(speedNorm, 2) * 0.25;
      this.windGain.gain.setTargetAtTime(windVol, t, 0.1);
      this.windFilter.frequency.setTargetAtTime(150 + speedNorm * 600, t, 0.1);
    }

    // Rain sound
    if (this.rainGain) {
      const rainVol = (rain > 0.05 ? rain * 0.22 : 0) * (this.inTunnel ? 0.2 : 1.0);
      this.rainGain.gain.setTargetAtTime(rainVol, t, 0.2);
    }
  }

  public honk(active: boolean): void {
    if (!this.ctx || !this.hornGain) return;
    const t = this.ctx.currentTime;
    this.hornGain.gain.setTargetAtTime(active ? 0.45 : 0, t, 0.02);
  }

  public setVolumes(master: number, engine: number): void {
    this.masterVol = master / 100;
    this.engineVol = engine / 100;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : this.masterVol, this.ctx.currentTime, 0.05);
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : this.masterVol, this.ctx.currentTime, 0.05);
    }
    return this.isMuted;
  }

  public crash(intensity: number = 1): void {
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      const vol = Math.min(1.0, 0.3 + intensity * 0.4);

      // Noise burst for metal crunch
      const len = 0.45;
      const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * len), ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < data.length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.12));
      }

      const src = ctx.createBufferSource();
      src.buffer = buf;

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800 + intensity * 600, t);
      filter.frequency.exponentialRampToValueAtTime(120, t + len);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(vol, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + len);

      src.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);
      src.start();

      // Low metal clunk thud
      const thud = ctx.createOscillator();
      thud.type = 'triangle';
      thud.frequency.setValueAtTime(140, t);
      thud.frequency.exponentialRampToValueAtTime(35, t + 0.3);

      const thudGain = ctx.createGain();
      thudGain.gain.setValueAtTime(vol * 0.9, t);
      thudGain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);

      thud.connect(thudGain);
      thudGain.connect(this.masterGain);
      thud.start();
      thud.stop(t + 0.35);
    } catch {
      // Audio fallback
    }
  }

  public startRefuelSound(): void {
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    try {
      this.stopRefuelSound();
      const ctx = this.ctx;
      const t = ctx.currentTime;

      // Fuel electric pump motor hum
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(115, t);

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(260, t);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(0.18, t + 0.2);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);
      osc.start();

      this.refuelOsc = osc;
      this.refuelGain = gain;

      // Periodic meter ticking (like mechanical flow counter)
      this.refuelInterval = window.setInterval(() => {
        if (!this.ctx || !this.masterGain || this.isMuted) return;
        try {
          const now = this.ctx.currentTime;
          const tickOsc = this.ctx.createOscillator();
          tickOsc.type = 'sine';
          tickOsc.frequency.setValueAtTime(1800, now);
          tickOsc.frequency.exponentialRampToValueAtTime(400, now + 0.03);

          const tickGain = this.ctx.createGain();
          tickGain.gain.setValueAtTime(0.08, now);
          tickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);

          tickOsc.connect(tickGain);
          tickGain.connect(this.masterGain);
          tickOsc.start(now);
          tickOsc.stop(now + 0.035);
        } catch {
          // ignore
        }
      }, 180);
    } catch {
      // Audio fallback
    }
  }

  public stopRefuelSound(): void {
    if (this.refuelInterval) {
      clearInterval(this.refuelInterval);
      this.refuelInterval = null;
    }
    if (this.refuelOsc && this.refuelGain && this.ctx) {
      try {
        const t = this.ctx.currentTime;
        this.refuelGain.gain.setValueAtTime(this.refuelGain.gain.value, t);
        this.refuelGain.gain.linearRampToValueAtTime(0.001, t + 0.15);
        this.refuelOsc.stop(t + 0.16);
      } catch {
        // ignore
      }
      this.refuelOsc = null;
      this.refuelGain = null;
    }
  }

  public refuelClick(): void {
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;

      // Heavy metallic nozzle latch clack
      const osc = ctx.createOscillator();
      osc.type = 'square';
      osc.frequency.setValueAtTime(820, t);
      osc.frequency.exponentialRampToValueAtTime(120, t + 0.08);

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1400, t);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.45, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.12);

      // Positive bell chime
      const bell = ctx.createOscillator();
      bell.type = 'sine';
      bell.frequency.setValueAtTime(1046.5, t + 0.04); // C6
      const bellGain = ctx.createGain();
      bellGain.gain.setValueAtTime(0.2, t + 0.04);
      bellGain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);

      bell.connect(bellGain);
      bellGain.connect(this.masterGain);
      bell.start(t + 0.04);
      bell.stop(t + 0.55);
    } catch {
      // ignore
    }
  }

  public lowFuelChime(): void {
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;

      // Two-tone warning beep
      [0, 0.18].forEach((offset, idx) => {
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(idx === 0 ? 880 : 1174, t + offset);

        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.25, t + offset);
        gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.12);

        osc.connect(gain);
        gain.connect(this.masterGain!);
        osc.start(t + offset);
        osc.stop(t + offset + 0.14);
      });
    } catch {
      // ignore
    }
  }

  public engineSputter(): void {
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;

      // Irregular combustion misfire puffs
      for (let i = 0; i < 3; i++) {
        const delay = i * 0.12 + Math.random() * 0.04;
        const osc = ctx.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(45 + Math.random() * 20, t + delay);
        osc.frequency.exponentialRampToValueAtTime(20, t + delay + 0.09);

        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.3, t + delay);
        gain.gain.exponentialRampToValueAtTime(0.001, t + delay + 0.09);

        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(t + delay);
        osc.stop(t + delay + 0.1);
      }
    } catch {
      // ignore
    }
  }

  public navChime(): void {
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      // High-clarity 2-tone Google Maps style chime (F6 -> A6)
      const notes = [
        { freq: 1046.5, time: 0, dur: 0.12 },
        { freq: 1318.5, time: 0.09, dur: 0.18 },
      ];

      notes.forEach((n) => {
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(n.freq, t + n.time);

        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.2, t + n.time);
        gain.gain.exponentialRampToValueAtTime(0.001, t + n.time + n.dur);

        osc.connect(gain);
        gain.connect(this.masterGain!);
        osc.start(t + n.time);
        osc.stop(t + n.time + n.dur + 0.02);
      });
    } catch {
      // ignore
    }
  }
}

export const sound = new SoundEngine();
