/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { buildModel, VehicleModelResult } from './model.ts';
import { VehicleDefinition, RoadSampleState } from '../types.ts';
import { Input } from '../core/input.ts';
import { sound } from '../audio/SoundEngine.ts';

const G = 9.81;

const tbl = (t: [number, number][], x: number): number => {
  if (x <= t[0][0]) return t[0][1];
  for (let i = 1; i < t.length; i++) {
    if (x <= t[i][0]) {
      const a = t[i - 1];
      const b = t[i];
      return a[1] + ((b[1] - a[1]) * (x - a[0])) / (b[0] - a[0]);
    }
  }
  return t[t.length - 1][1];
};

export interface WorldInterface {
  groundAt(x: number, z: number, st: RoadSampleState): number;
  constrain(v: Vehicle): void;
}

export class Vehicle {
  public def: VehicleDefinition;
  public model: VehicleModelResult;
  public root: THREE.Group;
  public x = 0;
  public y = 0;
  public z = 0;
  public yaw = 0;
  public vx = 0;
  public vz = 0;
  public vy = 0;
  public vf = 0; // forward velocity
  public steer = 0;
  public delta = 0; // wheel steer angle
  public pitch = 0;
  public roll = 0;
  public pd = 0; // pitch dynamic (squat/dive)
  public rd = 0; // roll dynamic (centrifugal)
  public thr = 0; // throttle 0-1
  public shiftT = 0;
  public ax = 0;
  public w = 0; // angular yaw velocity
  public slope = 0;
  public gear = 1;
  public rpm = 900;
  public slip = 0;
  public st: RoadSampleState = { i: 0, off: 0, hw: 4, rx: 1, rz: 0 };
  public lights = false;
  public ts: number = 0;
  public lightK = 1;
  public lk = 1;
  public isBraking = false;
  public damage = 0; // 0 to 100%

  // Fuel System Properties
  public fuelCapacity: number;
  public fuel: number;
  public fuelRateLps = 0; // Liters per second
  public fuelRateL100km = 0; // Liters per 100km
  public isOutOfFuel = false;
  public isLowFuel = false;
  public isCriticalFuel = false;
  public isRefueling = false;
  public refuelProgress = 0;
  public refueledLitersThisSession = 0;
  public totalCostThisSession = 0;
  private refuelPricePerL = 96.8;
  private hasWarnedLowFuel = false;
  private sputterTimer = 0;

  constructor(def: VehicleDefinition, scene: THREE.Scene) {
    this.def = def;
    this.model = buildModel(def);
    this.root = this.model.root;
    this.root.rotation.order = 'YXZ';
    scene.add(this.root);
    this.rpm = def.idle;
    this.fuelCapacity = def.fuelCapacity || 35;
    this.fuel = this.fuelCapacity;
  }

  // Speed-to-Steer Sensitivity Configuration
  public speedSteerEnabled: boolean = true;
  public speedSteerSensitivity: number = 65; // 0 - 100%
  public steerSensitivity: number = 100; // 50 - 150%

  public setSteerSettings(enabled = true, speedSens = 65, rateSens = 100): void {
    this.speedSteerEnabled = enabled;
    this.speedSteerSensitivity = speedSens;
    this.steerSensitivity = rateSens;
  }

  public applyDamage(impactLocal: THREE.Vector3, force: number): void {
    const d = this.model.applyDamage(impactLocal, force);
    this.damage = Math.round(d * 100);
  }

  public repair(): void {
    this.damage = 0;
    this.model.repairDamage();
  }

  public startRefueling(pricePerLiter = 96.8): void {
    if (this.fuel >= this.fuelCapacity) return;
    this.isRefueling = true;
    this.refuelPricePerL = pricePerLiter;
    this.refuelProgress = (this.fuel / this.fuelCapacity) * 100;
    sound.startRefuelSound();
  }

  public stopRefueling(): void {
    if (this.isRefueling) {
      this.isRefueling = false;
      sound.stopRefuelSound();
      sound.refuelClick();
    }
  }

  public emergencyRefuel(amountLiters = 15): void {
    this.fuel = Math.min(this.fuelCapacity, this.fuel + amountLiters);
    this.isOutOfFuel = false;
    this.hasWarnedLowFuel = false;
    sound.refuelClick();
  }

  public placeAt(x: number, z: number, yaw: number, world: WorldInterface, shouldRepair = true): void {
    this.x = x;
    this.z = z;
    this.yaw = yaw;
    this.vx = this.vz = this.vf = this.vy = this.thr = this.steer = this.w = this.slope = this.ax = this.pd = this.rd = 0;
    this.gear = 1;
    this.st.dom = -1;
    if (shouldRepair) {
      this.repair();
      if (this.fuel < 8) this.fuel = this.fuelCapacity * 0.8;
      this.isOutOfFuel = false;
      this.hasWarnedLowFuel = false;
    }
    this.y = world.groundAt(x, z, this.st);
    this.ts = this.y;
    this.apply(0);
  }

  public setLights(on: boolean): void {
    if (on !== this.lights || this.lk !== this.lightK) {
      this.lights = on;
      this.lk = this.lightK;
      this.model.setHeadlights(on, this.lightK);
    }
  }

  public toggleLights(): void {
    this.lights = !this.lights;
    this.model.setHeadlights(this.lights, this.lightK);
  }

  public setReflections(t: THREE.Texture | null): void {
    for (const m of this.model.envMats) {
      m.envMap = t;
      m.envMapIntensity = 0.95;
      m.needsUpdate = true;
    }
  }

  get speedKmh(): number {
    return Math.abs(this.vf) * 3.6;
  }

  public update(dt: number, inp: Input, world: WorldInterface): void {
    const d = this.def;
    const st = this.st;
    let s = Math.sin(this.yaw);
    let c = Math.cos(this.yaw);

    const offRoad = Math.abs(st.off) > st.hw + 1;
    const mu = offRoad ? 0.58 : d.mu;
    const lim = mu * G;
    let vf = this.vx * s + this.vz * c;

    let thrT = 0;
    let brk = false;

    // Refueling logic: vehicle remains parked/braked during refueling
    if (this.isRefueling) {
      brk = true;
      thrT = 0;
      this.thr = 0;
      const fillRate = 3.2; // L/s
      const fillAmount = fillRate * dt;
      const needed = this.fuelCapacity - this.fuel;
      const actualFill = Math.min(needed, fillAmount);

      this.fuel += actualFill;
      this.refueledLitersThisSession += actualFill;
      this.totalCostThisSession += actualFill * this.refuelPricePerL;
      this.refuelProgress = Math.min(100, (this.fuel / this.fuelCapacity) * 100);

      if (this.fuel >= this.fuelCapacity - 0.01) {
        this.fuel = this.fuelCapacity;
        this.isRefueling = false;
        this.isOutOfFuel = false;
        sound.stopRefuelSound();
        sound.refuelClick();
      }
    } else {
      if (inp.isThrottle && !this.isOutOfFuel) {
        if (vf > -0.6) thrT = inp.touchUp > 0 ? inp.touchUp : 1;
        else brk = true;
      }
      if (inp.isBrake) {
        if (vf > 0.6) brk = true;
        else if (!this.isOutOfFuel) thrT = inp.touchDown > 0 ? inp.touchDown : 1;
      }
    }

    this.isBraking = brk || inp.isHandbrake;
    this.model.setBrakeLights(this.isBraking);

    // Smooth throttle pedal actuation
    this.thr += (thrT - this.thr) * (1 - Math.exp(-9 * dt));

    // Gear shift logic
    if (inp.isBrake && vf <= 0.5) this.gear = -1;
    else if (
      this.gear < 0 &&
      ((inp.isThrottle && vf > -0.5) || (!inp.isThrottle && !inp.isBrake && Math.abs(vf) < 0.2))
    ) {
      this.gear = 1;
    }

    const ratio = (this.gear < 0 ? d.reverseRatio : d.gears[this.gear - 1]) * d.final;
    this.shiftT = Math.max(0, this.shiftT - dt);

    if (this.gear > 0 && this.shiftT === 0) {
      if (this.gear < d.gears.length && this.rpm > d.upRpm && this.thr > 0.3) {
        this.gear++;
        this.shiftT = 0.28;
      } else if (this.gear > 1 && this.rpm < d.downRpm) {
        this.gear--;
        this.shiftT = 0.2;
      }
    }

    // Dynamic Fuel Consumption based on RPM and load
    if (this.fuel > 0.001) {
      this.isOutOfFuel = false;
      this.rpm = Math.max(d.idle, (Math.abs(vf) / d.wheelR) * ratio * 9.5493);

      const massScale = this.def.mass / 1000;
      const rpmFraction = Math.max(0, (this.rpm - d.idle) / (d.redline - d.idle));

      // Engine load: throttle pedal + uphill grade resistance + acceleration force
      const slopeLoad = Math.max(0, this.slope * 3.8);
      const accelLoad = Math.max(0, this.ax * 0.08);
      const engineLoad = Math.min(2.5, this.thr * (1 + slopeLoad) + accelLoad);

      // Decel fuel cut-off (DFCO) when coasting at speed with zero throttle
      const isCoasting = this.thr < 0.02 && Math.abs(vf) > 4.0;
      const baseIdleLps = isCoasting ? 0.00004 * massScale : 0.00014 * massScale;

      // Load & RPM driven fuel rate
      const loadLps = massScale * 0.0018 * Math.pow(rpmFraction, 1.35) * (0.05 + engineLoad * 1.45);
      this.fuelRateLps = baseIdleLps + loadLps;
      this.fuel = Math.max(0, this.fuel - this.fuelRateLps * dt);

      // Calculate instant L/100km
      const speedKmh = this.speedKmh;
      if (speedKmh > 3.0) {
        this.fuelRateL100km = (this.fuelRateLps * 3600 / speedKmh) * 100;
      } else {
        this.fuelRateL100km = 0;
      }

      // Fuel status checks
      const fuelFrac = this.fuel / this.fuelCapacity;
      this.isLowFuel = fuelFrac < 0.15;
      this.isCriticalFuel = fuelFrac < 0.05;

      if (this.isLowFuel && !this.hasWarnedLowFuel) {
        this.hasWarnedLowFuel = true;
        sound.lowFuelChime();
      } else if (!this.isLowFuel) {
        this.hasWarnedLowFuel = false;
      }
    } else {
      // Out of fuel!
      this.fuel = 0;
      this.isOutOfFuel = true;
      this.fuelRateLps = 0;
      this.fuelRateL100km = 0;
      this.isLowFuel = true;
      this.isCriticalFuel = true;

      // Sputter / engine die down
      this.rpm += (0 - this.rpm) * (1 - Math.exp(-6 * dt));
      this.sputterTimer += dt;
      if (this.sputterTimer > 1.8 && Math.abs(vf) > 0.4) {
        this.sputterTimer = 0;
        sound.engineSputter();
      }
    }

    // Engine driving force
    let F = 0;
    const kRatio = (ratio * d.eta) / d.wheelR;
    if (this.shiftT === 0 && this.rpm < d.redline && !this.isOutOfFuel && !this.isRefueling) {
      if (this.thr > 0.02) {
        F =
          tbl(d.torque, Math.max(this.rpm, this.thr > 0.05 ? d.clutchRpm : d.idle)) *
          this.thr *
          kRatio *
          (this.gear < 0 ? -Math.max(0, 1 + vf / d.maxReverse) : 1);
      } else if (Math.abs(vf) > 0.5) {
        F = -Math.sign(vf) * d.engBrake * (this.rpm / 3000) * kRatio;
      }
    }

    const Fmax = mu * d.mass * G * d.driveShare;
    F = Math.max(-Fmax, Math.min(Fmax, F));

    const sg = Math.sign(vf) || 1;
    const drag = 0.5 * 1.2 * d.cdA * vf * Math.abs(vf);
    const roll = (offRoad ? 0.07 : d.crr) * d.mass * G * Math.min(1, Math.abs(vf) / 0.5) * sg;
    let Fb = brk ? Math.min(mu * 0.95, d.brakeG) * G * d.mass * sg : 0;
    if (inp.isHandbrake) Fb += 0.35 * G * d.mass * sg;

    const a = (F - drag - roll - Fb) / d.mass - G * this.slope;
    let nf = vf + a * dt;

    if (vf * nf < 0 && thrT === 0) nf = 0;
    if (!inp.isThrottle && !inp.isBrake && !inp.isHandbrake && Math.abs(nf) < 0.4 && Math.abs(this.slope) < 0.25) {
      nf = 0;
    }

    this.vx += (nf - vf) * s;
    this.vz += (nf - vf) * c;
    this.ax += (a - this.ax) * (1 - Math.exp(-9 * dt));

    // Dynamic Speed-to-Steer Sensitivity Model
    const steerInput = inp.steerVal;
    const steerRateMultiplier = (this.steerSensitivity ?? 100) / 100;
    const steerResponseSpeed = 8.5 * steerRateMultiplier;
    this.steer += (steerInput - this.steer) * (1 - Math.exp(-steerResponseSpeed * dt));

    const av = Math.abs(nf);
    const latMax = Math.sqrt(Math.max(0, lim * lim - a * a * 0.9)) * (inp.isHandbrake ? 0.4 : 1);

    let maxSteerAngle = d.maxSteer;
    if (this.speedSteerEnabled !== false) {
      const speedKmh = av * 3.6;
      const speedSensRatio = (this.speedSteerSensitivity ?? 65) / 100;
      // Hyperbolic speed sensitivity falloff:
      // - At 0 km/h: factor = 1.0 (full lock available for sharp hairpin turns & parking)
      // - At 45 km/h: factor = ~0.60 (agile mountain road cornering)
      // - At 90 km/h: factor = ~0.35 (solid highway high-speed stability without twitchiness)
      const speedDecay = 1 / (1 + (speedKmh / 42) * (speedSensRatio * 1.1));
      const minLockRatio = 1 - speedSensRatio * 0.72; // never drops below ~28% lock
      maxSteerAngle = d.maxSteer * (minLockRatio + (1 - minLockRatio) * speedDecay);
    }

    this.delta = this.steer * Math.min(d.maxSteer, Math.max(0.08, maxSteerAngle));

    let w = (nf * Math.tan(this.delta)) / d.wheelbase;
    const wMax = latMax / Math.max(av, 1);
    if (Math.abs(w) > wMax) w = Math.sign(w) * wMax;
    if (inp.isHandbrake) w *= 1.45;

    this.yaw += w * dt;
    this.w = w;

    s = Math.sin(this.yaw);
    c = Math.cos(this.yaw);
    const rx = c;
    const rz = -s;
    vf = this.vx * s + this.vz * c;
    let vl = this.vx * rx + this.vz * rz;

    // Lateral friction & slip
    const latFriction = Math.min(Math.abs(vl) * d.stiff, latMax) * dt;
    vl -= Math.sign(vl) * Math.min(Math.abs(vl), latFriction);

    // Calculate slip for sound engine
    this.slip = Math.min(1, Math.abs(vl) / 3.5 + (inp.isHandbrake ? 0.5 : 0));

    this.vx = s * vf + rx * vl;
    this.vz = c * vf + rz * vl;
    this.vf = vf;
    this.x += this.vx * dt;
    this.z += this.vz * dt;

    // 4-point ground probing for suspension
    const hl = d.track / 2;
    const hb = d.wheelbase / 2;
    const hFL = world.groundAt(this.x + s * hb - rx * hl, this.z + c * hb - rz * hl, st);
    const hFR = world.groundAt(this.x + s * hb + rx * hl, this.z + c * hb + rz * hl, st);
    const hRL = world.groundAt(this.x - s * hb - rx * hl, this.z - c * hb - rz * hl, st);
    const hRR = world.groundAt(this.x - s * hb + rx * hl, this.z - c * hb + rz * hl, st);

    world.groundAt(this.x, this.z, st);
    world.constrain(this);

    const rawSlope = Math.max(-0.4, Math.min(0.4, ((hFL + hFR) / 2 - (hRL + hRR) / 2) / d.wheelbase));
    this.slope += (rawSlope - this.slope) * (1 - Math.exp(-12 * dt));

    const targetHeight = (hFL + hFR + hRL + hRR) / 4;
    const prevTs = this.ts;
    this.ts += (targetHeight - this.ts) * (1 - Math.exp(-25 * dt));
    const tv = dt > 0 ? (this.ts - prevTs) / dt : 0;
    const gap = this.y - this.ts;

    if (gap > 0.2) this.vy -= G * dt;
    else this.vy += (-gap * 900 - (this.vy - tv) * 60) * dt;

    this.vy = Math.max(-12, Math.min(4, this.vy));
    this.y += this.vy * dt;
    if (this.y < this.ts - 0.25) {
      this.y = this.ts - 0.25;
      this.vy = Math.max(0, this.vy);
    }

    // Dynamic pitch and roll with suspension damping
    const kk = 1 - Math.exp(-12 * dt);
    this.pitch += (-Math.atan2((hFL + hFR) / 2 - (hRL + hRR) / 2, d.wheelbase) - this.pitch) * kk;
    this.roll += (Math.atan2((hFR + hRR) / 2 - (hFL + hRL) / 2, d.track) - this.roll) * kk;

    // Body dive / squat & cornering body roll
    this.pd += (Math.max(-0.06, Math.min(0.06, -this.ax * 0.012)) - this.pd) * kk;
    this.rd += (Math.max(-0.09, Math.min(0.09, w * this.vf * 0.014)) - this.rd) * kk;

    this.apply(dt);

    // Audio update
    sound.update({
      rpm: this.rpm,
      throttle: this.thr,
      speedKmh: this.speedKmh,
      slip: this.slip,
      rain: 0,
      inTunnel: !!st.inTunnel,
    });
    sound.honk(inp.horn);
  }

  public apply(dt: number): void {
    this.root.position.set(this.x, this.y, this.z);
    this.root.rotation.set(this.pitch + this.pd, this.yaw, this.roll + this.rd, 'YXZ');

    for (const w of this.model.wheels) {
      w.spin.rotation.x += (this.vf * dt) / this.def.wheelR;
      w.pivot.rotation.y = w.front ? this.delta : 0;
    }
    this.model.swheel.rotation.z = -this.steer * 2.4;

    if (this.model.updateDashboard) {
      this.model.updateDashboard(
        this.speedKmh,
        this.rpm,
        this.gear < 0 ? 'R' : `G${this.gear}`,
        this.fuel / this.fuelCapacity,
        this.lights
      );
    }
  }
}
