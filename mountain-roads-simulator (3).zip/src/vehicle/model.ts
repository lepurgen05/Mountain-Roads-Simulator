/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { canvasTex } from '../core/textures.ts';
import { VehicleDefinition } from '../types.ts';

const std = (c: number, r: number, m = 0) =>
  new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m });

function extrude(pts: [number, number][], width: number, bevel: number, mat: THREE.Material): THREE.Mesh {
  const sh = new THREE.Shape();
  pts.forEach(([z, y], i) => (i ? sh.lineTo(z, y) : sh.moveTo(z, y)));
  sh.closePath();
  const d = width - 2 * bevel;
  const g = new THREE.ExtrudeGeometry(sh, {
    depth: d,
    bevelEnabled: true,
    bevelThickness: bevel,
    bevelSize: bevel,
    bevelOffset: -bevel,
    bevelSegments: 3,
    curveSegments: 4,
  });
  g.translate(0, 0, -d / 2);
  g.rotateY(-Math.PI / 2);
  return new THREE.Mesh(g, mat);
}

const add = (
  p: THREE.Group,
  w: number,
  h: number,
  d: number,
  m: THREE.Material,
  x: number,
  y: number,
  z: number,
  rx = 0
): THREE.Mesh => {
  const o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  o.position.set(x, y, z);
  o.rotation.x = rx;
  p.add(o);
  return o;
};

const cyl = (
  p: THREE.Group,
  r: number,
  l: number,
  m: THREE.Material,
  x: number,
  y: number,
  z: number
): THREE.Mesh => {
  const o = new THREE.Mesh(new THREE.CylinderGeometry(r, r, l, 16).rotateX(Math.PI / 2), m);
  o.position.set(x, y, z);
  p.add(o);
  return o;
};

function hatch(def: VehicleDefinition, B: THREE.Group, M: Record<string, THREE.Material>): void {
  const a = (...r: Parameters<typeof add> extends [any, ...infer Rest] ? Rest : never) => add(B, ...r);
  B.add(
    extrude(
      [
        [-1.64, 0.2],
        [1.6, 0.2],
        [1.68, 0.32],
        [1.69, 0.56],
        [1.6, 0.68],
        [0.85, 0.8],
        [0.72, 0.86],
        [-1.58, 0.88],
        [-1.67, 0.76],
        [-1.68, 0.4],
      ],
      1.4,
      0.07,
      M.paint
    )
  );
  B.add(
    extrude(
      [
        [0.78, 0.84],
        [0.36, 1.33],
        [-1.1, 1.33],
        [-1.56, 0.86],
      ],
      1.3,
      0.04,
      M.glass
    )
  );
  B.add(
    extrude(
      [
        [0.4, 1.3],
        [0.37, 1.39],
        [-1.12, 1.39],
        [-1.14, 1.3],
      ],
      1.34,
      0.03,
      M.paint
    )
  );
  for (const sx of [-1, 1]) {
    a(0.05, 0.64, 0.07, M.paint, sx * 0.65, 1.085, 0.57, -0.63);
    a(0.07, 0.62, 0.1, M.paint, sx * 0.65, 1.09, -1.35, 0.74);
    for (const z of [0.5, -0.55]) a(0.012, 0.5, 0.015, M.trim, sx * 0.705, 0.58, z);
    a(0.12, 0.03, 0.03, M.chrome, sx * 0.71, 0.78, 0.25);
    a(0.1, 0.1, 0.18, M.trim, sx * 0.76, 0.98, 0.6);
    a(0.3, 0.16, 0.07, M.chrome, sx * 0.5, 0.62, 1.68);
    a(0.26, 0.13, 0.06, M.head, sx * 0.5, 0.62, 1.71);
    a(0.12, 0.26, 0.05, M.tail, sx * 0.58, 0.66, -1.7);
  }
  a(1.4, 0.15, 0.1, M.trim, 0, 0.34, 1.66);
  a(1.4, 0.15, 0.1, M.trim, 0, 0.32, -1.66);
  a(0.5, 0.1, 0.05, M.trim, 0, 0.6, 1.7);
  for (let i = 0; i < 4; i++) a(0.5, 0.012, 0.02, M.chrome, 0, 0.57 + i * 0.025, 1.73);
  a(0.4, 0.12, 0.02, M.chrome, 0, 0.45, 1.72);
  a(0.4, 0.12, 0.02, M.chrome, 0, 0.5, -1.72);
}

function thar(def: VehicleDefinition, B: THREE.Group, M: Record<string, THREE.Material>): void {
  const a = (...r: Parameters<typeof add> extends [any, ...infer Rest] ? Rest : never) => add(B, ...r);
  B.add(
    extrude(
      [
        [-1.95, 0.38],
        [1.95, 0.38],
        [2.0, 0.55],
        [2.0, 0.98],
        [1.1, 1.03],
        [0.85, 1.05],
        [-1.95, 1.05],
      ],
      1.78,
      0.05,
      M.paint
    )
  );
  B.add(
    extrude(
      [
        [0.75, 1.05],
        [0.68, 1.78],
        [-1.9, 1.78],
        [-1.95, 1.05],
      ],
      1.66,
      0.03,
      M.glass
    )
  );
  B.add(
    extrude(
      [
        [0.72, 1.74],
        [0.7, 1.84],
        [-1.94, 1.84],
        [-1.96, 1.74],
      ],
      1.72,
      0.03,
      M.paint
    )
  );
  for (const sx of [-1, 1]) {
    a(0.07, 0.8, 0.07, M.trim, sx * 0.82, 1.42, 0.7, -0.08);
    a(0.07, 0.7, 0.12, M.paint, sx * 0.84, 1.42, -1.93);
    cyl(B, 0.13, 0.07, M.chrome, sx * 0.66, 0.8, 2.0);
    cyl(B, 0.1, 0.08, M.head, sx * 0.66, 0.8, 2.02);
    a(0.12, 0.1, 1.0, M.trim, sx * 0.95, 0.86, 1.225);
    a(0.12, 0.1, 1.0, M.trim, sx * 0.95, 0.86, -1.225);
    a(0.12, 0.22, 0.05, M.tail, sx * 0.8, 0.8, -1.99);
    a(0.12, 0.16, 0.18, M.trim, sx * 1.0, 1.1, 0.85);
    a(0.2, 0.05, 1.6, M.trim, sx * 0.95, 0.4, 0);
  }
  a(1.2, 0.4, 0.05, M.trim, 0, 0.78, 2.0);
  for (let i = -3; i <= 3; i++) a(0.07, 0.34, 0.04, M.paint, i * 0.15, 0.78, 2.03);
  a(1.8, 0.22, 0.15, M.trim, 0, 0.42, 2.02);
  a(1.8, 0.22, 0.15, M.trim, 0, 0.42, -2.0);
  cyl(B, 0.36, 0.22, M.tire, 0, 0.95, -2.1);
  cyl(B, 0.2, 0.24, M.rim, 0, 0.95, -2.1);
}

function truck(def: VehicleDefinition, B: THREE.Group, M: Record<string, THREE.Material>): void {
  const a = (...r: Parameters<typeof add> extends [any, ...infer Rest] ? Rest : never) => add(B, ...r);
  a(1.3, 0.22, 5.8, M.trim, 0, 0.62, -0.25);
  B.add(
    extrude(
      [
        [1.0, 0.8],
        [2.65, 0.8],
        [2.7, 1.4],
        [2.55, 2.55],
        [1.05, 2.62],
        [1.0, 2.4],
      ],
      2.1,
      0.06,
      M.paint
    )
  );
  a(1.9, 0.95, 0.05, M.glass, 0, 1.95, 2.58);
  for (const sx of [-1, 1]) {
    a(0.03, 0.7, 0.9, M.glass, sx * 1.07, 1.95, 1.85);
    a(0.012, 0.9, 0.015, M.trim, sx * 1.07, 1.5, 1.4);
    a(0.1, 0.5, 0.1, M.trim, sx * 1.28, 1.9, 2.3);
    a(0.3, 0.2, 0.07, M.head, sx * 0.8, 1.0, 2.72);
    a(0.1, 0.22, 0.05, M.tail, sx * 1.0, 1.15, -3.12);
  }
  a(1.4, 0.4, 0.05, M.trim, 0, 1.0, 2.7);
  a(2.1, 0.25, 0.2, M.trim, 0, 0.55, 2.7);
  a(0.8, 0.12, 0.04, M.chrome, 0, 1.0, 2.74);
  a(2.1, 0.12, 4.2, M.wood, 0, 1.02, -1.0);
  for (const sx of [-1, 1]) {
    a(0.08, 0.7, 4.2, M.accent, sx * 1.0, 1.43, -1.0);
    for (let k = 0; k < 5; k++) a(0.1, 0.7, 0.06, M.wood, sx * 1.0, 1.43, -2.9 + k * 0.9);
  }
  a(2.1, 0.9, 0.08, M.accent, 0, 1.48, 1.06);
  a(2.1, 0.7, 0.08, M.accent, 0, 1.43, -3.1);

  const t = new THREE.Mesh(
    new THREE.PlaneGeometry(1.9, 0.45),
    new THREE.MeshBasicMaterial({
      map: canvasTex('HORN OK PLEASE', 512, 96, '#1f4f9a', '#ffd83a', 'bold 54px Arial'),
    })
  );
  t.position.set(0, 1.45, -3.15);
  t.rotation.y = Math.PI;
  B.add(t);

  for (let i = 0; i < 4; i++) {
    a(
      0.6 + (i % 2) * 0.3,
      0.5 + (i % 3) * 0.15,
      0.6,
      M.wood,
      i % 2 ? 0.4 : -0.4,
      1.4 + i * 0.02,
      -0.5 - i * 0.7
    );
  }
}

function bus(def: VehicleDefinition, B: THREE.Group, M: Record<string, THREE.Material>): void {
  const a = (...r: Parameters<typeof add> extends [any, ...infer Rest] ? Rest : never) => add(B, ...r);
  const cream = std(0xf0e6c8, 0.6);
  B.add(
    extrude(
      [
        [-4.75, 0.6],
        [4.5, 0.6],
        [4.7, 0.8],
        [4.75, 1.6],
        [4.6, 2.0],
        [4.5, 3.25],
        [-4.7, 3.3],
        [-4.75, 0.6],
      ],
      2.45,
      0.08,
      M.paint
    )
  );
  for (const sx of [-1, 1]) {
    a(0.03, 0.35, 8.6, cream, sx * 1.24, 1.35, -0.2);
    a(0.03, 0.95, 7.9, M.glass, sx * 1.24, 2.5, -0.35);
    for (let k = 0; k < 7; k++) a(0.05, 1.0, 0.06, M.trim, sx * 1.24, 2.5, -4 + k * 1.15);
    a(0.12, 0.5, 0.12, M.trim, sx * 1.35, 2.5, 4.2);
    cyl(B, 0.15, 0.08, M.head, sx * 0.85, 1.1, 4.78);
    a(0.12, 0.25, 0.05, M.tail, sx * 1.0, 1.5, -4.77);
  }
  a(2.2, 1.2, 0.04, M.glass, 0, 2.65, 4.52);
  a(2.0, 0.8, 0.04, M.glass, 0, 2.7, -4.72);
  a(1.2, 0.5, 0.05, M.trim, 0, 1.1, 4.78);
  a(2.5, 0.3, 0.25, M.trim, 0, 0.7, 4.72);
  a(2.5, 0.3, 0.25, M.trim, 0, 0.7, -4.72);

  const s = new THREE.Mesh(
    new THREE.PlaneGeometry(1.6, 0.32),
    new THREE.MeshBasicMaterial({
      map: canvasTex('RIMBICK - DARJEELING', 512, 96, '#111', '#ffcf33', 'bold 40px Arial'),
    })
  );
  s.position.set(0, 3.08, 4.53);
  B.add(s);

  a(2.3, 0.05, 6.2, M.trim, 0, 3.4, -0.8);
  for (let i = 0; i < 6; i++) {
    a(
      0.8 + (i % 3) * 0.3,
      0.5 + (i % 2) * 0.3,
      0.9,
      [M.wood, M.accent, cream][i % 3],
      i % 2 ? 0.5 : -0.5,
      3.7,
      -3.2 + i * 1.0
    );
  }
}

const BUILD = { hatch, thar, truck, bus };

export interface VehicleModelResult {
  root: THREE.Group;
  body: THREE.Group;
  interior: THREE.Group;
  wheels: { pivot: THREE.Group; spin: THREE.Group; front: boolean }[];
  swheel: THREE.Group;
  setHeadlights: (on: boolean, k?: number) => void;
  setBrakeLights: (on: boolean) => void;
  setHazardLights?: (on: boolean) => void;
  applyDamage: (impactLocal: THREE.Vector3, force: number) => number;
  repairDamage: () => void;
  getDamage: () => number;
  envMats: THREE.MeshStandardMaterial[];
  updateDashboard?: (
    speedKmh: number,
    rpm: number,
    gear: string,
    fuelFrac: number,
    lights: boolean,
    navInstruction?: string
  ) => void;
}

export function buildModel(def: VehicleDefinition, opts: { lights?: boolean; bake?: boolean } = {}): VehicleModelResult {
  const root = new THREE.Group();
  const body = new THREE.Group();
  const interior = new THREE.Group();
  root.add(body, interior);
  interior.visible = false;

  const M: Record<string, THREE.MeshStandardMaterial> = {
    paint: new THREE.MeshPhysicalMaterial({
      color: def.color,
      metalness: 0.35,
      roughness: 0.28,
      clearcoat: 0.88,
      clearcoatRoughness: 0.12,
    }) as unknown as THREE.MeshStandardMaterial,
    glass: std(0x0d151c, 0.06, 0.9),
    rim: std(0x9aa0a6, 0.35, 0.75),
    tire: std(0x111111, 0.95),
    trim: std(0x1a1a1a, 0.8),
    cabin: std(0x2b2a2d, 0.9),
    liner: std(0x8d8a82, 0.95),
    chrome: std(0xcfd3d6, 0.15, 1.0),
    accent: std(def.accent ?? 0x1f4f9a, 0.5, 0.2),
    wood: std(0x8a6a44, 0.9),
    head: new THREE.MeshStandardMaterial({
      color: 0xdddddd,
      emissive: 0xffffee,
      emissiveIntensity: 0.1,
      roughness: 0.2,
    }),
    tail: new THREE.MeshStandardMaterial({
      color: 0x660000,
      emissive: 0xff1111,
      emissiveIntensity: 0.4,
    }),
  };

  BUILD[def.type](def, body, M);

  const [cx, cy, cz] = def.cam.cockpit;
  const w = def.width;

  // ==========================================
  // REALISTIC COCKPIT INTERIOR & DASHBOARD
  // ==========================================
  // 1. Front Hood / Bonnet extension (matches vehicle authentic paint & contour)
  const hoodL = Math.max(1.1, def.length * 0.36);
  const hoodY = cy - 0.28;
  const hoodZ = cz + 0.6 + hoodL / 2;
  const hoodMesh = add(interior, w * 0.94, 0.08, hoodL, M.paint, 0, hoodY, hoodZ);
  hoodMesh.rotation.x = -0.04;
  // Center hood crease
  add(interior, w * 0.38, 0.03, hoodL * 0.9, M.paint, 0, hoodY + 0.04, hoodZ);

  // Twin windscreen wipers resting on cowl
  for (const sx of [-0.3, 0.25]) {
    add(interior, 0.42, 0.015, 0.02, M.trim, sx, cy - 0.22, cz + 0.62, 0.1);
  }

  // 2. Windshield frame & A-pillars
  for (const sx of [-1, 1]) {
    add(interior, 0.05, 0.75, 0.07, M.trim, sx * (w / 2 - 0.08), cy + 0.12, cz + 0.58, -0.6);
  }
  // Windscreen top header
  add(interior, w * 0.88, 0.05, 0.06, M.trim, 0, cy + 0.42, cz + 0.3);
  // Interior rearview mirror angled toward driver
  const rvm = add(interior, 0.22, 0.07, 0.02, M.chrome, 0, cy + 0.36, cz + 0.34);
  rvm.rotation.y = cx > 0 ? 0.25 : -0.25;
  rvm.rotation.x = 0.15;

  // Sun visors
  for (const sx of [-1, 1]) {
    add(interior, 0.32, 0.02, 0.12, M.cabin, sx * 0.32, cy + 0.4, cz + 0.25);
  }

  // 2B. Euro Truck Simulator 2 Style Dual Wing Mirrors (Driver & Passenger Side Rear-Vision)
  const mirrorCanvas = document.createElement('canvas');
  mirrorCanvas.width = 128;
  mirrorCanvas.height = 256;
  const mctx = mirrorCanvas.getContext('2d')!;
  const mirrorTex = new THREE.CanvasTexture(mirrorCanvas);
  mirrorTex.colorSpace = THREE.SRGBColorSpace;
  const mirrorMat = new THREE.MeshBasicMaterial({ map: mirrorTex });

  for (const sx of [-1, 1]) {
    const mx = sx * (w / 2 + 0.14);
    const my = cy - 0.05;
    const mz = cz + 0.42;

    // Rigid dual-strut mirror bracket extending from door A-pillar
    add(interior, 0.12, 0.018, 0.018, M.trim, sx * (w / 2 + 0.06), my + 0.09, mz);
    add(interior, 0.12, 0.018, 0.018, M.trim, sx * (w / 2 + 0.06), my - 0.09, mz);

    // Aerodynamic commercial mirror casing
    const casing = add(interior, 0.06, 0.36, 0.15, M.trim, mx, my, mz);
    casing.rotation.y = sx * 0.32;

    // Convex glass mirror surface (angled toward driver eye)
    const pane = new THREE.Mesh(new THREE.PlaneGeometry(0.13, 0.32), mirrorMat);
    pane.position.set(mx - sx * 0.032, my, mz);
    pane.rotation.y = sx > 0 ? -Math.PI / 2 + 0.32 : Math.PI / 2 - 0.32;
    pane.rotation.x = 0.03;
    interior.add(pane);
  }

  // 3. Sculpted Dashboard Structure
  // Main dashboard upper pad (curved dark vinyl/leather)
  add(interior, w * 0.96, 0.22, 0.42, M.cabin, 0, cy - 0.26, cz + 0.58);
  // Lower center console & glovebox fascia
  add(interior, w * 0.92, 0.26, 0.22, M.trim, 0, cy - 0.46, cz + 0.52);

  // Driver seats and floor
  add(interior, 0.5, 0.14, 0.5, M.cabin, cx, cy - 0.7, cz - 0.1);
  add(interior, 0.5, 0.55, 0.1, M.cabin, cx, cy - 0.4, cz - 0.4);
  add(interior, w * 0.9, 0.03, 2, M.liner, 0, def.roofY, cz - 0.2);

  // 4. Sacred "Om Mani Padme Hum" Brass Devotional Plaque on Center Dash Cowl
  const plaqueCanvas = document.createElement('canvas');
  plaqueCanvas.width = 512;
  plaqueCanvas.height = 128;
  const pctx = plaqueCanvas.getContext('2d')!;
  const pGrad = pctx.createLinearGradient(0, 0, 512, 128);
  pGrad.addColorStop(0, '#785210');
  pGrad.addColorStop(0.3, '#d4af37');
  pGrad.addColorStop(0.5, '#fef08a');
  pGrad.addColorStop(0.7, '#d4af37');
  pGrad.addColorStop(1, '#633e08');
  pctx.fillStyle = pGrad;
  pctx.fillRect(0, 0, 512, 128);

  pctx.strokeStyle = '#fef9c3';
  pctx.lineWidth = 4;
  pctx.strokeRect(6, 6, 500, 116);
  pctx.strokeStyle = '#854d0e';
  pctx.lineWidth = 2;
  pctx.strokeRect(12, 12, 488, 104);

  // Sacred Tibetan Uchen Script Mantra
  pctx.fillStyle = '#422006';
  pctx.font = 'bold 38px "Noto Sans Tibetan", "Tibetan Machine Uni", "Jomolhari", serif, sans-serif';
  pctx.textAlign = 'center';
  pctx.textBaseline = 'middle';
  pctx.fillText('ཨོཾ་མ་ཎི་པདྨེ་ཧཱུྃ', 256, 50);

  // Transliteration & Sanskrit
  pctx.font = 'bold 16px sans-serif';
  pctx.fillStyle = '#582b08';
  pctx.fillText('OM MANI PADME HUM  ·  HIMALAYAN BLESSING', 256, 92);

  const plaqueTex = new THREE.CanvasTexture(plaqueCanvas);
  plaqueTex.colorSpace = THREE.SRGBColorSpace;
  const plaqueMat = new THREE.MeshStandardMaterial({
    map: plaqueTex,
    metalness: 0.65,
    roughness: 0.28,
  });
  const plaqueMesh = new THREE.Mesh(new THREE.PlaneGeometry(0.24, 0.06), plaqueMat);
  const centerDashX = cx > 0 ? -0.1 : 0.1;
  plaqueMesh.position.set(centerDashX, cy - 0.15, cz + 0.53);
  plaqueMesh.rotation.x = -0.22;
  interior.add(plaqueMesh);

  // 4B. 5-Color Mini Windshield Prayer Flag Garland (Lungta: Blue, White, Red, Green, Yellow)
  const flagColors = [0x2563eb, 0xf8fafc, 0xdc2626, 0x16a34a, 0xeab308];
  const numFlags = 10;
  const garlandSpan = w * 0.72;
  const flagW = garlandSpan / numFlags * 0.75;
  const flagH = 0.045;
  for (let fi = 0; fi < numFlags; fi++) {
    const fx = -garlandSpan / 2 + (fi + 0.5) * (garlandSpan / numFlags);
    // Catenary sag curve
    const sag = Math.sin((fi / (numFlags - 1)) * Math.PI) * 0.035;
    const fy = cy + 0.39 - sag;
    const fz = cz + 0.35 + sag * 0.3;
    const flagMat = new THREE.MeshStandardMaterial({
      color: flagColors[fi % flagColors.length],
      roughness: 0.85,
      side: THREE.DoubleSide,
    });
    const flagM = new THREE.Mesh(new THREE.PlaneGeometry(flagW, flagH), flagMat);
    flagM.position.set(fx, fy, fz);
    flagM.rotation.x = 0.12;
    flagM.rotation.z = (Math.random() - 0.5) * 0.08;
    interior.add(flagM);
  }

  // 5. Driver Instrument Binnacle (arched cowl over dials, lowered for clear sightline)
  add(interior, 0.46, 0.11, 0.28, M.cabin, cx, cy - 0.14, cz + 0.52, -0.2);

  // High-Resolution Instrument Cluster Backplate
  const clusterCanvas = document.createElement('canvas');
  clusterCanvas.width = 512;
  clusterCanvas.height = 256;
  const cctx = clusterCanvas.getContext('2d')!;

  const clusterTex = new THREE.CanvasTexture(clusterCanvas);
  clusterTex.colorSpace = THREE.SRGBColorSpace;
  const clusterMat = new THREE.MeshBasicMaterial({ map: clusterTex });

  const clusterPlane = new THREE.Mesh(new THREE.PlaneGeometry(0.38, 0.19), clusterMat);
  clusterPlane.position.set(cx, cy - 0.18, cz + 0.54);
  clusterPlane.rotation.x = -0.18;
  interior.add(clusterPlane);

  // 6. Center Console Infotainment Display (In-dash Google Maps navigation)
  const navCanvas = document.createElement('canvas');
  navCanvas.width = 256;
  navCanvas.height = 256;
  const nctx = navCanvas.getContext('2d')!;

  const navTex = new THREE.CanvasTexture(navCanvas);
  navTex.colorSpace = THREE.SRGBColorSpace;
  const navMat = new THREE.MeshBasicMaterial({ map: navTex });

  const navScreen = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.22), navMat);
  const navX = cx > 0 ? -0.15 : 0.15;
  navScreen.position.set(navX, cy - 0.22, cz + 0.55);
  navScreen.rotation.y = cx > 0 ? 0.2 : -0.2;
  navScreen.rotation.x = -0.15;
  interior.add(navScreen);

  // 6B. Car Stereo / Himalayan Radio Unit Faceplate
  const radioCanvas = document.createElement('canvas');
  radioCanvas.width = 256;
  radioCanvas.height = 128;
  const rctx = radioCanvas.getContext('2d')!;
  const radioTex = new THREE.CanvasTexture(radioCanvas);
  radioTex.colorSpace = THREE.SRGBColorSpace;
  const radioMat = new THREE.MeshBasicMaterial({ map: radioTex });

  const radioScreen = new THREE.Mesh(new THREE.PlaneGeometry(0.20, 0.10), radioMat);
  radioScreen.position.set(navX, cy - 0.35, cz + 0.53);
  radioScreen.rotation.y = cx > 0 ? 0.18 : -0.18;
  radioScreen.rotation.x = -0.15;
  interior.add(radioScreen);

  // Radio Rotary Knobs (Volume & Tune)
  cyl(interior, 0.012, 0.015, M.chrome, navX - 0.07, cy - 0.35, cz + 0.54).rotation.x = Math.PI / 2;
  cyl(interior, 0.012, 0.015, M.chrome, navX + 0.07, cy - 0.35, cz + 0.54).rotation.x = Math.PI / 2;

  // Center Air Vents & Hazard Button
  add(interior, 0.22, 0.045, 0.03, M.trim, navX, cy - 0.09, cz + 0.55);
  add(interior, 0.035, 0.035, 0.02, new THREE.MeshStandardMaterial({ color: 0xcc1111 }), navX, cy - 0.42, cz + 0.52);

  // Center Transmission Tunnel & Gear Shift Lever
  add(interior, 0.24, 0.28, 0.65, M.cabin, 0, cy - 0.62, cz + 0.25);
  add(interior, 0.08, 0.05, 0.08, M.trim, 0, cy - 0.46, cz + 0.35);
  add(interior, 0.015, 0.14, 0.015, M.chrome, 0, cy - 0.38, cz + 0.35, -0.2);
  cyl(interior, 0.025, 0.04, M.trim, 0, cy - 0.31, cz + 0.33);

  // 7. Steering Column & Steering Wheel (lowered slightly so road ahead is crystal clear)
  const sw = new THREE.Group();
  sw.position.set(cx, cy - 0.24, cz + 0.42);
  sw.rotation.x = def.cam.tilt ?? 0.58;
  const swheel = new THREE.Group();
  sw.add(swheel);
  swheel.add(new THREE.Mesh(new THREE.TorusGeometry(def.cam.swR ?? 0.165, 0.017, 12, 28), M.trim));
  add(swheel, 0.31, 0.022, 0.02, M.trim, 0, 0, 0);
  add(swheel, 0.022, 0.14, 0.02, M.trim, 0, -0.065, 0);
  cyl(swheel, 0.042, 0.025, M.cabin, 0, 0, 0.01);
  interior.add(sw);

  let lastDashUpdate = 0;
  const updateDashboard = (
    speedKmh: number,
    rpm: number,
    gear: string,
    fuelFrac: number,
    lights: boolean,
    navInstruction?: string
  ) => {
    const now = performance.now();
    if (now - lastDashUpdate < 40) return;
    lastDashUpdate = now;

    // A. Draw Instrument Cluster (Speedometer, Tachometer, Gear, Fuel)
    cctx.fillStyle = '#070a0e';
    cctx.fillRect(0, 0, 512, 256);

    const glowColor = lights ? '#38bdf8' : '#f1f5f9';
    const subColor = '#94a3b8';
    const needleColor = '#f43f5e';

    // Left Dial: Speedometer (0 - 160 km/h)
    const sx = 135;
    const sy = 126;
    const sr = 88;

    cctx.strokeStyle = 'rgba(255,255,255,0.12)';
    cctx.lineWidth = 6;
    cctx.beginPath();
    cctx.arc(sx, sy, sr, 0.75 * Math.PI, 2.25 * Math.PI);
    cctx.stroke();

    cctx.strokeStyle = glowColor;
    cctx.lineWidth = 3;
    cctx.beginPath();
    cctx.arc(sx, sy, sr, 0.75 * Math.PI, 2.25 * Math.PI);
    cctx.stroke();

    cctx.fillStyle = glowColor;
    cctx.font = 'bold 15px sans-serif';
    cctx.textAlign = 'center';
    cctx.textBaseline = 'middle';
    for (let k = 0; k <= 160; k += 20) {
      const a = 0.75 * Math.PI + (k / 160) * 1.5 * Math.PI;
      const tx = sx + Math.cos(a) * (sr - 16);
      const ty = sy + Math.sin(a) * (sr - 16);
      cctx.fillText(String(k), tx, ty);
    }
    cctx.font = 'bold 12px sans-serif';
    cctx.fillStyle = subColor;
    cctx.fillText('SPEED', sx, sy + 24);
    cctx.fillText('km/h', sx, sy + 38);

    // Speedo Needle
    const spdAngle = 0.75 * Math.PI + Math.min(1.0, speedKmh / 160) * 1.5 * Math.PI;
    cctx.strokeStyle = needleColor;
    cctx.lineWidth = 4.5;
    cctx.lineCap = 'round';
    cctx.beginPath();
    cctx.moveTo(sx, sy);
    cctx.lineTo(sx + Math.cos(spdAngle) * (sr - 10), sy + Math.sin(spdAngle) * (sr - 10));
    cctx.stroke();

    // Center hub cap
    cctx.fillStyle = '#0f172a';
    cctx.beginPath();
    cctx.arc(sx, sy, 8, 0, Math.PI * 2);
    cctx.fill();

    // Right Dial: Tachometer (0 - 8000 RPM)
    const rx = 377;
    const ry = 126;
    const rr = 88;

    cctx.strokeStyle = 'rgba(255,255,255,0.12)';
    cctx.lineWidth = 6;
    cctx.beginPath();
    cctx.arc(rx, ry, rr, 0.75 * Math.PI, 2.25 * Math.PI);
    cctx.stroke();

    cctx.strokeStyle = glowColor;
    cctx.lineWidth = 3;
    cctx.beginPath();
    cctx.arc(rx, ry, rr, 0.75 * Math.PI, 1.85 * Math.PI);
    cctx.stroke();

    // Redline zone
    cctx.strokeStyle = '#ef4444';
    cctx.lineWidth = 5;
    cctx.beginPath();
    cctx.arc(rx, ry, rr, 1.85 * Math.PI, 2.25 * Math.PI);
    cctx.stroke();

    cctx.fillStyle = glowColor;
    cctx.font = 'bold 15px sans-serif';
    for (let k = 0; k <= 8; k += 1) {
      const a = 0.75 * Math.PI + (k / 8) * 1.5 * Math.PI;
      const tx = rx + Math.cos(a) * (rr - 16);
      const ty = ry + Math.sin(a) * (rr - 16);
      cctx.fillStyle = k >= 6 ? '#ef4444' : glowColor;
      cctx.fillText(String(k), tx, ty);
    }
    cctx.fillStyle = subColor;
    cctx.font = 'bold 11px sans-serif';
    cctx.fillText('RPM x1000', rx, ry + 36);

    // Tacho Needle
    const rpmAngle = 0.75 * Math.PI + Math.min(1.0, rpm / 8000) * 1.5 * Math.PI;
    cctx.strokeStyle = needleColor;
    cctx.lineWidth = 4.5;
    cctx.beginPath();
    cctx.moveTo(rx, ry);
    cctx.lineTo(rx + Math.cos(rpmAngle) * (rr - 10), ry + Math.sin(rpmAngle) * (rr - 10));
    cctx.stroke();

    // Center Digital LCD Display (Gear, Fuel Liters, Speed)
    cctx.fillStyle = '#090d16';
    cctx.fillRect(220, 48, 72, 160);
    cctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
    cctx.lineWidth = 1.5;
    cctx.strokeRect(220, 48, 72, 160);

    // Gear indicator
    cctx.fillStyle = '#38bdf8';
    cctx.font = 'bold 26px monospace';
    cctx.fillText(gear, 256, 82);

    // Fuel Gauge in center
    cctx.fillStyle = '#94a3b8';
    cctx.font = 'bold 10px sans-serif';
    cctx.fillText('FUEL', 256, 114);

    // E and F marks
    cctx.font = '9px monospace';
    cctx.fillStyle = '#ef4444';
    cctx.fillText('E', 232, 128);
    cctx.fillStyle = '#10b981';
    cctx.fillText('F', 280, 128);

    // Fuel Bar
    cctx.fillStyle = 'rgba(255,255,255,0.1)';
    cctx.fillRect(230, 134, 52, 8);
    cctx.fillStyle = fuelFrac < 0.15 ? '#ef4444' : '#10b981';
    cctx.fillRect(230, 134, Math.max(3, 52 * fuelFrac), 8);

    // Exact Liters Readout
    const remainingL = (fuelFrac * def.fuelCapacity).toFixed(1);
    cctx.fillStyle = fuelFrac < 0.15 ? '#f87171' : '#a7f3d0';
    cctx.font = 'bold 11px monospace';
    cctx.fillText(`${remainingL} L`, 256, 158);

    // Digital Speed
    cctx.fillStyle = '#cbd5e1';
    cctx.font = 'bold 13px monospace';
    cctx.fillText(`${Math.round(speedKmh)} KM/H`, 256, 186);

    clusterTex.needsUpdate = true;

    // B. Draw Center Dashboard Infotainment Screen (Google Maps in Dash!)
    nctx.fillStyle = '#0f172a';
    nctx.fillRect(0, 0, 256, 256);

    nctx.fillStyle = '#137333';
    nctx.fillRect(0, 0, 256, 68);

    nctx.fillStyle = '#ffffff';
    nctx.font = 'bold 15px sans-serif';
    nctx.textAlign = 'left';
    nctx.fillText(navInstruction || 'Route Navigation', 16, 32);

    nctx.font = '12px sans-serif';
    nctx.fillStyle = '#d1fae5';
    nctx.fillText('Rimbick - Gairigaon Pass', 16, 52);

    nctx.strokeStyle = '#334155';
    nctx.lineWidth = 14;
    nctx.beginPath();
    nctx.moveTo(128, 240);
    nctx.quadraticCurveTo(80, 160, 160, 110);
    nctx.stroke();

    nctx.strokeStyle = '#3b82f6';
    nctx.lineWidth = 8;
    nctx.beginPath();
    nctx.moveTo(128, 240);
    nctx.quadraticCurveTo(80, 160, 160, 110);
    nctx.stroke();

    nctx.fillStyle = '#1d4ed8';
    nctx.beginPath();
    nctx.arc(128, 220, 8, 0, Math.PI * 2);
    nctx.fill();
    nctx.strokeStyle = '#ffffff';
    nctx.lineWidth = 3;
    nctx.stroke();

    nctx.fillStyle = '#0f172a';
    nctx.fillRect(16, 204, 60, 36);
    nctx.strokeStyle = '#38bdf8';
    nctx.lineWidth = 1.5;
    nctx.strokeRect(16, 204, 60, 36);

    nctx.fillStyle = '#38bdf8';
    nctx.font = 'bold 18px monospace';
    nctx.textAlign = 'center';
    nctx.fillText(String(Math.round(speedKmh)), 46, 228);

    navTex.needsUpdate = true;

    // C. Draw Car Radio Unit (FM 98.3 AIR Kurseong / Cassette Deck)
    rctx.fillStyle = '#111827';
    rctx.fillRect(0, 0, 256, 128);

    // Digital Radio LCD
    rctx.fillStyle = '#064e3b';
    rctx.fillRect(16, 14, 224, 52);
    rctx.strokeStyle = '#10b981';
    rctx.lineWidth = 1.5;
    rctx.strokeRect(16, 14, 224, 52);

    rctx.fillStyle = '#a7f3d0';
    rctx.font = 'bold 16px monospace';
    rctx.textAlign = 'left';
    rctx.fillText('FM 98.3 AIR KURSEONG', 26, 38);

    rctx.font = '11px sans-serif';
    rctx.fillStyle = '#6ee7b7';
    rctx.fillText('HIMALAYAN FOLK & NEWS · STEREO', 26, 56);

    // Animated EQ bars on the right
    const t = now * 0.008;
    for (let bi = 0; bi < 6; bi++) {
      const bh = 6 + Math.abs(Math.sin(t + bi * 1.3)) * 22;
      rctx.fillStyle = bi > 4 ? '#ef4444' : '#34d399';
      rctx.fillRect(200 + bi * 6, 58 - bh, 4, bh);
    }

    // Radio Cassette Slot & Station Presets
    rctx.fillStyle = '#030712';
    rctx.fillRect(20, 76, 216, 10);

    // Push buttons [1] [2] [3] [4] [5] [BAND]
    const btnLabels = ['1', '2', '3', '4', '5', 'FM'];
    for (let pi = 0; pi < 6; pi++) {
      const bx = 20 + pi * 36;
      rctx.fillStyle = '#1f2937';
      rctx.fillRect(bx, 94, 30, 20);
      rctx.strokeStyle = '#374151';
      rctx.strokeRect(bx, 94, 30, 20);
      rctx.fillStyle = '#9ca3af';
      rctx.font = 'bold 10px monospace';
      rctx.textAlign = 'center';
      rctx.fillText(btnLabels[pi], bx + 15, 108);
    }

    radioTex.needsUpdate = true;

    // D. Euro Truck Simulator 2 Style Wing Mirror Reflection (Real-Time Rear Vision)
    const skyCol = lights ? '#08111d' : '#6b96cf';
    const hillCol = lights ? '#0a1610' : '#274820';
    const roadCol = lights ? '#131518' : '#22252a';

    // Sky in mirror
    mctx.fillStyle = skyCol;
    mctx.fillRect(0, 0, 128, 256);

    // Mountain hills in rear reflection
    mctx.fillStyle = hillCol;
    mctx.beginPath();
    mctx.moveTo(0, 115);
    mctx.lineTo(45, 92);
    mctx.lineTo(85, 112);
    mctx.lineTo(128, 86);
    mctx.lineTo(128, 256);
    mctx.lineTo(0, 256);
    mctx.closePath();
    mctx.fill();

    // Receding Asphalt Highway
    mctx.fillStyle = roadCol;
    mctx.beginPath();
    mctx.moveTo(64, 110);
    mctx.lineTo(12, 256);
    mctx.lineTo(116, 256);
    mctx.closePath();
    mctx.fill();

    // Dashed center road marking moving with vehicle speed
    const roadOffset = (now * speedKmh * 0.04) % 32;
    mctx.strokeStyle = lights ? '#fef08a' : '#ffffff';
    mctx.lineWidth = 2.5;
    mctx.setLineDash([10, 8]);
    mctx.lineDashOffset = -roadOffset;
    mctx.beginPath();
    mctx.moveTo(64, 110);
    mctx.lineTo(64, 256);
    mctx.stroke();
    mctx.setLineDash([]);

    // Solid white road shoulder edge lines
    mctx.strokeStyle = '#e2e8f0';
    mctx.lineWidth = 1.5;
    mctx.beginPath();
    mctx.moveTo(61, 110);
    mctx.lineTo(18, 256);
    mctx.moveTo(67, 110);
    mctx.lineTo(110, 256);
    mctx.stroke();

    // Night tail reflection or following car headlights
    if (lights) {
      mctx.fillStyle = 'rgba(239, 68, 68, 0.45)';
      mctx.beginPath();
      mctx.arc(64, 215, 6, 0, Math.PI * 2);
      mctx.fill();
    }

    // Mirror split line (ETS 2 commercial dual-pane mirror)
    mctx.fillStyle = '#0f172a';
    mctx.fillRect(0, 186, 128, 3.5);

    mirrorTex.needsUpdate = true;
  };

  // Wheels
  const tg = new THREE.CylinderGeometry(def.wheelR, def.wheelR, def.tw, 22).rotateZ(Math.PI / 2);
  const rg = new THREE.CylinderGeometry(def.wheelR * 0.68, def.wheelR * 0.68, def.tw + 0.01, 12).rotateZ(
    Math.PI / 2
  );
  const wheels: { pivot: THREE.Group; spin: THREE.Group; front: boolean }[] = [];

  for (const [sx, sz] of [
    [1, 1],
    [-1, 1],
    [1, -1],
    [-1, -1],
  ] as const) {
    const pivot = new THREE.Group();
    const spin = new THREE.Group();
    spin.add(new THREE.Mesh(tg, M.tire), new THREE.Mesh(rg, M.rim));
    pivot.add(spin);
    pivot.position.set((sx * def.track) / 2, def.wheelR, (sz * def.wheelbase) / 2);
    root.add(pivot);
    wheels.push({ pivot, spin, front: sz > 0 });
  }

  // Headlight spot cones & ETS 2 Volumetric Dust/Mist Cones
  const spots: THREE.SpotLight[] = [];
  const beamMats: THREE.MeshBasicMaterial[] = [];
  if (opts.lights !== false) {
    for (const sx of [-1, 1]) {
      const sp = new THREE.SpotLight(0xfff5e6, 0, 120, 0.58, 0.65, 1.5);
      sp.position.set(sx * def.width * 0.3, 0.75, def.length / 2 - 0.2);
      sp.target.position.set(sx * def.width * 0.15, -0.3, def.length / 2 + 32);
      root.add(sp, sp.target);
      spots.push(sp);

      // ETS 2 Volumetric Headlight Mist Cone (visible in dark / fog / night)
      const bGeo = new THREE.CylinderGeometry(0.08, 1.6, 26, 16, 1, true);
      bGeo.rotateX(-Math.PI / 2);
      bGeo.translate(0, 0, 13);
      const bMat = new THREE.MeshBasicMaterial({
        color: 0xfff4db,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const bMesh = new THREE.Mesh(bGeo, bMat);
      bMesh.position.copy(sp.position);
      bMesh.lookAt(sp.target.position);
      root.add(bMesh);
      beamMats.push(bMat);
    }
  }

  // Static bake optimization for traffic/parked vehicles to reduce draw calls
  if (opts.bake) {
    body.updateMatrixWorld(true);
    const by = new Map<THREE.Material, THREE.BufferGeometry[]>();
    const olds: THREE.Mesh[] = [];
    body.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        const mesh = o as THREE.Mesh;
        olds.push(mesh);
        const g = mesh.geometry.index ? mesh.geometry.toNonIndexed() : mesh.geometry.clone();
        g.applyMatrix4(mesh.matrixWorld);
        const arr = by.get(mesh.material as THREE.Material) || [];
        arr.push(g);
        by.set(mesh.material as THREE.Material, arr);
      }
    });
    for (const o of olds) o.parent?.remove(o);
    for (const [m, gs] of by) {
      body.add(new THREE.Mesh(mergeGeometries(gs), m));
    }
  }

  root.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });

  // Cache original vertices for physical crash deformation and repair
  const originalGeos: { mesh: THREE.Mesh; origPos: Float32Array }[] = [];
  body.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      const mesh = o as THREE.Mesh;
      const pos = mesh.geometry.attributes.position;
      if (pos) {
        originalGeos.push({
          mesh,
          origPos: new Float32Array(pos.array),
        });
      }
    }
  });

  let currentDamage = 0;

  const applyDamage = (impactLocal: THREE.Vector3, force: number): number => {
    const intensity = Math.min(1.0, force / 15);
    currentDamage = Math.min(1.0, currentDamage + intensity * 0.35);
    const radius = 0.8 + intensity * 0.9;
    const maxDeform = 0.15 + intensity * 0.25;

    for (const { mesh, origPos } of originalGeos) {
      const pos = mesh.geometry.attributes.position;
      if (!pos) continue;
      let modified = false;

      for (let i = 0; i < pos.count; i++) {
        const vx = origPos[i * 3];
        const vy = origPos[i * 3 + 1];
        const vz = origPos[i * 3 + 2];
        const dist = Math.hypot(vx - impactLocal.x, vy - impactLocal.y, vz - impactLocal.z);

        if (dist < radius) {
          const factor = (1 - dist / radius) * maxDeform;
          const nx = (Math.random() - 0.5) * 0.05;
          const ny = (Math.random() - 0.5) * 0.05;
          const nz = (Math.random() - 0.5) * 0.05;
          pos.setXYZ(
            i,
            vx - Math.sign(vx || 1) * factor * 0.5 + nx,
            vy - factor * 0.3 + ny,
            vz - Math.sign(impactLocal.z || 1) * factor + nz
          );
          modified = true;
        }
      }
      if (modified) {
        pos.needsUpdate = true;
        mesh.geometry.computeVertexNormals();
      }
    }
    return currentDamage;
  };

  const repairDamage = () => {
    currentDamage = 0;
    for (const { mesh, origPos } of originalGeos) {
      const pos = mesh.geometry.attributes.position;
      if (pos) {
        pos.array.set(origPos);
        pos.needsUpdate = true;
        mesh.geometry.computeVertexNormals();
      }
    }
  };

  const getDamage = () => currentDamage;

  const setHeadlights = (on: boolean, k = 1) => {
    M.head.emissiveIntensity = on ? 2.2 : 0.1;
    for (const sp of spots) sp.intensity = on ? 380 * k : 0;
    for (const bm of beamMats) bm.opacity = on ? 0.11 * k : 0;
  };

  const setBrakeLights = (on: boolean) => {
    M.tail.emissiveIntensity = on ? 3.5 : 0.4;
    M.tail.color.setHex(on ? 0xff2222 : 0x660000);
  };

  return {
    root,
    body,
    interior,
    wheels,
    swheel,
    setHeadlights,
    setBrakeLights,
    applyDamage,
    repairDamage,
    getDamage,
    envMats: [M.paint, M.glass, M.rim],
    updateDashboard,
  };
}
