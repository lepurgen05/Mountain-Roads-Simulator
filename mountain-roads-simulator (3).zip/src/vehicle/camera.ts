/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { Vehicle } from './vehicle.ts';
import { RoadSampleState } from '../types.ts';

const NAMES = ['Chase', 'Close chase', 'Cockpit', 'Hood', 'Aerial'];
const tv = new THREE.Vector3();

export interface CameraWorldInterface {
  blocked(x: number, z: number, margin?: number): boolean;
  groundAt(x: number, z: number, st: RoadSampleState): number;
}

export class CameraRig {
  public camera: THREE.PerspectiveCamera;
  public mode: number = 0;
  public distScale: number = 1;
  public heightScale: number = 1;
  public sens: number = 1;
  public shakeOn: boolean = true;
  public baseFov: number = 62;
  public yaw: number = 0;
  public py: number = 0;
  public t: number = 0;
  public st: RoadSampleState = { i: 0, off: 0, hw: 4, rx: 1, rz: 0 };
  public fov: number = 62;
  public look: THREE.Vector3 = new THREE.Vector3();

  constructor(camera: THREE.PerspectiveCamera) {
    this.camera = camera;
  }

  public select(i: number, v: Vehicle): string {
    this.mode = ((i % 5) + 5) % 5;
    v.model.body.visible = this.mode !== 2;
    v.model.interior.visible = true;
    return NAMES[this.mode] + ' camera';
  }

  public snap(v: Vehicle): void {
    this.yaw = v.yaw;
    this.st.dom = -1;
    this.py = v.y + 3;
    this.fov = this.baseFov;
    this.look.set(v.x, v.y + 1, v.z);
  }

  public update(dt: number, v: Vehicle, world: CameraWorldInterface): void {
    const m = this.mode;
    const cam = this.camera;
    const cm = v.def.cam;
    const sc = cm.s;
    this.t += dt;

    let dy = v.yaw - this.yaw;
    dy = Math.atan2(Math.sin(dy), Math.cos(dy));
    this.yaw += dy * (1 - Math.exp(-dt * (m === 4 ? 2 : 3.8) * this.sens));

    const sf = Math.min(1, v.speedKmh / (v.def.maxSpeed * 3.6));
    const shake = this.shakeOn
      ? 0.012 * sf * (Math.sin(this.t * 47) + Math.sin(this.t * 31))
      : 0;

    if (m === 2 || m === 3) {
      // Cockpit / Hood camera attached directly to vehicle chassis
      const l = m === 2 ? cm.cockpit : cm.hood;
      v.root.updateMatrixWorld(true);
      tv.set(l[0], l[1], l[2]);
      v.root.localToWorld(tv);

      // Realistic driver head g-force dynamics in first-person cockpit
      let headTiltX = 0;
      let headLeanZ = 0;
      if (m === 2) {
        headTiltX = Math.max(-0.05, Math.min(0.05, -v.ax * 0.007));
        headLeanZ = Math.max(-0.04, Math.min(0.04, -v.w * 0.012));
      }

      cam.position.set(tv.x, tv.y + shake, tv.z);
      cam.quaternion.copy(v.root.quaternion);
      cam.rotateY(Math.PI);
      if (m === 2) {
        cam.rotateX(headTiltX - 0.035); // Natural slight glance toward road ahead and instrument cluster
        cam.rotateZ(headLeanZ);
      }
    } else {
      const base =
        m === 0
          ? [7, 2.7, 1.2]
          : m === 1
          ? [4.4, 1.7, 1.0]
          : [13, 28, 0.5];

      const d0 = base[0] * (m === 4 ? Math.sqrt(sc) : sc) * this.distScale;
      const h = base[1] * (m === 4 ? 1 : 1 + (sc - 1) * 0.8) * this.heightScale;

      let d = d0;
      let px = v.x - Math.sin(this.yaw) * d;
      let pz = v.z - Math.cos(this.yaw) * d;

      // Obstacle collision avoidance to prevent camera clipping inside walls or terrain
      for (let k = 0; k < 6 && world.blocked(px, pz, 1.4); k++) {
        d *= 0.65;
        px = v.x - Math.sin(this.yaw) * d;
        pz = v.z - Math.cos(this.yaw) * d;
      }

      const g = world.groundAt(px, pz, this.st) + 1.2;
      this.py += (Math.max(v.y + h, g) - this.py) * (1 - Math.exp(-dt * 5.5));
      if (this.py < g) this.py = g;

      cam.position.set(px, this.py + shake, pz);

      const ahead = m === 4 ? 0 : 4 * sc;
      const k = 1 - Math.exp(-dt * 9.5);
      this.look.x += (v.x + Math.sin(v.yaw) * ahead - this.look.x) * k;
      this.look.y += (v.y + base[2] * (1 + (sc - 1) * 0.6) - this.look.y) * k;
      this.look.z += (v.z + Math.cos(v.yaw) * ahead - this.look.z) * k;
      cam.lookAt(this.look);
    }

    // Dynamic FOV based on speed
    const tf = this.baseFov + (m === 2 ? 4 : m === 3 ? 2 : 0) + sf * (m === 4 ? 4 : 16);
    this.fov += (tf - this.fov) * (1 - Math.exp(-dt * 3.5));
    if (Math.abs(cam.fov - this.fov) > 0.01) {
      cam.fov = this.fov;
      cam.updateProjectionMatrix();
    }
  }
}
