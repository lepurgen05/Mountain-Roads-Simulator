/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

export const HORIZON: [number, number, number] = [0.5, 0.62, 0.76];

export class Sky {
  public u: {
    sunDir: { value: THREE.Vector3 };
    moonDir: { value: THREE.Vector3 };
    zen: { value: THREE.Color };
    hor: { value: THREE.Color };
    sunCol: { value: THREE.Color };
    moonIllum: { value: number };
    stars: { value: number };
    cover: { value: number };
    dark: { value: number };
    flash: { value: number };
    sunVis: { value: number };
    time: { value: number };
  };
  public mat: THREE.ShaderMaterial;
  public mesh: THREE.Mesh;

  constructor() {
    const u = (this.u = {
      sunDir: { value: new THREE.Vector3(0, 1, 0) },
      moonDir: { value: new THREE.Vector3(0, -1, 0) },
      zen: { value: new THREE.Color(0.08, 0.2, 0.52) },
      hor: { value: new THREE.Color(...HORIZON) },
      sunCol: { value: new THREE.Color(1, 0.9, 0.7) },
      moonIllum: { value: 0.5 },
      stars: { value: 0 },
      cover: { value: 0.2 },
      dark: { value: 0 },
      flash: { value: 0 },
      sunVis: { value: 1 },
      time: { value: 0 },
    });

    this.mat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      depthTest: false,
      fog: false,
      uniforms: u,
      vertexShader: `
        varying vec3 vDir;
        void main() {
          vDir = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 sunDir, moonDir, zen, hor, sunCol;
        uniform float moonIllum, stars, cover, dark, flash, sunVis, time;
        varying vec3 vDir;

        float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
        float hash3(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }
        float noise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
                     mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
        }
        float fbm(vec2 p) {
          float a = 0.5, s = 0.0;
          for (int i = 0; i < 5; i++) {
            s += a * noise(p);
            p *= 2.02;
            a *= 0.5;
          }
          return s;
        }

        void main() {
          vec3 d = normalize(vDir);
          vec3 col = mix(hor, zen, pow(max(d.y, 0.0), 0.5));
          float sd = max(dot(d, sunDir), 0.0);
          col += sunCol * pow(sd, 6.0) * 0.22 * sunVis;

          if (d.y > 0.0) {
            // Star field with twinkling
            vec3 p = d * 160.0;
            vec3 id = floor(p);
            float hs = hash3(id);
            float st = step(0.9972, hs) * (0.6 + 0.4 * sin(time * 3.0 + hs * 80.0));
            st *= 1.0 - smoothstep(0.0, 0.45, length(fract(p) - 0.5));
            col += vec3(0.9, 0.95, 1.0) * st * stars * (1.0 - cover) * smoothstep(0.0, 0.12, d.y) * 2.0;

            // Moon disc and phase illumination
            float dm = dot(d, moonDir);
            float disc = smoothstep(0.99992, 0.99996, dm) * step(0.0, moonDir.y + 0.05);
            vec3 q = (d - moonDir * dm) / 0.0125;
            vec3 sT = normalize(sunDir - moonDir * dot(sunDir, moonDir) + 1e-5);
            float u = dot(q, sT);
            float lit = smoothstep(1.0 - 2.0 * moonIllum - 0.15, 1.0 - 2.0 * moonIllum + 0.15, u);
            col += vec3(1.0, 0.97, 0.88) * disc * (0.04 + 0.96 * lit) * 3.0 * (1.0 - cover * 0.9)
                 + vec3(0.5, 0.6, 0.9) * pow(max(dm, 0.0), 300.0) * 0.35 * moonIllum;

            // Clouds
            vec2 uv = d.xz / (d.y + 0.15) * 0.9 + vec2(time * 0.012, time * 0.004);
            float n = fbm(uv * 1.3);
            float thr = mix(0.8, 0.3, cover);
            float c = smoothstep(thr, thr + 0.22, n) * smoothstep(0.0, 0.2, d.y);
            float lum = clamp(dot(hor, vec3(0.4, 0.4, 0.2)) * 1.9, 0.02, 1.0);
            vec3 cc = mix(vec3(0.7, 0.74, 0.82), vec3(1.0, 0.98, 0.95), smoothstep(0.5, 0.9, n));
            cc *= mix(1.0, 0.4, dark) * lum;
            cc += sunCol * pow(sd, 4.0) * 0.3 * sunVis;
            col = mix(col, cc, c * 0.92);
            col += sunCol * pow(sd, 500.0) * 8.0 * sunVis * (1.0 - c * 0.95);
          } else {
            col = hor;
          }

          // Lightning flash
          col += vec3(0.7, 0.75, 1.0) * flash * 0.7;
          gl_FragColor = vec4(col, 1.0);

          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }
      `,
    });

    this.mesh = new THREE.Mesh(new THREE.SphereGeometry(600, 32, 16), this.mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = -1000;
  }

  public update(camera: THREE.Camera, t: number): void {
    this.mesh.position.copy(camera.position);
    this.u.time.value = t;
  }
}
