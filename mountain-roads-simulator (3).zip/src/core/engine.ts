/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Sky, HORIZON } from './sky.ts';
import { GameSettings } from '../types.ts';

export const SUN_DIR = new THREE.Vector3(0.6, 0.42, 0.68).normalize();

export const isSoftwareGl = (() => {
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return false;
  }
})();

export class Engine {
  public renderer: THREE.WebGLRenderer;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public hemi: THREE.HemisphereLight;
  public sun: THREE.DirectionalLight;
  public moon: THREE.DirectionalLight;
  public sunDir: THREE.Vector3;
  public moonDir: THREE.Vector3;
  public fogBase: number = 0.0012;
  public envTex: THREE.Texture;
  public sky: Sky;
  public onStep: ((dt: number) => void)[] = [];
  public onFrame: ((dt: number) => void)[] = [];
  public paused: boolean = false;
  public last: number = 0;
  public time: number = 0;
  public reflections: boolean = true;
  private animId: number = 0;
  private resizeListener: () => void;

  constructor(canvas: HTMLCanvasElement, s: GameSettings) {
    const r = (this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: !isSoftwareGl && s.antialias,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true,
    }));
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.toneMappingExposure = 1.06;
    r.outputColorSpace = THREE.SRGBColorSpace;
    r.shadowMap.enabled = !isSoftwareGl && s.shadows !== 'Off';
    r.shadowMap.type = THREE.PCFSoftShadowMap;

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(new THREE.Color().setRGB(...HORIZON), 0.0012);
    this.camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.15, 1600);

    // ETS 2 Ambient Hemisphere Light (Mountain Sky Azure + Alpine Meadow Ground Bounce)
    this.hemi = new THREE.HemisphereLight(
      new THREE.Color(0x7ea8e6),
      new THREE.Color(0x2f3e22),
      0.95
    );
    this.scene.add(this.hemi);

    // ETS 2 Directional Sun (Golden Sunlight with High Physical Radiance)
    const sun = (this.sun = new THREE.DirectionalLight(0xfff6ea, 3.6));
    this.scene.add(sun, sun.target);

    const moon = (this.moon = new THREE.DirectionalLight(0x94b4ff, 0));
    this.scene.add(moon, moon.target);

    this.sunDir = SUN_DIR.clone();
    this.moonDir = new THREE.Vector3(0, -1, 0);

    const sc = sun.shadow.camera;
    sc.left = sc.bottom = -65;
    sc.right = sc.top = 65;
    sc.near = 1;
    sc.far = 420;
    sun.shadow.bias = -0.00018;
    sun.shadow.normalBias = 0.022;

    const pm = new THREE.PMREMGenerator(r);
    this.envTex = pm.fromScene(new RoomEnvironment(), 0.04).texture;
    pm.dispose();
    this.scene.environment = this.envTex;

    this.sky = new Sky();
    this.scene.add(this.sky.mesh);

    this.resizeListener = () => this.apply(s);
    window.addEventListener('resize', this.resizeListener);
    this.apply(s);
  }

  public apply(s: GameSettings): void {
    const r = this.renderer;
    const dpr = isSoftwareGl ? 1 : Math.min(window.devicePixelRatio * (s.resolution / 100), 2.2);
    r.setPixelRatio(dpr);
    r.setSize(window.innerWidth, window.innerHeight);

    this.camera.aspect = window.innerWidth / window.innerHeight;
    const dist = s.renderDistance * 160 + 80;
    this.fogBase = 1.85 / dist;
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.density = this.fogBase;
    }
    this.camera.far = dist * 1.4 + 400;
    this.camera.updateProjectionMatrix();

    const size = s.shadows === 'High' ? 2048 : 1024;
    this.sun.castShadow = !isSoftwareGl && s.shadows !== 'Off';
    if (this.sun.shadow.mapSize.x !== size) {
      this.sun.shadow.mapSize.set(size, size);
      if (this.sun.shadow.map) {
        this.sun.shadow.map.dispose();
        this.sun.shadow.map = null as unknown as THREE.WebGLRenderTarget;
      }
    }
    this.reflections = s.effects === 'High';
  }

  public followLight(x: number, y: number, z: number): void {
    this.sun.target.position.set(x, y, z);
    this.sun.position.copy(this.sunDir).multiplyScalar(220).add(this.sun.target.position);
    this.moon.target.position.set(x, y, z);
    this.moon.position.copy(this.moonDir).multiplyScalar(220).add(this.moon.target.position);
  }

  public start(): void {
    this.last = performance.now();
    const loop = (t: number) => {
      this.animId = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (t - this.last) / 1000);
      this.last = t;

      if (!this.paused) {
        this.time += dt;
        // Optimized 60Hz physics substepping (max 2 substeps) to maintain high frame rate without CPU stalls
        const n = Math.max(1, Math.min(2, Math.ceil(dt / (1 / 60))));
        const h = dt / n;
        for (let k = 0; k < n; k++) {
          for (let f = 0; f < this.onStep.length; f++) {
            this.onStep[f](h);
          }
        }
        for (let f = 0; f < this.onFrame.length; f++) {
          this.onFrame[f](dt);
        }
      }

      this.sky.update(this.camera, this.time);
      this.renderer.render(this.scene, this.camera);
    };

    this.animId = requestAnimationFrame(loop);
  }

  public dispose(): void {
    cancelAnimationFrame(this.animId);
    window.removeEventListener('resize', this.resizeListener);
    this.renderer.dispose();
    this.envTex.dispose();
  }
}
