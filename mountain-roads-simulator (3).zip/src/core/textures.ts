/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { mulberry32 } from './noise.ts';

// Tileable procedural detail texture (3 octaves of wrapped value noise + speckle).
export function noiseTexture(size: number, lo: number, hi: number, seed: number, speckle: number): THREE.CanvasTexture {
  const rnd = mulberry32(seed);
  const layers = [
    [4, 0.35],
    [16, 0.3],
    [64, 0.35],
  ];
  const grids = layers.map(([n]) => {
    const g = new Float32Array(n * n);
    for (let i = 0; i < g.length; i++) g[i] = rnd();
    return g;
  });

  const cv = document.createElement('canvas');
  cv.width = cv.height = size;
  const ctx = cv.getContext('2d')!;
  const img = ctx.createImageData(size, size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let v = 0;
      for (let l = 0; l < 3; l++) {
        const n = layers[l][0];
        const G = grids[l];
        const gx = (x / size) * n;
        const gy = (y / size) * n;
        const ix = Math.floor(gx);
        const iy = Math.floor(gy);
        let fx = gx - ix;
        let fy = gy - iy;
        fx = fx * fx * (3 - 2 * fx);
        fy = fy * fy * (3 - 2 * fy);
        const a = G[(iy % n) * n + (ix % n)];
        const b = G[(iy % n) * n + ((ix + 1) % n)];
        const c = G[((iy + 1) % n) * n + (ix % n)];
        const d = G[((iy + 1) % n) * n + ((ix + 1) % n)];
        v += layers[l][1] * (a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy);
      }
      const o = (y * size + x) * 4;
      const g = Math.max(0, Math.min(255, (lo + (hi - lo) * v + (rnd() - 0.5) * speckle) * 255));
      img.data[o] = g;
      img.data[o + 1] = g;
      img.data[o + 2] = g;
      img.data[o + 3] = 255;
    }
  }

  ctx.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(cv);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

export function canvasTex(text: string, w: number, h: number, bg: string, fg: string, font: string): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const g = c.getContext('2d')!;
  g.fillStyle = bg;
  g.fillRect(0, 0, w, h);
  g.strokeStyle = fg;
  g.lineWidth = 6;
  g.strokeRect(6, 6, w - 12, h - 12);
  g.fillStyle = fg;
  g.font = font;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText(text, w / 2, h / 2 + 3);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

/**
 * Euro Truck Simulator 2 Roadside Flora: Dense multi-blade grass tufts with alpine wildflowers
 */
export function grassTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  const size = 256;
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(107);

  // Clear transparent
  g.clearRect(0, 0, size, size);

  // 1. Multi-blade dense grass clumps
  const numBlades = 55;
  for (let i = 0; i < numBlades; i++) {
    const rootX = 16 + rnd() * (size - 32);
    const rootY = size - 4;
    const bladeH = 90 + rnd() * 140;
    const bladeW = 3.5 + rnd() * 4.0;
    const lean = (rnd() - 0.5) * 48;
    const tipX = rootX + lean;
    const tipY = size - bladeH;
    const ctrlX = rootX + lean * 0.45 + (rnd() - 0.5) * 20;
    const ctrlY = size - bladeH * 0.55;

    // Rich gradient from moist deep chlorophyll root to sunlit golden-green tip
    const grad = g.createLinearGradient(rootX, rootY, tipX, tipY);
    const hue = 82 + rnd() * 32;
    grad.addColorStop(0, `hsl(${hue - 12}, 68%, 20%)`);
    grad.addColorStop(0.35, `hsl(${hue}, 56%, 32%)`);
    grad.addColorStop(0.75, `hsl(${hue + 8}, 62%, 46%)`);
    grad.addColorStop(1.0, `hsl(${hue + 14}, 72%, 58%)`);

    g.fillStyle = grad;
    g.beginPath();
    g.moveTo(rootX - bladeW * 0.5, rootY);
    g.quadraticCurveTo(ctrlX - bladeW * 0.25, ctrlY, tipX, tipY);
    g.quadraticCurveTo(ctrlX + bladeW * 0.25, ctrlY, rootX + bladeW * 0.5, rootY);
    g.closePath();
    g.fill();
  }

  // 2. Himalayan Alpine Wildflowers (buttercups, gentians, pink asters, chamomile)
  const flowerCount = 18;
  const flowers = [
    { petals: '#fbbf24', center: '#d97706' }, // Alpine buttercup
    { petals: '#3b82f6', center: '#fbbf24' }, // Mountain blue gentian
    { petals: '#f43f5e', center: '#fef08a' }, // Wild rhododendron pink
    { petals: '#f8fafc', center: '#f59e0b' }, // White daisy / chamomile
    { petals: '#a855f7', center: '#fef08a' }, // Purple alpine aster
  ];

  for (let f = 0; f < flowerCount; f++) {
    const fx = 24 + rnd() * (size - 48);
    const fy = 95 + rnd() * 110;
    const flower = flowers[Math.floor(rnd() * flowers.length)];
    const r = 3.5 + rnd() * 3.5;

    // Stem
    g.strokeStyle = '#2d5a1e';
    g.lineWidth = 1.5;
    g.beginPath();
    g.moveTo(fx, fy + r);
    g.quadraticCurveTo(fx + (rnd() - 0.5) * 10, fy + 35, fx + (rnd() - 0.5) * 8, size - 10);
    g.stroke();

    // Petals
    g.fillStyle = flower.petals;
    const petalsNum = 5;
    for (let p = 0; p < petalsNum; p++) {
      const ang = (p / petalsNum) * Math.PI * 2;
      const px = fx + Math.cos(ang) * (r * 1.1);
      const py = fy + Math.sin(ang) * (r * 1.1);
      g.beginPath();
      g.arc(px, py, r * 0.7, 0, Math.PI * 2);
      g.fill();
    }
    // Flower Center
    g.fillStyle = flower.center;
    g.beginPath();
    g.arc(fx, fy, r * 0.6, 0, Math.PI * 2);
    g.fill();
  }

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

export function tunnelWallTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(99);

  // Reinforced concrete blocks with drainage grooves and hazard stripes
  g.fillStyle = '#4a4d52';
  g.fillRect(0, 0, 256, 256);

  // Concrete grid seams
  g.strokeStyle = '#2d2f33';
  g.lineWidth = 3;
  g.strokeRect(0, 0, 256, 256);
  g.beginPath();
  g.moveTo(0, 128);
  g.lineTo(256, 128);
  g.moveTo(128, 0);
  g.lineTo(128, 256);
  g.stroke();

  // Noise specks
  for (let i = 0; i < 400; i++) {
    const x = rnd() * 256;
    const y = rnd() * 256;
    const s = 1 + rnd() * 3;
    g.fillStyle = rnd() > 0.5 ? '#36393e' : '#5d6168';
    g.fillRect(x, y, s, s);
  }

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

export function roadAsphaltTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = c.height = 512;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(101);

  // Deep dark bitumen base (Euro Truck Simulator 2 style rich asphalt)
  g.fillStyle = '#22252a';
  g.fillRect(0, 0, 512, 512);

  // Dual polished wheel wear tracks (where heavy tires compress and polish bitumen)
  const leftTrackGrad = g.createLinearGradient(70, 0, 200, 0);
  leftTrackGrad.addColorStop(0, 'rgba(20, 22, 26, 0)');
  leftTrackGrad.addColorStop(0.5, 'rgba(16, 17, 21, 0.55)');
  leftTrackGrad.addColorStop(1, 'rgba(20, 22, 26, 0)');
  g.fillStyle = leftTrackGrad;
  g.fillRect(70, 0, 130, 512);

  const rightTrackGrad = g.createLinearGradient(310, 0, 440, 0);
  rightTrackGrad.addColorStop(0, 'rgba(20, 22, 26, 0)');
  rightTrackGrad.addColorStop(0.5, 'rgba(16, 17, 21, 0.55)');
  rightTrackGrad.addColorStop(1, 'rgba(20, 22, 26, 0)');
  g.fillStyle = rightTrackGrad;
  g.fillRect(310, 0, 130, 512);

  // Coarse stone aggregate & mineral specks (limestone, quartz, basalt)
  const img = g.getImageData(0, 0, 512, 512);
  const data = img.data;
  for (let i = 0; i < 512 * 512; i++) {
    const r = rnd();
    const x = i % 512;
    const inTrack = (x > 85 && x < 185) || (x > 325 && x < 425);

    let val = inTrack ? 32 + Math.floor(r * 16) : 38 + Math.floor(r * 26);
    if (!inTrack && r > 0.86) {
      val += Math.floor(rnd() * 48);
    } else if (r < 0.08) {
      val -= Math.floor(rnd() * 18);
    }
    const idx = i * 4;
    data[idx] = Math.min(255, Math.max(0, val));
    data[idx + 1] = Math.min(255, Math.max(0, Math.floor(val * 0.97)));
    data[idx + 2] = Math.min(255, Math.max(0, Math.floor(val * 0.94)));
    data[idx + 3] = 255;
  }
  g.putImageData(img, 0, 0);

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 16;
  return t;
}

// Procedural Tangent-Space Normal Map for ETS 2 Asphalt Aggregate
export function roadAsphaltNormal(): THREE.CanvasTexture {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(202);

  const h = new Float32Array(size * size);
  for (let i = 0; i < size * size; i++) {
    const r = rnd();
    h[i] = r * 0.4 + (r > 0.85 ? 0.6 : 0);
  }

  const img = g.createImageData(size, size);
  const d = img.data;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      const l = h[y * size + ((x - 1 + size) % size)];
      const r = h[y * size + ((x + 1) % size)];
      const u = h[((y - 1 + size) % size) * size + x];
      const b = h[((y + 1) % size) * size + x];

      const dx = (l - r) * 2.2;
      const dy = (u - b) * 2.2;
      const dz = 1.0;
      const len = Math.hypot(dx, dy, dz);

      d[idx] = Math.floor(((dx / len) * 0.5 + 0.5) * 255);
      d[idx + 1] = Math.floor(((dy / len) * 0.5 + 0.5) * 255);
      d[idx + 2] = Math.floor(((dz / len) * 0.5 + 0.5) * 255);
      d[idx + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 16;
  return t;
}

// Procedural Roughness Map (Polished Tire Tracks = smooth specular sheen, shoulders = rough)
export function roadRoughnessTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d')!;

  g.fillStyle = '#d2d2d2';
  g.fillRect(0, 0, 256, 256);

  const gradL = g.createLinearGradient(35, 0, 100, 0);
  gradL.addColorStop(0, '#d2d2d2');
  gradL.addColorStop(0.5, '#707070');
  gradL.addColorStop(1, '#d2d2d2');
  g.fillStyle = gradL;
  g.fillRect(35, 0, 65, 256);

  const gradR = g.createLinearGradient(155, 0, 220, 0);
  gradR.addColorStop(0, '#d2d2d2');
  gradR.addColorStop(0.5, '#707070');
  gradR.addColorStop(1, '#d2d2d2');
  g.fillStyle = gradR;
  g.fillRect(155, 0, 65, 256);

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 16;
  return t;
}

/**
 * Euro Truck Simulator 2 Style High-Resolution Terrain Micro-Detail Map.
 * Blends organic grass blade stippling, gravel scree, and moist dark soil humus.
 */
export function groundDetailTexture(): THREE.CanvasTexture {
  const size = 512;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(31415);

  g.fillStyle = '#a8b0a2';
  g.fillRect(0, 0, size, size);

  const img = g.getImageData(0, 0, size, size);
  const d = img.data;

  const o1 = new Float32Array(64 * 64);
  for (let i = 0; i < 64 * 64; i++) o1[i] = rnd();
  const o2 = new Float32Array(16 * 16);
  for (let i = 0; i < 16 * 16; i++) o2[i] = rnd();

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      const nx1 = ((x / size) * 16) % 16;
      const ny1 = ((y / size) * 16) % 16;
      const vLow = o2[Math.floor(ny1) * 16 + Math.floor(nx1)];

      const nx2 = ((x / size) * 64) % 64;
      const ny2 = ((y / size) * 64) % 64;
      const vHigh = o1[Math.floor(ny2) * 64 + Math.floor(nx2)];

      const grain = (rnd() - 0.5) * 0.12;
      const combined = 0.55 * vLow + 0.35 * vHigh + grain;

      const baseVal = 145 + combined * 70;
      d[idx] = Math.min(255, Math.max(0, Math.floor(baseVal * 1.02)));
      d[idx + 1] = Math.min(255, Math.max(0, Math.floor(baseVal * 1.05)));
      d[idx + 2] = Math.min(255, Math.max(0, Math.floor(baseVal * 0.94)));
      d[idx + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 16;
  return t;
}

/**
 * Tangent-Space Normal Map for Hills & Mountain Slopes (ETS 2 tactile rock/soil/sod relief)
 */
export function groundNormalTexture(): THREE.CanvasTexture {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(502);

  const h = new Float32Array(size * size);
  for (let i = 0; i < size * size; i++) {
    const r = rnd();
    h[i] = r * 0.5 + (r > 0.8 ? 0.4 : 0);
  }

  const hSmooth = new Float32Array(size * size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let sum = 0;
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const sx = (x + dx + size) % size;
          const sy = (y + dy + size) % size;
          sum += h[sy * size + sx];
        }
      }
      hSmooth[y * size + x] = sum / 9;
    }
  }

  const img = g.createImageData(size, size);
  const d = img.data;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      const l = hSmooth[y * size + ((x - 1 + size) % size)];
      const r = hSmooth[y * size + ((x + 1) % size)];
      const u = hSmooth[((y - 1 + size) % size) * size + x];
      const b = hSmooth[((y + 1) % size) * size + x];

      const dx = (l - r) * 2.8;
      const dy = (u - b) * 2.8;
      const dz = 1.0;
      const len = Math.hypot(dx, dy, dz);

      d[idx] = Math.floor(((dx / len) * 0.5 + 0.5) * 255);
      d[idx + 1] = Math.floor(((dy / len) * 0.5 + 0.5) * 255);
      d[idx + 2] = Math.floor(((dz / len) * 0.5 + 0.5) * 255);
      d[idx + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 16;
  return t;
}

/**
 * Authentic Himalayan Village House Wall Facade Texture (Timber siding courses, stone plinth, plaster)
 */
export function houseWallTexture(): THREE.CanvasTexture {
  const size = 512;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(888);

  g.fillStyle = '#f0ebe1';
  g.fillRect(0, 0, size, size);

  const boardH = 32;
  for (let y = 0; y < size; y += boardH) {
    g.fillStyle = 'rgba(40, 30, 20, 0.18)';
    g.fillRect(0, y, size, 4);

    g.strokeStyle = 'rgba(70, 50, 30, 0.10)';
    g.lineWidth = 1;
    g.beginPath();
    g.moveTo(0, y + boardH / 2);
    g.lineTo(size, y + boardH / 2 + (rnd() - 0.5) * 2);
    g.stroke();
  }

  for (let y = size - 80; y < size; y += 20) {
    g.strokeStyle = 'rgba(50, 45, 40, 0.22)';
    g.lineWidth = 2;
    g.beginPath();
    g.moveTo(0, y);
    g.lineTo(size, y);
    g.stroke();
    for (let x = (y % 40 === 0 ? 0 : 25); x < size; x += 50) {
      g.beginPath();
      g.moveTo(x + (rnd() - 0.5) * 4, y);
      g.lineTo(x + (rnd() - 0.5) * 4, y + 20);
      g.stroke();
    }
  }

  const img = g.getImageData(0, 0, size, size);
  const d = img.data;
  for (let i = 0; i < size * size; i++) {
    const n = (rnd() - 0.5) * 16;
    const idx = i * 4;
    d[idx] = Math.min(255, Math.max(0, d[idx] + n));
    d[idx + 1] = Math.min(255, Math.max(0, d[idx + 1] + n));
    d[idx + 2] = Math.min(255, Math.max(0, d[idx + 2] + n));
  }
  g.putImageData(img, 0, 0);

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 16;
  return t;
}

/**
 * Tangent-Space Normal Map for House Walls (Timber lapboard steps & mortar joints)
 */
export function houseWallNormal(): THREE.CanvasTexture {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;

  const boardH = 16;
  const h = new Float32Array(size * size);
  for (let y = 0; y < size; y++) {
    const frac = (y % boardH) / boardH;
    const ramp = frac * 0.55;
    for (let x = 0; x < size; x++) {
      h[y * size + x] = ramp;
    }
  }

  const img = g.createImageData(size, size);
  const d = img.data;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      const l = h[y * size + ((x - 1 + size) % size)];
      const r = h[y * size + ((x + 1) % size)];
      const u = h[((y - 1 + size) % size) * size + x];
      const b = h[((y + 1) % size) * size + x];

      const dx = (l - r) * 2.0;
      const dy = (u - b) * 2.5;
      const dz = 1.0;
      const len = Math.hypot(dx, dy, dz);

      d[idx] = Math.floor(((dx / len) * 0.5 + 0.5) * 255);
      d[idx + 1] = Math.floor(((dy / len) * 0.5 + 0.5) * 255);
      d[idx + 2] = Math.floor(((dz / len) * 0.5 + 0.5) * 255);
      d[idx + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 16;
  return t;
}

/**
 * Authentic Corrugated Galvanized Sheet Metal Roof Texture (ETS 2 style wave profile & fasteners)
 */
export function corrugatedRoofTexture(): THREE.CanvasTexture {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(777);

  g.fillStyle = '#b8bec6';
  g.fillRect(0, 0, size, size);

  const waveWidth = 16;
  for (let x = 0; x < size; x += waveWidth) {
    const waveGrad = g.createLinearGradient(x, 0, x + waveWidth, 0);
    waveGrad.addColorStop(0, 'rgba(255, 255, 255, 0.35)');
    waveGrad.addColorStop(0.5, 'rgba(0, 0, 0, 0.28)');
    waveGrad.addColorStop(1, 'rgba(255, 255, 255, 0.35)');
    g.fillStyle = waveGrad;
    g.fillRect(x, 0, waveWidth, size);

    for (const py of [40, 128, 216]) {
      g.fillStyle = 'rgba(50, 50, 50, 0.7)';
      g.beginPath();
      g.arc(x + waveWidth / 2, py, 2.0, 0, Math.PI * 2);
      g.fill();
    }
  }

  for (let i = 0; i < 600; i++) {
    const x = rnd() * size;
    const y = rnd() * size;
    const s = 1.5 + rnd() * 3.5;
    g.fillStyle = rnd() > 0.5 ? 'rgba(255, 255, 255, 0.22)' : 'rgba(70, 80, 95, 0.18)';
    g.fillRect(x, y, s, s);
  }

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 16;
  return t;
}

/**
 * Tangent-Space Normal Map for Corrugated Metal Roof Ribs
 */
export function corrugatedRoofNormal(): THREE.CanvasTexture {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;

  const waveWidth = 16;
  const h = new Float32Array(size * size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const rad = ((x % waveWidth) / waveWidth) * Math.PI * 2;
      h[y * size + x] = Math.sin(rad) * 0.5;
    }
  }

  const img = g.createImageData(size, size);
  const d = img.data;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      const l = h[y * size + ((x - 1 + size) % size)];
      const r = h[y * size + ((x + 1) % size)];
      const u = h[((y - 1 + size) % size) * size + x];
      const b = h[((y + 1) % size) * size + x];

      const dx = (l - r) * 3.5;
      const dy = (u - b) * 1.0;
      const dz = 1.0;
      const len = Math.hypot(dx, dy, dz);

      d[idx] = Math.floor(((dx / len) * 0.5 + 0.5) * 255);
      d[idx + 1] = Math.floor(((dy / len) * 0.5 + 0.5) * 255);
      d[idx + 2] = Math.floor(((dz / len) * 0.5 + 0.5) * 255);
      d[idx + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 16;
  return t;
}

/**
 * Detailed Architectural Window Panes (Wooden muntin grid, reflective glass, warm blinds)
 */
export function windowTexture(): THREE.CanvasTexture {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;

  g.fillStyle = '#1e293b';
  g.fillRect(0, 0, size, size);

  const curtainGrad = g.createLinearGradient(0, 0, 0, size * 0.6);
  curtainGrad.addColorStop(0, '#fef08a');
  curtainGrad.addColorStop(1, '#334155');
  g.fillStyle = curtainGrad;
  g.fillRect(16, 16, size - 32, size * 0.55);

  g.strokeStyle = '#475569';
  g.lineWidth = 16;
  g.strokeRect(8, 8, size - 16, size - 16);

  g.strokeStyle = '#64748b';
  g.lineWidth = 10;
  g.beginPath();
  g.moveTo(size / 2, 8);
  g.lineTo(size / 2, size - 8);
  g.moveTo(8, size / 2);
  g.lineTo(size - 8, size / 2);
  g.stroke();

  const glint = g.createLinearGradient(0, 0, size, size);
  glint.addColorStop(0, 'rgba(255, 255, 255, 0.45)');
  glint.addColorStop(0.3, 'rgba(255, 255, 255, 0)');
  glint.addColorStop(0.65, 'rgba(255, 255, 255, 0.25)');
  glint.addColorStop(0.9, 'rgba(255, 255, 255, 0)');
  g.fillStyle = glint;
  g.fillRect(16, 16, size - 32, size - 32);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

/**
 * High-detail Pine / Cedar Tree Foliage Texture (Dense needle cluster stippling)
 */
export function treeFoliageTexture(): THREE.CanvasTexture {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(404);

  g.fillStyle = '#225c30';
  g.fillRect(0, 0, size, size);

  for (let i = 0; i < 1200; i++) {
    const x = rnd() * size;
    const y = rnd() * size;
    const len = 4 + rnd() * 8;
    const ang = rnd() * Math.PI * 2;
    const r = rnd();

    g.strokeStyle = r < 0.25 ? '#14381d' : r < 0.7 ? '#2f7a40' : '#4bb35e';
    g.lineWidth = 1.2;
    g.beginPath();
    g.moveTo(x, y);
    g.lineTo(x + Math.cos(ang) * len, y + Math.sin(ang) * len);
    g.stroke();
  }

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

/**
 * Authentic Himalayan Mountain Tree Bark Texture (Fibrous vertical bark ridges)
 */
export function treeBarkTexture(): THREE.CanvasTexture {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(606);

  g.fillStyle = '#3a271a';
  g.fillRect(0, 0, size, size);

  for (let x = 0; x < size; x += 6) {
    const w = 3 + rnd() * 5;
    const shade = rnd() > 0.5 ? '#4e3523' : '#2b1c12';
    g.fillStyle = shade;
    g.fillRect(x, 0, w, size);

    if (rnd() > 0.4) {
      g.strokeStyle = '#1b120c';
      g.lineWidth = 1.5;
      g.beginPath();
      g.moveTo(x, rnd() * size);
      g.lineTo(x + (rnd() - 0.5) * 4, rnd() * size);
      g.stroke();
    }
  }

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
