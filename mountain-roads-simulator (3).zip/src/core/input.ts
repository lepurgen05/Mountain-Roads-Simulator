/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

const MAP: Record<string, 'up' | 'down' | 'left' | 'right' | 'brake'> = {
  KeyW: 'up',
  ArrowUp: 'up',
  KeyS: 'down',
  ArrowDown: 'down',
  KeyA: 'left',
  ArrowLeft: 'left',
  KeyD: 'right',
  ArrowRight: 'right',
  Space: 'brake',
};

export class Input {
  public up: boolean = false;
  public down: boolean = false;
  public left: boolean = false;
  public right: boolean = false;
  public brake: boolean = false;
  public horn: boolean = false;
  private handlers: Record<string, (() => void)[]> = {};

  // Touch virtual inputs
  public touchUp: number = 0;
  public touchDown: number = 0;
  public touchSteer: number = 0; // -1 to 1
  public touchBrake: boolean = false;

  constructor() {
    window.addEventListener('keydown', (e: KeyboardEvent) => {
      if (e.target && /^(INPUT|SELECT|TEXTAREA)$/.test((e.target as HTMLElement).tagName)) {
        return;
      }
      if (MAP[e.code]) {
        this[MAP[e.code]] = true;
        e.preventDefault();
      }
      if (e.code === 'KeyK' || e.code === 'KeyB') {
        this.horn = true;
      }
      if (!e.repeat && this.handlers[e.code]) {
        for (const fn of this.handlers[e.code]) fn();
      }
    });

    window.addEventListener('keyup', (e: KeyboardEvent) => {
      if (MAP[e.code]) {
        this[MAP[e.code]] = false;
      }
      if (e.code === 'KeyK' || e.code === 'KeyB') {
        this.horn = false;
      }
    });

    window.addEventListener('blur', () => {
      this.up = this.down = this.left = this.right = this.brake = this.horn = false;
    });
  }

  public on(code: string, fn: () => void): void {
    if (!this.handlers[code]) this.handlers[code] = [];
    this.handlers[code].push(fn);
  }

  get isThrottle(): boolean {
    return this.up || this.touchUp > 0.05;
  }

  get isBrake(): boolean {
    return this.down || this.touchDown > 0.05;
  }

  get isHandbrake(): boolean {
    return this.brake || this.touchBrake;
  }

  get steerVal(): number {
    if (Math.abs(this.touchSteer) > 0.05) return this.touchSteer;
    return (this.left ? 1 : 0) - (this.right ? 1 : 0);
  }
}
