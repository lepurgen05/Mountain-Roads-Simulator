/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import {
  noiseTexture,
  grassTexture,
  tunnelWallTexture,
  roadAsphaltTexture,
  roadAsphaltNormal,
  roadRoughnessTexture,
  groundDetailTexture,
  groundNormalTexture,
  houseWallTexture,
  houseWallNormal,
  corrugatedRoofTexture,
  corrugatedRoofNormal,
  windowTexture,
  treeFoliageTexture,
  treeBarkTexture,
  canvasTex,
} from './textures.ts';
export { canvasTex };

const col = (h: number) => new THREE.Color(h);

export const C = {
  GA: col(0x386e24), // deep rich mountain forest green
  GB: col(0x51942f), // vibrant Himalayan slope grass
  GC: col(0x6eb83b), // sunlit alpine meadow green
  PADDY: col(0x4e9432), // fresh terrace green
  DRY: col(0x527c32), // mossy green
  ROCK: col(0x636662), // mountain cliff bedrock
  SNOW: col(0xf4f7fa),
  GRAVEL: col(0x6e785a), // grassy road shoulder verge
  DIRT: col(0x56633f), // rich moist mountain soil
  HAZE: col(0x457832), // atmospheric ridge green
  ASPH: col(0x2d3034), // deep mountain tarmac
  LINE: col(0xf4f4f4),
  YEL_LINE: col(0xf5b700),
  col,
};

export const paint = (g: THREE.BufferGeometry, hex: number): THREE.BufferGeometry => {
  const c = col(hex);
  const n = g.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    a[i * 3] = c.r;
    a[i * 3 + 1] = c.g;
    a[i * 3 + 2] = c.b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3));
  return g;
};

const cyl = (a: number, b: number, h: number, y: number) =>
  new THREE.CylinderGeometry(a, b, h, 8).translate(0, y, 0);
const cone = (r: number, h: number, y: number) =>
  new THREE.ConeGeometry(r, h, 8).translate(0, y, 0);

// Rich, multi-tiered Himalayan Blue Pine with flared needle skirts (Euro Truck Simulator 2 alpine foliage)
export const pineGeo = mergeGeometries([
  paint(cyl(0.28, 0.44, 3.2, 1.6), 0x3d2b1f),
  paint(cone(3.2, 3.8, 3.8), 0x1e4f2b),
  paint(cone(2.6, 3.5, 5.8), 0x276635),
  paint(cone(2.0, 3.2, 7.8), 0x317c41),
  paint(cone(1.3, 2.8, 9.6), 0x3ea352),
]);

// Grand Himalayan Deodar Cedar with broad stepped horizontal foliage tiers
export const cedarGeo = mergeGeometries([
  paint(cyl(0.26, 0.38, 2.8, 1.4), 0x3a281c),
  paint(cyl(3.4, 3.0, 1.2, 3.2), 0x1b4d26),
  paint(cyl(2.8, 2.4, 1.1, 5.2), 0x235e30),
  paint(cyl(2.1, 1.7, 1.0, 7.1), 0x2b7139),
  paint(cone(1.5, 2.4, 9.2), 0x388c47),
]);

// Sunlit Himalayan broadleaf (Oak / Alder / Rhododendron) with organic canopy volumes
export const leafGeo = mergeGeometries([
  paint(cyl(0.34, 0.48, 3.6, 1.8), 0x483222),
  paint(new THREE.SphereGeometry(2.5, 8, 6).scale(1.1, 0.85, 1.1).translate(0, 5.2, 0), 0x3d7e26),
  paint(new THREE.SphereGeometry(1.9, 7, 5).translate(1.3, 4.5, 0.7), 0x4e9e30),
  paint(new THREE.SphereGeometry(1.7, 7, 5).translate(-1.1, 4.9, -0.6), 0x458c2b),
  paint(new THREE.SphereGeometry(1.4, 6, 5).translate(0.2, 6.2, -0.8), 0x5bb838),
]);

// Mountain hillside bush / tea-garden shrub
export const bushGeo = paint(
  new THREE.SphereGeometry(1.1, 7, 6).scale(1.1, 0.75, 1.1).translate(0, 0.55, 0),
  0x46922b
);

// ETS 2 3-Way Star Roadside Grass Quad Geometry (Visible from all 360° angles)
const ga = new THREE.PlaneGeometry(1.6, 1.2).translate(0, 0.6, 0);
export const grassGeo = mergeGeometries([
  ga,
  ga.clone().rotateY(Math.PI / 3),
  ga.clone().rotateY((Math.PI * 2) / 3),
]);

export const rockGeo = new THREE.IcosahedronGeometry(1, 1);
{
  const p = rockGeo.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i);
    const y = p.getY(i);
    const z = p.getZ(i);
    const f = 1 + 0.28 * Math.sin(x * 5.1 + y * 3.7) * Math.cos(z * 4.3 + x * 2.1);
    p.setXYZ(i, x * f, y * f * 0.7, z * f);
  }
  rockGeo.computeVertexNormals();
}

// Solid box geometry centered horizontally, bottom at y = 0
export const boxGeo = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);

// Roof geometry
const rs = new THREE.Shape();
rs.moveTo(-0.5, 0);
rs.lineTo(0.5, 0);
rs.lineTo(0, 1);
rs.closePath();
export const roofGeo = new THREE.ExtrudeGeometry(rs, { depth: 1, bevelEnabled: false }).translate(0, 0, -0.5);

// Euro Truck Simulator 2 style roadside guideposts (delineators) with retroreflective cat's eyes
const postBody = paint(
  new THREE.BoxGeometry(0.12, 1.05, 0.08).translate(0, 0.525, 0),
  0xf8fafc
);
const postAngleCap = paint(
  new THREE.CylinderGeometry(0.06, 0.06, 0.08, 8).rotateX(Math.PI / 2).translate(0, 1.02, 0),
  0xf8fafc
);
const postBlackBand = paint(
  new THREE.BoxGeometry(0.125, 0.22, 0.085).translate(0, 0.76, 0),
  0x1e2229
);
const postReflectorWhite = paint(
  new THREE.BoxGeometry(0.045, 0.16, 0.09).translate(0, 0.76, 0),
  0xffffff
);
const postReflectorRed = paint(
  new THREE.BoxGeometry(0.045, 0.16, 0.09).translate(0, 0.76, 0.01),
  0xef4444
);
export const postGeo = mergeGeometries([
  postBody,
  postAngleCap,
  postBlackBand,
  postReflectorWhite,
  postReflectorRed,
]);

// Street lamp post
const lampPole = paint(new THREE.CylinderGeometry(0.06, 0.1, 4.2, 8).translate(0, 2.1, 0), 0x33373d);
const lampArm = paint(new THREE.BoxGeometry(0.08, 0.08, 0.9).translate(0, 4.15, 0.35), 0x33373d);
const lampHead = paint(new THREE.BoxGeometry(0.22, 0.12, 0.35).translate(0, 4.1, 0.7), 0xf5a623);
export const lampGeo = mergeGeometries([lampPole, lampArm, lampHead]);

// Materials - Enhanced ETS 2 Foliage, Corrugated Tin Roofs, Facade Textures, and Terrain Relief
export const treeMat = new THREE.MeshStandardMaterial({
  vertexColors: true,
  roughness: 0.62,
  metalness: 0.02,
  map: treeFoliageTexture(),
});

export const bushMat = new THREE.MeshStandardMaterial({
  vertexColors: true,
  roughness: 0.68,
  metalness: 0.02,
  map: treeFoliageTexture(),
});

export const grassMat = new THREE.MeshStandardMaterial({
  map: grassTexture(),
  alphaTest: 0.35,
  side: THREE.DoubleSide,
  roughness: 0.68,
  metalness: 0.01,
});

export const rockMat = new THREE.MeshStandardMaterial({
  color: 0x727570,
  roughness: 0.92,
  flatShading: true,
});

export const postMat = new THREE.MeshStandardMaterial({
  vertexColors: true,
  roughness: 0.32,
  metalness: 0.15,
});

export const lampMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6 });

// Authentic Himalayan Timber & Plaster House Walls with Normal Mapping
export const wallMat = new THREE.MeshStandardMaterial({
  color: 0xffffff,
  roughness: 0.76,
  metalness: 0.02,
  map: houseWallTexture(),
  normalMap: houseWallNormal(),
  normalScale: new THREE.Vector2(0.48, 0.48),
  side: THREE.DoubleSide,
});

// Euro Truck Simulator 2 Style Painted Corrugated Tin Roofs with 3D Wave Normal Map
export const roofMat = new THREE.MeshStandardMaterial({
  color: 0xffffff,
  roughness: 0.32,
  metalness: 0.52,
  map: corrugatedRoofTexture(),
  normalMap: corrugatedRoofNormal(),
  normalScale: new THREE.Vector2(0.72, 0.72),
  side: THREE.DoubleSide,
});

// Architectural Windows with Reflective Glass and Wooden Muntins
export const winMat = new THREE.MeshStandardMaterial({
  color: 0xffffff,
  roughness: 0.15,
  metalness: 0.78,
  map: windowTexture(),
  side: THREE.DoubleSide,
});

// Euro Truck Simulator 2 Mountain Hills Terrain Material with Tangent-Space Normal Map & Micro-Detail
export const groundMat = new THREE.MeshStandardMaterial({
  vertexColors: true,
  roughness: 0.82,
  metalness: 0.04,
  map: groundDetailTexture(),
  normalMap: groundNormalTexture(),
  normalScale: new THREE.Vector2(0.55, 0.55),
});

// Euro Truck Simulator 2 Photorealistic Asphalt PBR Material with normal map and tire wear roughness
export const roadMat = new THREE.MeshStandardMaterial({
  vertexColors: true,
  roughness: 0.62,
  metalness: 0.12,
  map: roadAsphaltTexture(),
  normalMap: roadAsphaltNormal(),
  normalScale: new THREE.Vector2(0.42, 0.42),
  roughnessMap: roadRoughnessTexture(),
  polygonOffset: true,
  polygonOffsetFactor: -2,
  polygonOffsetUnits: -2,
  side: THREE.FrontSide,
});

export const tunnelMat = new THREE.MeshStandardMaterial({
  color: 0x9fa4aa,
  roughness: 0.85,
  metalness: 0.15,
  map: tunnelWallTexture(),
  side: THREE.DoubleSide,
});

export const tunnelPortalMat = new THREE.MeshStandardMaterial({
  color: 0x5a5d62,
  roughness: 0.9,
  side: THREE.DoubleSide,
});

const dummy = new THREE.Object3D();
const tcol = new THREE.Color();

export function inst(
  parent: THREE.Object3D,
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  max: number,
  shadow = true
): THREE.InstancedMesh {
  const m = new THREE.InstancedMesh(geo, mat, Math.max(1, max));
  m.castShadow = shadow;
  m.receiveShadow = true;
  m.count = 0;
  parent.add(m);
  return m;
}

export function put(
  m: THREE.InstancedMesh,
  x: number,
  y: number,
  z: number,
  sx: number,
  sy: number,
  sz: number,
  ry: number,
  r: number,
  g: number,
  b: number
): void {
  dummy.position.set(x, y, z);
  dummy.scale.set(sx, sy, sz);
  dummy.rotation.set(0, ry, 0);
  dummy.updateMatrix();
  m.setMatrixAt(m.count, dummy.matrix);
  m.setColorAt(m.count, tcol.setRGB(r, g, b));
  m.count++;
}

export function done(m: THREE.InstancedMesh): void {
  m.instanceMatrix.needsUpdate = true;
  if (m.instanceColor) m.instanceColor.needsUpdate = true;
  m.computeBoundingSphere();
}
