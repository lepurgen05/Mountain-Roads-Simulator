/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { toDir, AstroData } from '../time/clock.ts';
import { sstep } from './noise.ts';
import { roadMat, groundMat } from './assets.ts';
import { Weather } from '../weather/weather.ts';
import { Engine } from './engine.ts';

const K: [number, [number, number, number], [number, number, number]][] = [
  [-14, [0.004, 0.008, 0.022], [0.012, 0.016, 0.03]],
  [-6, [0.012, 0.02, 0.07], [0.06, 0.05, 0.1]],
  [0, [0.05, 0.1, 0.3], [0.85, 0.42, 0.25]],
  [8, [0.08, 0.18, 0.45], [0.75, 0.55, 0.45]],
  [25, [0.08, 0.2, 0.52], [0.5, 0.62, 0.76]],
];

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const tmp = new THREE.Color();
const ORANGE = new THREE.Color(1, 0.55, 0.3);
const WHITE = new THREE.Color(1, 0.95, 0.85);

export class Atmosphere {
  public e: Engine;
  public night: number = 0;
  public dark: boolean = false;
  public sunDeg: number = 30;
  public moonDir: THREE.Vector3 = new THREE.Vector3();
  public sunV: THREE.Vector3 = new THREE.Vector3();

  constructor(engine: Engine) {
    this.e = engine;
  }

  public update(A: AstroData, W: Weather): void {
    const e = this.e;
    const u = e.sky.u;
    const deg = A.sun.el * 57.2958;
    const mdeg = A.moon.el * 57.2958;
    const day = sstep(-6, 8, deg);
    this.sunDeg = deg;
    this.night = 1 - sstep(-8, 4, deg);
    this.dark = deg < 3;

    toDir(A.sun, this.sunV);
    toDir(A.moon, this.moonDir);
    u.sunDir.value.copy(this.sunV);
    u.moonDir.value.copy(this.moonDir);

    let i = 0;
    while (i < K.length - 2 && deg > K[i + 1][0]) i++;
    const t = Math.min(1, Math.max(0, (deg - K[i][0]) / (K[i + 1][0] - K[i][0])));
    const zen = u.zen.value.set(
      lerp(K[i][1][0], K[i + 1][1][0], t),
      lerp(K[i][1][1], K[i + 1][1][1], t),
      lerp(K[i][1][2], K[i + 1][1][2], t)
    );
    const hor = u.hor.value.set(
      lerp(K[i][2][0], K[i + 1][2][0], t),
      lerp(K[i][2][1], K[i + 1][2][1], t),
      lerp(K[i][2][2], K[i + 1][2][2], t)
    );

    const cover = Math.min(1, W.cloud);
    const g = Math.min(1, cover * 0.85 + W.rain * 0.3 + W.fog * 0.5 + W.snow * 0.3);
    const dark = Math.min(1, W.rain * 0.7 + W.storm * 0.5 + cover * 0.3 + W.snow * 0.2);

    for (const c of [zen, hor]) {
      const L = ((c.r + c.g + c.b) / 3) * 0.9;
      c.r += (L - c.r) * g * 0.8;
      c.g += (L - c.g) * g * 0.8;
      c.b += (L - c.b) * g * 0.8;
      c.multiplyScalar(1 - 0.35 * dark * day);
    }

    if (W.fog > 0.1) {
      hor.lerp(tmp.setRGB(0.62 * day + 0.03, 0.64 * day + 0.03, 0.67 * day + 0.04), W.fog * 0.6);
    }

    u.cover.value = cover;
    u.dark.value = dark;
    u.flash.value = W.flash;
    u.stars.value = sstep(-4, -12, deg);
    u.moonIllum.value = A.illum;
    u.sunVis.value = sstep(-3, 3, deg) * (1 - 0.9 * cover);
    u.sunCol.value.lerpColors(ORANGE, WHITE, sstep(0, 25, deg));

    const sunI = 3.2 * sstep(-1, 10, deg) * (1 - 0.88 * Math.pow(cover, 1.2));
    const moonI = 0.45 * A.illum * sstep(0, 8, mdeg) * (1 - day) * (1 - 0.8 * cover);

    e.sun.intensity = sunI;
    e.sun.color.copy(u.sunCol.value);
    e.moon.intensity = moonI;

    // Realistic night hemisphere: dark indigo sky reflection, not blown out
    e.hemi.intensity =
      (0.025 + 0.85 * day) * (0.65 + 0.35 * cover) +
      0.06 * A.illum * (mdeg > 0 ? 1 : 0.3) * (1 - day) +
      1.8 * W.flash;
    e.hemi.color.copy(zen).multiplyScalar(0.3 + 1.1 * day);
    e.hemi.groundColor.setRGB(0.005 + 0.22 * day, 0.005 + 0.25 * day, 0.008 + 0.15 * day);

    e.sunDir.copy(deg > 1 ? this.sunV : this.moonDir);
    e.moonDir.copy(this.moonDir);

    // Tone mapping: 0.55 at night, 1.0 during day (prevents overexposed bright nights)
    e.renderer.toneMappingExposure = 0.52 + 0.48 * day;

    // Dim environment reflections at night so materials don't glow in the dark
    if ((e.scene as any).environmentIntensity !== undefined) {
      (e.scene as any).environmentIntensity = 0.02 + 0.98 * day;
    }

    if (e.scene.fog instanceof THREE.FogExp2) {
      e.scene.fog.color.copy(hor);
      e.scene.fog.density =
        e.fogBase * (1 + 10 * Math.pow(W.fog, 1.5) + 3 * W.rain + 0.4 * this.night + 1.5 * W.snow);
    }

    roadMat.roughness = 0.85 - 0.55 * W.wet;
    roadMat.color.setScalar(1 - 0.25 * W.wet);
    groundMat.roughness = 0.98 - 0.25 * W.wet;
    groundMat.color.setScalar(1 - 0.2 * W.wet);
  }
}
