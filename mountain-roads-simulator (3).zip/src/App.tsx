/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { Engine } from './core/engine.ts';
import { Input } from './core/input.ts';
import { World } from './world/world.ts';
import { Vehicle } from './vehicle/vehicle.ts';
import { VEHICLES } from './vehicle/definitions.ts';
import { CameraRig } from './vehicle/camera.ts';
import { Clock, astro } from './time/clock.ts';
import { Weather } from './weather/weather.ts';
import { Precip } from './weather/precip.ts';
import { Atmosphere } from './core/atmosphere.ts';
import { sstep } from './core/noise.ts';
import { VILLAGE as V } from './data/village.ts';
import { sound } from './audio/SoundEngine.ts';
import { GameSettings, FuelState, NavDestination, NavInstruction, MultiplayerPlayerState, MultiplayerChatMessage } from './types.ts';
import { SettingsModal } from './components/SettingsModal.tsx';
import { MobileControls } from './components/MobileControls.tsx';
import { FuelHUD } from './components/FuelHUD.tsx';
import { NavigationHUD } from './components/NavigationHUD.tsx';
import { MultiplayerHUD } from './components/MultiplayerHUD.tsx';
import { NavigationEngine, POPULAR_DESTINATIONS } from './navigation/navigationEngine.ts';
import { MultiplayerManager } from './multiplayer/MultiplayerManager.ts';
import { MultiplayerLobbyModal } from './components/MultiplayerLobbyModal.tsx';

const STORAGE_KEY = 'mountainroads.v2.settings';

const DEFAULT_SETTINGS: GameSettings = {
  preset: 'High',
  resolution: 100,
  renderDistance: 7,
  shadows: 'High',
  antialias: true,
  vegetation: 80,
  effects: 'High',
  headlight: 100,
  lodScale: 1.0,
  traffic: true,
  trafficDensity: 60,
  autoWeather: true,
  liveWeather: true,
  autoTime: true,
  timeMode: 'Real time',
  fixedTimeHour: -1,
  camMode: 0,
  fov: 62,
  camDist: 1.0,
  camHeight: 1.0,
  camSens: 1.0,
  shake: true,
  master: 80,
  engineVol: 80,
  envVol: 70,
  weatherVol: 70,
  vehicle: 'hatch800',
  seed: '',
  manualGear: false,
  speedSteerEnabled: true,
  speedSteerSensitivity: 65,
  steerSensitivity: 100,
};

function seedNum(str: string): number {
  str = String(str || '').trim();
  if (!str) return Math.floor(Math.random() * 1e9);
  if (/^\d{1,9}$/.test(str)) return +str;
  let h = 2166136261;
  for (const ch of str) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) % 1e9;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // States
  const [gameState, setGameState] = useState<'menu' | 'driving' | 'paused'>('menu');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [mpModalOpen, setMpModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [seedInput, setSeedInput] = useState('');
  const [selectedVehicle, setSelectedVehicle] = useState('hatch800');
  const [lightMode, setLightMode] = useState(0); // 0 = auto, 1 = on, 2 = off

  // Settings
  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch {
      // fallback
    }
    return DEFAULT_SETTINGS;
  });

  // Telemetry for HUD
  const [hudData, setHudData] = useState({
    speed: 0,
    unit: 'km/h',
    info: 'G1 900 rpm · Gairigaon · 2103 m',
    wx: '12:00 IST · Clear · 20°C',
    damage: 0,
  });

  const [fuelState, setFuelState] = useState<FuelState>({
    fuel: 32,
    capacity: 32,
    percent: 100,
    rateLps: 0,
    rateL100km: 0,
    rangeKm: 350,
    isLow: false,
    isCritical: false,
    isOut: false,
    isRefueling: false,
    refuelProgress: 100,
    refueledLitersThisSession: 0,
    totalCostThisSession: 0,
    nearestStation: null,
  });

  // Navigation & Multiplayer States
  const [navData, setNavData] = useState<{
    instruction: NavInstruction;
    totalDistanceM: number;
    etaMinutes: number;
    remainingKm: number;
    bearingDeg: number;
    destinationName: string;
    isArrived: boolean;
  }>({
    instruction: {
      type: 'straight',
      distanceM: 0,
      text: 'Proceed to route',
      roadName: 'Gairigaon - Rimbick Road',
      speedLimitKmh: 40,
    },
    totalDistanceM: 0,
    etaMinutes: 4,
    remainingKm: 2.1,
    bearingDeg: 0,
    destinationName: 'Rimbick Bazaar',
    isArrived: false,
  });

  const [activeNavDest, setActiveNavDest] = useState<NavDestination | null>(POPULAR_DESTINATIONS[0]);
  const [playerPos, setPlayerPos] = useState({ x: 170, z: 380, yaw: 0, speedKmh: 0 });

  const [mpData, setMpData] = useState<{
    isConnected: boolean;
    connectionStatus: 'connecting' | 'connected' | 'disconnected';
    remotePlayers: MultiplayerPlayerState[];
    messages: MultiplayerChatMessage[];
    playerName: string;
  }>({
    isConnected: false,
    connectionStatus: 'disconnected',
    remotePlayers: [],
    messages: [],
    playerName: 'Himalayan Driver',
  });

  // References
  const engineRef = useRef<Engine | null>(null);
  const worldRef = useRef<World | null>(null);
  const carRef = useRef<Vehicle | null>(null);
  const rigRef = useRef<CameraRig | null>(null);
  const clockRef = useRef<Clock | null>(null);
  const wxRef = useRef<Weather | null>(null);
  const precipRef = useRef<Precip | null>(null);
  const atmoRef = useRef<Atmosphere | null>(null);
  const inputRef = useRef<Input>(new Input());
  const navEngineRef = useRef<NavigationEngine>(new NavigationEngine());
  const mpRef = useRef<MultiplayerManager | null>(null);
  const toastTimeoutRef = useRef<number | null>(null);
  const orbitRef = useRef(0);
  const menuStRef = useRef({ i: 0, off: 0, hw: 4, rx: 1, rz: 0 });

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    if (toastTimeoutRef.current) window.clearTimeout(toastTimeoutRef.current);
    toastTimeoutRef.current = window.setTimeout(() => setToastMessage(null), 2400);
  }, []);

  // Initialize simulation
  useEffect(() => {
    if (!canvasRef.current) return;

    const s = settings;
    const engine = new Engine(canvasRef.current, s);
    engineRef.current = engine;

    const input = inputRef.current;
    const world = new World(engine.scene, s);
    worldRef.current = world;

    const numericSeed = seedNum(s.seed || seedInput);
    world.setSeed(numericSeed);
    setSeedInput(String(numericSeed));

    const clock = new Clock();
    clockRef.current = clock;

    const wx = new Weather();
    wxRef.current = wx;

    const precip = new Precip(engine.scene);
    precipRef.current = precip;

    const atmo = new Atmosphere(engine);
    atmoRef.current = atmo;

    const rig = new CameraRig(engine.camera);
    rigRef.current = rig;

    // Build vehicle
    const def = VEHICLES[s.vehicle] || VEHICLES.hatch800;
    const car = new Vehicle(def, engine.scene);
    carRef.current = car;
    car.lightK = (s.headlight || 100) / 100;
    car.setSteerSettings(
      s.speedSteerEnabled !== false,
      s.speedSteerSensitivity ?? 65,
      s.steerSensitivity ?? 100
    );

    // Initialize Multiplayer Connection
    const mp = new MultiplayerManager(engine.scene);
    mpRef.current = mp;
    mp.connect();

    const placeStart = () => {
      const y = V.start.yaw;
      car.placeAt(V.start.x + Math.cos(y) * 1.2, V.start.z - Math.sin(y) * 1.2, y, world);
      rig.snap(car);
    };
    placeStart();

    // Initial weather & atmosphere
    const A = astro(clock.ms);
    const day = sstep(-6, 8, A.sun.el * 57.2958);
    wx.update(0.016, {
      alt: 2103 + car.y,
      month: clock.month(),
      hour: clock.hour(),
      auto: s.autoWeather,
      live: s.liveWeather,
      day,
    });
    atmo.update(A, wx);

    engine.apply(s);
    world.setQuality(s);
    clock.configure(s.timeMode, s.autoTime, s.fixedTimeHour);
    rig.distScale = s.camDist;
    rig.heightScale = s.camHeight;
    rig.sens = s.camSens;
    rig.shakeOn = s.shake;
    rig.baseFov = s.fov;

    // Keyboard bindings
    input.on('Escape', () => {
      setSettingsOpen((prev) => {
        if (prev) return false;
        setGameState((gs) => {
          if (gs === 'driving') {
            engine.paused = true;
            return 'paused';
          }
          if (gs === 'paused') {
            engine.paused = false;
            return 'driving';
          }
          return gs;
        });
        return false;
      });
    });

    input.on('KeyC', () => {
      if (carRef.current && rigRef.current) {
        const nextMode = (rigRef.current.mode + 1) % 5;
        const name = rigRef.current.select(nextMode, carRef.current);
        showToast(name);
      }
    });

    for (let n = 1; n <= 5; n++) {
      input.on('Digit' + n, () => {
        if (carRef.current && rigRef.current) {
          const name = rigRef.current.select(n - 1, carRef.current);
          showToast(name);
        }
      });
    }

    input.on('KeyH', () => {
      setLightMode((prev) => {
        const next = (prev + 1) % 3;
        showToast('Headlights: ' + ['auto', 'on', 'off'][next]);
        return next;
      });
    });

    input.on('KeyR', () => {
      if (carRef.current && worldRef.current && rigRef.current) {
        const p = worldRef.current.respawnPoint(carRef.current);
        carRef.current.placeAt(p.x, p.z, p.yaw, worldRef.current, true);
        rigRef.current.snap(carRef.current);
        showToast('Back on the road (repaired)');
      }
    });

    input.on('KeyY', () => {
      if (carRef.current && worldRef.current && rigRef.current) {
        const z = worldRef.current.nextZone(carRef.current.st.i, carRef.current.st.dom !== 1);
        const p = worldRef.current.teleportRow(z.row);
        carRef.current.placeAt(p.x, p.z, p.yaw, worldRef.current, false);
        rigRef.current.snap(carRef.current);
        showToast('Region: ' + z.name);
      }
    });

    const toggleRefuel = () => {
      const c = carRef.current;
      const w = worldRef.current;
      if (!c || !w) return;
      if (c.isRefueling) {
        c.stopRefueling();
        showToast('Refuelling completed');
      } else {
        const nearestSt = w.getNearestFuelStation(c.x, c.z, c.speedKmh);
        if (nearestSt && nearestSt.inBay) {
          c.startRefueling(nearestSt.station.pricePerLiter);
          showToast(`Refuelling at ${nearestSt.station.name}`);
        } else if (nearestSt) {
          showToast(`Pull into the Refuel Bay first (${Math.round(nearestSt.distance)}m away)`);
        }
      }
    };

    input.on('KeyE', toggleRefuel);
    input.on('KeyF', toggleRefuel);

    // Sub-stepped physics loop (fixed 120Hz)
    engine.onStep.push((dt) => {
      const curState = (window as any).__mrState || 'menu';
      if (curState === 'driving' && carRef.current && worldRef.current) {
        carRef.current.update(dt, inputRef.current, worldRef.current);
        worldRef.current.step(
          dt,
          carRef.current,
          atmoRef.current?.dark || !!carRef.current.st.inTunnel
        );
      }
    });

    // Frame render loop
    let mpSendTimer = 0;
    let navThrottle = 0;

    engine.onFrame.push((dt) => {
      const curState = (window as any).__mrState || 'menu';
      const c = carRef.current;
      const w = worldRef.current;
      const r = rigRef.current;
      const cl = clockRef.current;
      const weather = wxRef.current;
      const at = atmoRef.current;
      const pc = precipRef.current;

      if (!c || !w || !cl || !weather || !at || !pc || !r) return;

      cl.update(dt);
      const astroData = astro(cl.ms);
      const isDay = sstep(-6, 8, astroData.sun.el * 57.2958);

      weather.maybeFetch(settings.liveWeather);
      weather.update(dt, {
        alt: 2103 + c.y,
        month: cl.month(),
        hour: cl.hour(),
        auto: settings.autoWeather,
        live: settings.liveWeather,
        day: isDay,
      });

      at.update(astroData, weather);
      w.village.setNight(at.night);
      pc.update(engine.time, engine.camera.position, weather.rain, weather.snow, weather.wind);

      // Headlight control
      const isNightOrDark = Boolean(at.dark || weather.fog > 0.45 || weather.rain > 0.6 || weather.storm > 0.5 || c.st.inTunnel);
      const shouldLights = lightMode === 1 || (lightMode === 0 && isNightOrDark);
      c.setLights(shouldLights);

      // Remote multiplayer update
      if (mp) {
        mp.update(dt, c.x, c.z);
      }

      if (curState === 'menu') {
        orbitRef.current += dt * 0.12;
        const R = 6 + c.def.length * 0.8;
        const cam = engine.camera;
        cam.position.set(
          c.x + Math.cos(orbitRef.current) * R,
          c.y + 2.3 + c.def.cam.s,
          c.z + Math.sin(orbitRef.current) * R
        );
        for (let k = 0; k < 6 && w.blocked(cam.position.x, cam.position.z, 1.5); k++) {
          cam.position.x = c.x + (cam.position.x - c.x) * 0.75;
          cam.position.z = c.z + (cam.position.z - c.z) * 0.75;
        }
        cam.position.y = Math.max(cam.position.y, w.groundAt(cam.position.x, cam.position.z, menuStRef.current) + 1.5);
        cam.lookAt(c.x, c.y + 0.9, c.z);
        w.menuStep(dt, c);
      } else if (curState === 'driving') {
        if (w.fell(c)) {
          const p = w.respawnPoint(c);
          c.placeAt(p.x, p.z, p.yaw, w, false);
          r.snap(c);
          showToast('Fell off the edge - back on the road');
        }
        r.update(dt, c, w);

        // Multiplayer local state broadcast (20Hz)
        if (mp) {
          mpSendTimer += dt;
          if (mpSendTimer >= 0.05) {
            mpSendTimer = 0;
            mp.sendLocalState(
              c.x,
              c.y,
              c.z,
              c.yaw,
              c.pitch,
              c.roll,
              c.speedKmh,
              c.lights,
              c.isBraking,
              inputRef.current.horn,
              selectedVehicle,
              c.fuel
            );
          }
        }

        // Navigation Engine update
        const navRes = navEngineRef.current.update(dt, c.x, c.z, c.yaw, c.speedKmh, w.road, c.st);

        // Update in-dash gauges and Google Maps screen
        if (c.model.updateDashboard) {
          c.model.updateDashboard(
            c.speedKmh,
            c.rpm,
            c.gear < 0 ? 'R' : `G${c.gear}`,
            c.fuel / c.fuelCapacity,
            c.lights,
            navRes.instruction.text
          );
        }

        navThrottle += dt;
        if (navThrottle >= 0.1) {
          navThrottle = 0;
          setNavData(navRes);
          setActiveNavDest(navEngineRef.current.activeDestination);
          setPlayerPos({ x: c.x, z: c.z, yaw: c.yaw, speedKmh: Math.round(c.speedKmh) });
          if (mp) {
            setMpData({
              isConnected: mp.isConnected,
              connectionStatus: mp.connectionStatus,
              remotePlayers: mp.getPlayerList(),
              messages: [...mp.messages],
              playerName: mp.playerName,
            });
          }
        }

        const place =
          c.st.dom === 1
            ? c.st.inTunnel
              ? 'Ridge Tunnel'
              : c.st.sty === 2
              ? 'Highway'
              : c.st.sty === 1
              ? 'Cliff road'
              : 'Hill road'
            : c.x < 700
            ? 'Gairigaon'
            : c.x < 1300
            ? 'Gairigaon - Rimbick road'
            : 'Rimbick';

        const damageText = c.damage > 0 ? ` · DMG ${c.damage}%` : '';
        const infoStr = `G${c.gear < 0 ? 'R' : c.gear}  ${Math.round(c.rpm / 50) * 50} rpm   ·   ${place}  ·  ${Math.round(2103 + c.y)} m${damageText}`;
        const wxStr = `${cl.label()} IST   ·   ${weather.label}  ·  ${Math.round(weather.temp)}°C`;

        setHudData({
          speed: Math.round(c.speedKmh),
          unit: 'km/h',
          info: infoStr,
          wx: wxStr,
          damage: c.damage,
        });

        // Fuel state telemetry & landmark proximity
        const nearestSt = w.getNearestFuelStation(c.x, c.z, c.speedKmh);
        const avgEff = c.def.fuelEfficiency || 14;
        const estRange = Math.round(c.fuel * avgEff);

        setFuelState({
          fuel: c.fuel,
          capacity: c.fuelCapacity,
          percent: Math.min(100, (c.fuel / c.fuelCapacity) * 100),
          rateLps: c.fuelRateLps,
          rateL100km: c.fuelRateL100km,
          rangeKm: estRange,
          isLow: c.isLowFuel,
          isCritical: c.isCriticalFuel,
          isOut: c.isOutOfFuel,
          isRefueling: c.isRefueling,
          refuelProgress: c.refuelProgress,
          refueledLitersThisSession: c.refueledLitersThisSession,
          totalCostThisSession: c.totalCostThisSession,
          nearestStation: nearestSt
            ? {
                station: nearestSt.station,
                distance: nearestSt.distance,
                inBay: nearestSt.inBay,
              }
            : null,
        });
      }

      w.frame(c, engine.camera.position, dt, at.night, engine.sun.color);
      engine.followLight(c.x, c.y, c.z);
    });

    engine.start();

    return () => {
      engine.dispose();
    };
  }, []);

  useEffect(() => {
    (window as any).__mrState = gameState;
  }, [gameState]);

  const startSolo = () => {
    sound.init();
    sound.resume();

    const n = seedNum(seedInput);
    if (worldRef.current && n !== worldRef.current.seed) {
      worldRef.current.setSeed(n);
    }
    setSeedInput(String(n));

    if (carRef.current && worldRef.current && rigRef.current) {
      const y = V.start.yaw;
      carRef.current.placeAt(V.start.x + Math.cos(y) * 1.2, V.start.z - Math.sin(y) * 1.2, y, worldRef.current, true);
      rigRef.current.snap(carRef.current);
    }

    if (engineRef.current) engineRef.current.paused = false;
    setGameState('driving');
    showToast(`${rigRef.current ? rigRef.current.select(settings.camMode | 0, carRef.current!) : 'Chase camera'} · keep LEFT · H = headlights`);
  };

  const startMultiplayer = () => {
    sound.init();
    sound.resume();

    const mp = mpRef.current;
    if (mp && mp.sharedSeed && worldRef.current) {
      worldRef.current.setSeed(mp.sharedSeed);
      setSeedInput(String(mp.sharedSeed));
    } else {
      const n = seedNum(seedInput);
      if (worldRef.current && n !== worldRef.current.seed) {
        worldRef.current.setSeed(n);
      }
      setSeedInput(String(n));
    }

    if (carRef.current && worldRef.current && rigRef.current) {
      const y = V.start.yaw;
      carRef.current.placeAt(V.start.x + Math.cos(y) * 1.2, V.start.z - Math.sin(y) * 1.2, y, worldRef.current, true);
      rigRef.current.snap(carRef.current);
    }

    if (engineRef.current) engineRef.current.paused = false;
    setGameState('driving');
    showToast('Joined Multiplayer Convoy · Online Drivers synced');
  };

  const resumeDriving = () => {
    if (engineRef.current) engineRef.current.paused = false;
    setGameState('driving');
  };

  const toMainMenu = () => {
    if (engineRef.current) engineRef.current.paused = false;
    setGameState('menu');
    if (carRef.current) {
      carRef.current.model.body.visible = true;
      carRef.current.model.interior.visible = false;
      const y = V.start.yaw;
      carRef.current.placeAt(V.start.x + Math.cos(y) * 1.2, V.start.z - Math.sin(y) * 1.2, y, worldRef.current!, true);
    }
  };

  const cycleVeh = (d: number) => {
    const keys = Object.keys(VEHICLES);
    const nextKey = keys[(keys.indexOf(selectedVehicle) + d + keys.length) % keys.length];
    setSelectedVehicle(nextKey);
    setSettings((prev) => {
      const next = { ...prev, vehicle: nextKey };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });

    if (engineRef.current && worldRef.current) {
      if (carRef.current) engineRef.current.scene.remove(carRef.current.root);
      const def = VEHICLES[nextKey] || VEHICLES.hatch800;
      const car = new Vehicle(def, engineRef.current.scene);
      carRef.current = car;
      car.setReflections(engineRef.current.reflections ? engineRef.current.envTex : null);
      car.lightK = (settings.headlight || 100) / 100;
      car.setSteerSettings(
        settings.speedSteerEnabled !== false,
        settings.speedSteerSensitivity ?? 65,
        settings.steerSensitivity ?? 100
      );

      const y = V.start.yaw;
      car.placeAt(V.start.x + Math.cos(y) * 1.2, V.start.z - Math.sin(y) * 1.2, y, worldRef.current, true);
      if (rigRef.current) rigRef.current.snap(car);
    }
  };

  const handleUpdateSettings = (newSettings: GameSettings) => {
    setSettings(newSettings);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newSettings));

    if (engineRef.current && worldRef.current && rigRef.current && clockRef.current) {
      engineRef.current.apply(newSettings);
      worldRef.current.setQuality(newSettings);
      clockRef.current.configure(newSettings.timeMode, newSettings.autoTime, newSettings.fixedTimeHour);

      rigRef.current.distScale = newSettings.camDist;
      rigRef.current.heightScale = newSettings.camHeight;
      rigRef.current.sens = newSettings.camSens;
      rigRef.current.shakeOn = newSettings.shake;
      rigRef.current.baseFov = newSettings.fov;

      if (carRef.current) {
        carRef.current.setReflections(engineRef.current.reflections ? engineRef.current.envTex : null);
        carRef.current.lightK = newSettings.headlight / 100;
        carRef.current.setSteerSettings(
          newSettings.speedSteerEnabled !== false,
          newSettings.speedSteerSensitivity ?? 65,
          newSettings.steerSensitivity ?? 100
        );
      }
      sound.setVolumes(newSettings.master, newSettings.engineVol);
    }
  };

  const handleResetDefaults = () => {
    handleUpdateSettings(DEFAULT_SETTINGS);
    showToast('Settings reset to default');
  };

  const handleStartRefueling = (price: number) => {
    if (carRef.current) {
      carRef.current.startRefueling(price);
      showToast('Refuelling started...');
    }
  };

  const handleStopRefueling = () => {
    if (carRef.current) {
      carRef.current.stopRefueling();
      showToast('Refuelling finished');
    }
  };

  const handleEmergencyJerryCan = () => {
    if (carRef.current) {
      carRef.current.emergencyRefuel(15);
      showToast('Emergency fuel delivered (+15 L)');
    }
  };

  return (
    <>
      {/* 3D WebGL Canvas */}
      <canvas id="view" ref={canvasRef} />
      <div id="vignette" />

      {/* DRIVING HUD */}
      {gameState === 'driving' && (
        <>
          <div id="hud">
            <div id="wx">{hudData.wx}</div>
            <div id="speed">{hudData.speed}</div>
            <div id="unit">{hudData.unit}</div>
            <div id="info">{hudData.info}</div>
          </div>

          {/* Google Maps Styled Navigation HUD */}
          <NavigationHUD
            instruction={navData.instruction}
            totalDistanceM={navData.totalDistanceM}
            etaMinutes={navData.etaMinutes}
            remainingKm={navData.remainingKm}
            bearingDeg={navData.bearingDeg}
            activeDestination={activeNavDest}
            onSelectDestination={(id) => {
              navEngineRef.current.setDestination(id);
              setActiveNavDest(navEngineRef.current.activeDestination);
            }}
            playerPos={playerPos}
            remotePlayers={mpData.remotePlayers}
          />

          {/* Multiplayer Driver Convoy HUD */}
          <MultiplayerHUD
            isConnected={mpData.isConnected}
            connectionStatus={mpData.connectionStatus}
            localName={mpData.playerName}
            onUpdateName={(name) => {
              if (mpRef.current) {
                mpRef.current.setPlayerName(name);
                setMpData((prev) => ({ ...prev, playerName: mpRef.current!.playerName }));
              }
            }}
            remotePlayers={mpData.remotePlayers}
            messages={mpData.messages}
            onSendChat={(text) => mpRef.current?.sendChat(text)}
            onBroadcastHorn={() => mpRef.current?.broadcastHorn()}
            playerPos={playerPos}
          />

          {/* Sleek, compact Fuel Widget showing exact Litres left */}
          <FuelHUD
            fuelState={fuelState}
            onStartRefueling={handleStartRefueling}
            onStopRefueling={handleStopRefueling}
            onEmergencyJerryCan={handleEmergencyJerryCan}
            vehicleName={VEHICLES[selectedVehicle]?.name || 'Vehicle'}
          />
        </>
      )}

      {/* MAIN MENU */}
      {gameState === 'menu' && (
        <div id="main" className="menu">
          <h1>
            MOUNTAIN<br />
            <span>ROADS</span>
          </h1>
          <nav>
            <button id="btn-solo" onClick={startSolo}>
              SOLO DRIVE
            </button>
            <button
              id="btn-multiplayer"
              onClick={() => setMpModalOpen(true)}
              style={{ color: '#34d399', display: 'flex', alignItems: 'center', gap: '8px' }}
            >
              <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#34d399', display: 'inline-block', boxShadow: '0 0 10px #34d399' }} />
              <span>ONLINE MULTIPLAYER ({mpData.remotePlayers.length + 1} DRIVERS)</span>
            </button>
            <button id="btn-settings" onClick={() => setSettingsOpen(true)}>
              SETTINGS
            </button>
            <button id="btn-quit" onClick={() => showToast('You can close this tab now')}>
              QUIT
            </button>
          </nav>
          <div className="opts">
            <label>WORLD SEED</label>
            <input
              id="seed"
              type="text"
              maxLength={24}
              value={seedInput}
              onChange={(e) => setSeedInput(e.target.value)}
              placeholder="any number or word"
            />
            <button
              id="seed-rnd"
              onClick={() => setSeedInput(String(Math.floor(Math.random() * 1e9)))}
              title="Random seed"
            >
              RANDOM
            </button>
          </div>
          <div className="opts">
            <label>VEHICLE</label>
            <button id="veh-prev" onClick={() => cycleVeh(-1)}>
              &lt;
            </button>
            <span id="veh-name">{VEHICLES[selectedVehicle]?.name}</span>
            <button id="veh-next" onClick={() => cycleVeh(1)}>
              &gt;
            </button>
          </div>
          <p>
            Start: Gairigaon (Pushpa Store, 2,103 m) &rarr; Rimbick (2,286 m) &rarr; endless road. Drive on the LEFT.
            <br />
            W/S throttle &middot; A/D steer &middot; Space handbrake &middot; C or 1-5 camera &middot; H lights &middot; E/F refuel &middot; K horn &middot; R back on road &middot; Y next region &middot; Esc pause
          </p>
        </div>
      )}

      {/* PAUSE MENU */}
      {gameState === 'paused' && (
        <div id="pause" className="menu">
          <h1>
            <span>PAUSED</span>
          </h1>
          <nav>
            <button id="p-resume" onClick={resumeDriving}>
              RESUME
            </button>
            <button id="p-multiplayer" onClick={() => setMpModalOpen(true)}>
              CONVOY LOBBY
            </button>
            <button id="p-settings" onClick={() => setSettingsOpen(true)}>
              SETTINGS
            </button>
            <button id="p-menu" onClick={toMainMenu}>
              MAIN MENU
            </button>
          </nav>
        </div>
      )}

      {/* MULTIPLAYER LOBBY MODAL */}
      <MultiplayerLobbyModal
        isOpen={mpModalOpen}
        onClose={() => setMpModalOpen(false)}
        onJoinConvoy={startMultiplayer}
        localName={mpData.playerName}
        onUpdateName={(name) => {
          if (mpRef.current) {
            mpRef.current.setPlayerName(name);
            setMpData((prev) => ({ ...prev, playerName: mpRef.current!.playerName }));
          }
        }}
        selectedVehicle={selectedVehicle}
        onSelectVehicle={(vehKey) => {
          setSelectedVehicle(vehKey);
          if (carRef.current && engineRef.current && worldRef.current) {
            engineRef.current.scene.remove(carRef.current.root);
            const def = VEHICLES[vehKey] || VEHICLES.hatch800;
            const car = new Vehicle(def, engineRef.current.scene);
            carRef.current = car;
            car.setSteerSettings(
              settings.speedSteerEnabled !== false,
              settings.speedSteerSensitivity ?? 65,
              settings.steerSensitivity ?? 100
            );
            const y = V.start.yaw;
            car.placeAt(V.start.x + Math.cos(y) * 1.2, V.start.z - Math.sin(y) * 1.2, y, worldRef.current, true);
          }
        }}
        remotePlayers={mpData.remotePlayers}
        isConnected={mpData.isConnected}
        connectionStatus={mpData.connectionStatus}
        sharedSeed={mpRef.current?.sharedSeed || 194723}
        onShowToast={showToast}
      />

      {/* SETTINGS MODAL */}
      <SettingsModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onResetDefaults={handleResetDefaults}
      />

      {/* TOAST MESSAGE */}
      {toastMessage && <div id="toast">{toastMessage}</div>}

      {/* Mobile Touch Controls for touch devices */}
      {gameState === 'driving' && <MobileControls input={inputRef.current} />}
    </>
  );
}
