/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

const D = Math.PI / 180;
export const LAT = 27.1; // Darjeeling / Gairigaon latitude
export const LON = 88.13; // longitude

export const SPEEDS: Record<string, number> = {
  'Real time': 1,
  x10: 10,
  x60: 60,
  x300: 300,
};

export interface AstroData {
  sun: { el: number; az: number };
  moon: { el: number; az: number };
  phase: number;
  illum: number;
}

export class Clock {
  public ms: number;
  public speed: number;
  public running: boolean;
  public fixedHour: number = -1;

  constructor() {
    this.ms = Date.now();
    this.speed = 1;
    this.running = true;
  }

  public configure(mode: string, running: boolean, fixedHour: number = -1): void {
    const sp = SPEEDS[mode] || 1;
    if (sp === 1 && running && this.speed !== 1) this.ms = Date.now();
    this.speed = sp;
    this.running = running;
    this.fixedHour = fixedHour;
  }

  public update(dt: number): void {
    if (!this.running && this.fixedHour < 0) return;
    if (this.fixedHour >= 0) {
      // Overridden to specific hour
      const d = new Date();
      d.setUTCHours(Math.floor(this.fixedHour) - 5, Math.floor((this.fixedHour % 1) * 60) - 30);
      this.ms = d.getTime();
      return;
    }
    if (this.speed === 1) this.ms = Date.now();
    else this.ms += dt * 1000 * this.speed;
  }

  public ist(): Date {
    return new Date(this.ms + 19800000); // UTC + 5:30
  }

  public hour(): number {
    const d = this.ist();
    return d.getUTCHours() + d.getUTCMinutes() / 60 + d.getUTCSeconds() / 3600;
  }

  public month(): number {
    return this.ist().getUTCMonth();
  }

  public label(): string {
    const d = this.ist();
    const p = (n: number) => String(n).padStart(2, '0');
    return `${p(d.getUTCHours())}:${p(d.getUTCMinutes())}`;
  }
}

export function astro(ms: number): AstroData {
  const jd = ms / 86400000 + 2440587.5;
  const n = jd - 2451545.0;
  const L = (280.46 + 0.9856474 * n) % 360;
  const g = ((357.528 + 0.9856003 * n) % 360) * D;
  const lam = (L + 1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g)) * D;
  const eps = 23.439 * D;
  const lst = (((280.46061837 + 360.98564736629 * n) % 360) + LON) * D;
  const lat = LAT * D;

  const pos = (lm: number) => {
    const ra = Math.atan2(Math.cos(eps) * Math.sin(lm), Math.cos(lm));
    const dec = Math.asin(Math.sin(eps) * Math.sin(lm));
    const ha = lst - ra;
    return {
      el: Math.asin(Math.sin(lat) * Math.sin(dec) + Math.cos(lat) * Math.cos(dec) * Math.cos(ha)),
      az: Math.atan2(
        -Math.cos(dec) * Math.sin(ha),
        Math.sin(dec) * Math.cos(lat) - Math.cos(dec) * Math.sin(lat) * Math.cos(ha)
      ),
    };
  };

  const phase = (((jd - 2451550.1) / 29.530588853) % 1 + 1) % 1;
  return {
    sun: pos(lam),
    moon: pos(lam + phase * 2 * Math.PI),
    phase,
    illum: (1 - Math.cos(phase * 2 * Math.PI)) / 2,
  };
}

export const toDir = (p: { el: number; az: number }, o: THREE.Vector3): THREE.Vector3 => {
  const c = Math.cos(p.el);
  return o.set(Math.sin(p.az) * c, Math.sin(p.el), -Math.cos(p.az) * c);
};
