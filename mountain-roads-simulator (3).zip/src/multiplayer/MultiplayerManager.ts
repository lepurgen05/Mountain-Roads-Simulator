/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { MultiplayerPlayerState, MultiplayerChatMessage } from '../types.ts';
import { buildModel, VehicleModelResult } from '../vehicle/model.ts';
import { VEHICLES } from '../vehicle/definitions.ts';
import { sound } from '../audio/SoundEngine.ts';

interface RemoteVehicleInstance {
  data: MultiplayerPlayerState;
  model: VehicleModelResult;
  nametagSprite: THREE.Sprite;
  targetPos: THREE.Vector3;
  targetRot: THREE.Euler;
  currentPos: THREE.Vector3;
  currentYaw: number;
}

export class MultiplayerManager {
  private scene: THREE.Scene;
  private ws: WebSocket | null = null;
  public localId: string | null = null;
  public playerName: string = 'Himalayan Driver';
  public isConnected: boolean = false;
  public connectionStatus: 'connecting' | 'connected' | 'disconnected' = 'disconnected';
  public remotePlayers: Map<string, RemoteVehicleInstance> = new Map();
  public messages: MultiplayerChatMessage[] = [];
  public sharedSeed: number | null = null;
  private sendThrottle: number = 0;
  private reconnectTimeout: number | null = null;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    const savedName = localStorage.getItem('mountainroads.mp.name');
    if (savedName) this.playerName = savedName;
  }

  public setPlayerName(name: string): void {
    this.playerName = name.trim().slice(0, 18) || 'Himalayan Driver';
    localStorage.setItem('mountainroads.mp.name', this.playerName);
  }

  public connect(): void {
    if (this.ws && (this.ws.readyState === WebSocket.CONNECTING || this.ws.readyState === WebSocket.OPEN)) {
      return;
    }

    this.connectionStatus = 'connecting';
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${proto}//${host}`;

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnected = true;
        this.connectionStatus = 'connected';
      };

      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          this.handleMessage(msg);
        } catch {
          // Ignore
        }
      };

      this.ws.onclose = () => {
        this.cleanupConnection();
        this.scheduleReconnect();
      };

      this.ws.onerror = () => {
        this.cleanupConnection();
        this.scheduleReconnect();
      };
    } catch {
      this.cleanupConnection();
      this.scheduleReconnect();
    }
  }

  private cleanupConnection(): void {
    this.isConnected = false;
    this.connectionStatus = 'disconnected';
    // Remove all remote player meshes from scene
    for (const remote of this.remotePlayers.values()) {
      this.scene.remove(remote.model.root);
      this.scene.remove(remote.nametagSprite);
    }
    this.remotePlayers.clear();
  }

  private scheduleReconnect(): void {
    if (this.reconnectTimeout) return;
    this.reconnectTimeout = window.setTimeout(() => {
      this.reconnectTimeout = null;
      this.connect();
    }, 4000);
  }

  private handleMessage(msg: any): void {
    if (msg.type === 'welcome') {
      this.localId = msg.id;
      if (msg.seed && !this.sharedSeed) {
        this.sharedSeed = msg.seed;
      }
      if (Array.isArray(msg.players)) {
        for (const p of msg.players) {
          if (p.id !== this.localId) {
            this.syncRemotePlayer(p);
          }
        }
      }
    } else if (msg.type === 'sync') {
      if (Array.isArray(msg.players)) {
        const activeIds = new Set<string>();
        for (const p of msg.players) {
          if (p.id !== this.localId) {
            activeIds.add(p.id);
            this.syncRemotePlayer(p);
          }
        }
        // Remove left players
        for (const [id, remote] of this.remotePlayers.entries()) {
          if (!activeIds.has(id)) {
            this.scene.remove(remote.model.root);
            this.scene.remove(remote.nametagSprite);
            this.remotePlayers.delete(id);
          }
        }
      }
    } else if (msg.type === 'player_joined') {
      if (msg.player && msg.player.id !== this.localId) {
        this.syncRemotePlayer(msg.player);
      }
    } else if (msg.type === 'player_left') {
      const remote = this.remotePlayers.get(msg.id);
      if (remote) {
        this.scene.remove(remote.model.root);
        this.scene.remove(remote.nametagSprite);
        this.remotePlayers.delete(msg.id);
      }
    } else if (msg.type === 'player_event') {
      if (msg.event === 'horn') {
        sound.honk(true);
        setTimeout(() => sound.honk(false), 300);
      } else if (msg.event === 'chat') {
        this.messages.push({
          id: `msg_${Date.now()}_${Math.random()}`,
          senderId: msg.senderId,
          senderName: msg.payload?.senderName || 'Driver',
          text: msg.payload?.text || '',
          timestamp: Date.now(),
        });
        if (this.messages.length > 20) this.messages.shift();
      }
    }
  }

  private syncRemotePlayer(p: MultiplayerPlayerState): void {
    let remote = this.remotePlayers.get(p.id);
    if (!remote) {
      // Spawn new 3D model for remote player
      const def = VEHICLES[p.vehicle] || VEHICLES.hatch800;
      const model = buildModel(def, { lights: true });

      // Custom paint tint if provided
      if (p.color && model.envMats[0]) {
        (model.envMats[0] as THREE.MeshStandardMaterial).color.setHex(p.color);
      }

      model.root.position.set(p.x, p.y, p.z);
      model.root.rotation.set(p.pitch, p.yaw, p.roll, 'YXZ');
      this.scene.add(model.root);

      // Create floating 3D nametag
      const nametagSprite = this.createNametagSprite(p.name);
      nametagSprite.position.set(p.x, p.y + 1.8, p.z);
      this.scene.add(nametagSprite);

      remote = {
        data: p,
        model,
        nametagSprite,
        targetPos: new THREE.Vector3(p.x, p.y, p.z),
        targetRot: new THREE.Euler(p.pitch, p.yaw, p.roll, 'YXZ'),
        currentPos: new THREE.Vector3(p.x, p.y, p.z),
        currentYaw: p.yaw,
      };
      this.remotePlayers.set(p.id, remote);
    } else {
      // Update target transform for smooth interpolation
      remote.data = p;
      remote.targetPos.set(p.x, p.y, p.z);
      remote.targetRot.set(p.pitch, p.yaw, p.roll, 'YXZ');
      remote.model.setHeadlights(p.lights);
      remote.model.setBrakeLights(p.brake);
    }
  }

  private createNametagSprite(name: string): THREE.Sprite {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 64;
    const ctx = canvas.getContext('2d')!;

    // Rounded tag background
    ctx.fillStyle = 'rgba(11, 16, 22, 0.85)';
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.7)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(6, 6, 244, 52, 16);
    ctx.fill();
    ctx.stroke();

    // Text
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(name, 128, 32);

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    const material = new THREE.SpriteMaterial({ map: texture, depthTest: false, transparent: true });
    const sprite = new THREE.Sprite(material);
    sprite.scale.set(3.2, 0.8, 1);
    return sprite;
  }

  public sendLocalState(
    x: number,
    y: number,
    z: number,
    yaw: number,
    pitch: number,
    roll: number,
    speedKmh: number,
    lights: boolean,
    brake: boolean,
    horn: boolean,
    vehicleKey: string,
    fuelLiters: number
  ): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    const payload = {
      type: 'update',
      state: {
        name: this.playerName,
        vehicle: vehicleKey,
        color: VEHICLES[vehicleKey]?.color || 0xb3262b,
        x: +x.toFixed(2),
        y: +y.toFixed(2),
        z: +z.toFixed(2),
        yaw: +yaw.toFixed(3),
        pitch: +pitch.toFixed(3),
        roll: +roll.toFixed(3),
        speedKmh: +speedKmh.toFixed(1),
        lights,
        brake,
        horn,
        fuelLiters: +fuelLiters.toFixed(1),
      },
    };

    this.ws.send(JSON.stringify(payload));
  }

  public sendChat(text: string): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(
      JSON.stringify({
        type: 'event',
        event: 'chat',
        payload: {
          senderName: this.playerName,
          text,
        },
      })
    );
    this.messages.push({
      id: `local_${Date.now()}`,
      senderId: this.localId || 'local',
      senderName: this.playerName,
      text,
      timestamp: Date.now(),
    });
  }

  public broadcastHorn(): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(
      JSON.stringify({
        type: 'event',
        event: 'horn',
      })
    );
  }

  public update(dt: number, localX: number, localZ: number): void {
    // Interpolate remote vehicles smoothly towards their latest network state
    const lerpFactor = 1 - Math.exp(-14 * dt);

    for (const remote of this.remotePlayers.values()) {
      remote.currentPos.lerp(remote.targetPos, lerpFactor);

      // Smooth yaw interpolation
      let dyaw = remote.targetRot.y - remote.currentYaw;
      while (dyaw > Math.PI) dyaw -= Math.PI * 2;
      while (dyaw < -Math.PI) dyaw += Math.PI * 2;
      remote.currentYaw += dyaw * lerpFactor;

      remote.model.root.position.copy(remote.currentPos);
      remote.model.root.rotation.set(remote.targetRot.x, remote.currentYaw, remote.targetRot.z, 'YXZ');

      // Update Nametag position & distance
      const dist = Math.hypot(remote.currentPos.x - localX, remote.currentPos.z - localZ);
      remote.nametagSprite.position.set(
        remote.currentPos.x,
        remote.currentPos.y + 1.8 + Math.min(2.5, dist * 0.02),
        remote.currentPos.z
      );
      // Scale nametag slightly with distance for readability
      const scale = Math.max(2.4, Math.min(5.5, dist * 0.04));
      remote.nametagSprite.scale.set(scale, scale * 0.25, 1);

      // Animate wheels
      const speedMs = remote.data.speedKmh / 3.6;
      for (const w of remote.model.wheels) {
        w.spin.rotation.x += speedMs * dt * 2.5;
      }
    }
  }

  public getPlayerList(): MultiplayerPlayerState[] {
    return Array.from(this.remotePlayers.values()).map((r) => r.data);
  }
}
